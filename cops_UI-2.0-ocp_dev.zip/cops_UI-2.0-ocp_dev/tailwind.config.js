const withMT = require("@material-tailwind/react/utils/withMT");

module.exports = withMT({
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./node_modules/react-tailwindcss-datepicker/dist/index.esm.js"
  ],
  theme: {
    extend: {
      gridTemplateColumns: {
        // Simple 16 column grid
        '13': 'repeat(13, minmax(0, 2fr))',
      },
      backgroundImage: {
        'wallpaper': "url('../src/assets/images/bg_img.jpg')",
        // 'footer-texture': "url('/img/footer-texture.png')",
      },
      colors: {
        'customcolor': "#283489",
        'iconColor': "#003060",
        'pinkcolor': "#E7D2CC",
        'greycolor': "#B9B7BD",
      },
      height: {
        '102': '30.5rem',
      },
      width: {
        '42': '10.5rem',
      },
      margin: {
        'left-42': '10.5rem',
        'left-40': '8.1rem',
        'x-15': '3.75rem',
      },   
    },
  },
  plugins: [
    require('tailwind-scrollbar'),
  ],
});
