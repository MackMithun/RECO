// import { useGetCatrerSectionQuery } from '../services/api-service'

//creating service
const initialState = {
    loading: true,
    error: '',
    post: []
}


//calling reducer
const reducer = (state: any, action: any) => {
    switch (action.type) {
        case "Success":
            return {
                loading: false,
                post: action.payload,
                error: ''
            }
        case "Error":
            return {
                loading: true,
                post: {},
                error: action.payload
            }
        default:
            return state;
    }
}

export { reducer, initialState }

// export const useCatererService = () => {
//     const [catrersectionData, setcatrersectionData] = React.useState([]);
//     React.useEffect(() => {
//         const { data, error, isLoading } = useGetCatrerSectionQuery('value');
//         setcatrersectionData(data);
//     }, [0])
//     return [setcatrersectionData]
// }