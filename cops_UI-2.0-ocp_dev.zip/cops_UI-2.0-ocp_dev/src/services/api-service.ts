// Need to use the React-specific entry point to import createApi
import { useEffect, useState, useMemo, useReducer } from 'react'
import { environment } from '../environments/environment.dev';
import { GlobalApiNames } from '../helpers/ApiNames'

import { reducer, initialState } from '../hooks/catrerService'
//use Reducer hooks


const CatererStation = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  useEffect(() => {
    (async () => {
      try {
        const fetchfunc = await fetch(`${environment.baseUrl}/api/ProductionSheet/caterer-station`);
        const stationsData = await fetchfunc.json();
        const uniqueStationCodes = stationsData.reduce((uniqueCodes: any[], station: { station_Code: any }) => {
          if (!uniqueCodes.includes(station.station_Code)) {
            uniqueCodes.push(station.station_Code);
          }
          return uniqueCodes;
        }, []);
        const sortedUniqueStations = uniqueStationCodes.sort();
        const sortedData = [
          //{ station_Code: 'Select', stationID: 0 },
          ...sortedUniqueStations.map((code: any) => ({ station_Code: code })),
        ]
        dispatch({ type: 'Success', payload: sortedData })
      }
      catch (err) {
        dispatch({ type: 'Error', payload: err })
      }
    })();

  }, [])

  return {
    state
  }
}


const  ByCatererData =async(QueryString: any) =>{
  const response = await fetch(`${environment.baseUrl}${GlobalApiNames.cateterBystationCode}${QueryString}`);
  const CatererData = await response.json();
  return CatererData
}

const  Caterers =async() =>{

  const response = await fetch(`${environment.baseUrl}${GlobalApiNames.caterers}`);
  const CatererData = await response.json();
  return CatererData
}

const FlightNumber = async (QueryString: any) => {
//  api/ManufacturingSheet/getflightno?flightDate=2023-12-01&dep=MAA&flightType=d
  const response = await fetch(environment.baseUrl + GlobalApiNames.ManufacturingflightDate + QueryString);
  const FlightNumber = await response.json();
  return FlightNumber;
}

async function AircraftType() { 
    const response = await fetch(environment.baseUrl + GlobalApiNames.getaircrafttype);
    const aircraftType = await response.json();
  return aircraftType;
}

async function Terminal(QueryString: any) {
    const response = await fetch(environment.baseUrl + GlobalApiNames.getterminalbystation + `${QueryString}`);
    const TerminalData = await response.json();
  return TerminalData;
}

export { CatererStation, ByCatererData, Caterers, FlightNumber, AircraftType, Terminal,  }

// Define a service using a base URL and expected endpoints
// export const serviceApi = createApi({
//     reducerPath: 'Api',
//     baseQuery: fetchBaseQuery({ baseUrl: environment.baseUrl }),
//     endpoints: (builder) => ({
//       getCatrerSection: builder.query<any[],string>({
//         query(value) {return { url : GlobalApiNames.catererStation}}
//       }),
//     }),
//   })

  // export const { useGetCatrerSectionQuery } = serviceApi