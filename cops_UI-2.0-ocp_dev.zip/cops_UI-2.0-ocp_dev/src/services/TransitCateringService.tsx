import { getapiUrl } from "../config/apiUrl";

export function getTransitcateringData(props: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.getTransitcateringInfo + `flightDate=${props.flightDate}&dep=${props.station}&isBaseFlight=${props.typeSelected}&aircraftID=${props.aircraftType}&catererCode=${null}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => {
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}