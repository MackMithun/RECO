import { deleteapiUrl, getapiUrl, getqueuestatusUrl, saveexecutiontimeUrl, sendEmailUrl, sendQueue, sheetTriggerUrl } from "../config/apiUrl";


export function GetProductionQueueData(searchData: any, pageindex: any) {
    const formattedDate = new Date(searchData.Date).toISOString().split('T')[0];
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.getProductionQueueData + `dt=${formattedDate}&pageNo=${pageindex}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200) {
                res.json().then(data => {
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function SendRetrigger(reqbody: any) {
    var promise = new Promise(function (resolve, reject) {
        console.log(JSON.stringify(reqbody));
        fetch(sheetTriggerUrl.productionSheet + '/ProductionSheet', {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain',
                'Content-Type': 'application/json;charset=UTF-8'
            },
            body: reqbody,
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
               resolve(res); 
            }
            else {
                reject("");
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function emailTrigger(emailmessage: any) {
    return new Promise(function (resolve, reject) {
        fetch(sendEmailUrl.productionsheet + `?QueueId=${emailmessage.queuid}&stationCode=${emailmessage.station}&caterCode=${emailmessage.caterer}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        })
        .then(res => {
            if (res.status === 200) {
                resolve(res);
            } else {
                reject(new Error('Non-200 status code'));
            }
        })
        .catch(err => {
            reject(err);
        });
    });
}

export function getQueueStatus(queueid: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getqueuestatusUrl.productionsheet + `?queueid=${queueid}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => {
                    console.log(data,'data')
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function AddNewQueue(reqbody: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(sendQueue.productionsheet, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain',
                'Content-Type': 'application/json;charset=UTF-8'
            },
            body: JSON.stringify(reqbody),
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then((data: any) => { resolve(data); });
            }
            else {
                reject("");
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function DeleteProductionSheet(id: number) {
    var promise = new Promise(function (resolve, reject) {
        fetch(deleteapiUrl.deleteProductionSheet + id, {
            method: 'Delete',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            resolve(res.status);
        }).catch(err => {
            reject(err);
        });
    });
    return promise;
}

export function saveExecutiontime(reqbody: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(saveexecutiontimeUrl.productionsheet + `?id=${reqbody.row.queueid}&time=${reqbody.row.executiontime}`, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain',
                'Content-Type': 'application/json;charset=UTF-8'
            },
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then((data: any) => { resolve(data); });
            }
            else {
                reject("");
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

