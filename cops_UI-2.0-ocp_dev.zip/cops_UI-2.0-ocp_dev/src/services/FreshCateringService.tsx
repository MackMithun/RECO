import { deleteapiUrl, getapiUrl } from "../config/apiUrl";

export function getFreshcateringData(props: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.getFreshCateringdata + `flightDate=${props.flightDate}&dep=${props.station}&isBaseFlight=${props.typeSelected}&aircraftID=${props.aircraftType}&catererCode=${null}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => {
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function InventoryCreation({flightDate,groupId}:any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.createinventory + `flightDate=${flightDate}&flightGroupId=${groupId}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => {
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

export function Deleteinventory(id: number) {
    var promise = new Promise(function (resolve, reject) {
        fetch(deleteapiUrl.deleteInventory + id, {
            method: 'Delete',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            resolve(res.status);
        }).catch(err => {
            reject(err);
        });
    });
    return promise;
}

export function getEditInventory(props: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.getEditInvenoryData + `flightDate=${props.flt_Dt}&flightGroupId=${props.groupId}`, {
            method: 'get',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => {
                    resolve(data);
                });
            }
            else {
                reject();
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}
