import { createSignal } from "@react-rxjs/utils";
import React from "react";
import { AiOutlineDelete, AiOutlineEdit } from "react-icons/ai";
import { BehaviorSubject } from "rxjs";
import { deleteapiUrl, getapiUrl, postapiUrl } from "../config/apiUrl";
import { DataColumnInterface } from "../interface/Global interface/DataColumnInterface";
import { dataRow } from "../interface/Global interface/TableInterface";

export function UpdateProductionSheetAlert(reqbody:any){
    var promise = new Promise(function (resolve, reject) {
        console.log(JSON.stringify(reqbody));
        fetch(postapiUrl.UpdateSaveAlertConfig, {
                method: 'PUT',
                headers: {
                    'Accept': 'application/json, text/plain',
                    'Content-Type': 'application/json;charset=UTF-8'
                },
                body: JSON.stringify(reqbody),
            }).then(res => {
                if (res.status == 200) {
                    res.json().then(data => { resolve(data); });
                }
                else {
                    reject("");
                }
            }).catch(err => {
                reject(err);
            })
    });
    return promise;
}

export function SaveProductionSheetAlert(reqbody: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(postapiUrl.UpdateSaveAlertConfig, {
            method: 'POST',
            headers: {
                'Accept': 'application/json, text/plain',
                'Content-Type': 'application/json;charset=UTF-8'
            },
            body: JSON.stringify(reqbody),
        }).then(res => {
            if (res.status == 200 || res.status == 201) {
                res.json().then(data => { resolve(data); });
            } else if (res.status == 400) {
                reject("Duplicate Date");
            } else {
                reject("Duplicate Date");
            }
        }).catch(err => {
            reject(err);
        })
    });
    return promise;
}

const searchApply = (data: any, searchFilter: any) => {
    let result = data.filter((item: any) => {
        let rowEffectiveFrom = new Date(item.effectiveFrom);
        let roweffectiveTo = new Date(item.effectiveTo);
        let searcheffectiveFrom = new Date(searchFilter.effectiveFrom?.split('T')[0]+"T00:00:00");
        let searcheffectiveTo = new Date(searchFilter.effectiveTo?.split('T')[0] + "T00:00:00");
        let rowSheetType = item.sheetType;
        let searchedItem = false;

        if (searchFilter.effectiveFrom != null && searchFilter.effectiveTo != null && searchFilter.sheettype.toLowerCase() != "select"
            && searchFilter.sheetName.toLowerCase() == "production") {
            if (rowEffectiveFrom >= searcheffectiveFrom
                && (rowEffectiveFrom < searcheffectiveTo
                    && roweffectiveTo >= searcheffectiveTo)
                && rowSheetType.toLowerCase() == searchFilter.sheettype.toLowerCase() && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom != null && searchFilter.effectiveTo != null && searchFilter.sheettype.toLowerCase() == "select"
            && searchFilter.sheetName.toLowerCase() == "production") {
            if (rowEffectiveFrom >= searcheffectiveFrom
                && (rowEffectiveFrom < searcheffectiveTo
                    && roweffectiveTo >= searcheffectiveTo)
                && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom != null && searchFilter.effectiveTo == null
            && searchFilter.sheettype.toLowerCase() != "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if (rowEffectiveFrom >= searcheffectiveFrom
                && rowSheetType.toLowerCase() == searchFilter.sheettype.toLowerCase() && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom == null && searchFilter.effectiveTo != null
            && searchFilter.sheettype.toLowerCase() != "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if ((rowEffectiveFrom < searcheffectiveTo
                && roweffectiveTo <= searcheffectiveTo)
                && rowSheetType.toLowerCase() == searchFilter.sheettype.toLowerCase() && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom == null && searchFilter.effectiveTo != null
            && searchFilter.sheettype.toLowerCase() == "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if ((rowEffectiveFrom < searcheffectiveTo
                && roweffectiveTo <= searcheffectiveTo)
                && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom == null && searchFilter.effectiveTo == null && searchFilter.sheettype.toLowerCase() != "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if (rowSheetType.toLowerCase() == searchFilter.sheettype.toLowerCase() && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom == null && searchFilter.effectiveTo == null && searchFilter.sheettype.toLowerCase() == "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if (searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        else if (searchFilter.effectiveFrom != null && searchFilter.effectiveTo == null && searchFilter.sheettype.toLowerCase() == "select" && searchFilter.sheetName.toLowerCase() == "production") {
            if (rowEffectiveFrom >= searcheffectiveFrom && searchFilter.sheetName.toLowerCase() == "production") {
                searchedItem = true;
            }
        }
        if (searchedItem) {
            return item;
        }
    });
  return result;
}

export function GetProductionSheetAlertConfigData(searchfilter: any) {
    var promise = new Promise(function (resolve, reject) {
        fetch(getapiUrl.getAlertConfig + searchfilter.sheetName, {
                method: 'get',
                mode: 'cors',
                // headers: new Headers({
                //     'Authorization': 'Bearer ' + token,
                // })
            }).then(res => {
                if (res.status == 200) {
                    res.json().then(data => {
                        let filteredData = searchApply(data, searchfilter);
                        resolve({ tableData: parsedata(filteredData), resultData: filteredData });
                    });
                }
                else {
                  reject();
                }
            }).catch(err => {
                reject(err);
            })
    });
    return promise;
}

export const rowChange$ = new BehaviorSubject<any>(null);
export const rowdelete$ = new BehaviorSubject<any>(null);

export function DeleteProductionSheetAlertConfig(id: number) {
    var promise = new Promise(function (resolve, reject) {
        fetch(deleteapiUrl.deleteAlertConfigRow + id, {
            method: 'Delete',
            mode: 'cors',
            // headers: new Headers({
            //     'Authorization': 'Bearer ' + token,
            // })
        }).then(res => {
            resolve(res.status);
        }).catch(err => {
            reject(err);
        });
    });
    return promise;
}

const btnDelete = (row: any,) => {
    rowdelete$.next(row);
};
 
 const btnEdit = (row: any) => {
     rowChange$.next(row);
 }

const parsedata = (data: any) => {
    let unmodifiedrows = parserowData(data);
    let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
        return {
            dataColumns: parsecolumns(row, index)
        } as dataRow;
    });
    return modifiedrows;
};

const parserowData = (data: any[]) => {
    return data.map((item: any) => {
        return {
            sheetName: item.sheetName,
            createdBy: item.createdBy,
            effectiveFrom: item.effectiveFrom.split('T')[0],
            effectiveTo: item.effectiveTo.split('T')[0],
            sheetType: item.sheetType,
            id: item.id,
            alertTime: item.alertTime,
            alertFrequency: item.flightFrequency === "-1" ? "Day Advance" : "Same Day",
            fromTime: item.fromTime,
            toTime: item.toTime
        } as any;
    })
};

const parsecolumns = (row: any, index: number): DataColumnInterface[] => {
    let columns = [] as DataColumnInterface[];
    columns.push({ text: (index + 1).toString(), action: undefined });
    columns.push({ text: row.effectiveFrom, action: undefined });
    columns.push({ text: row.effectiveTo, action: undefined });
    columns.push({ text: row.sheetType, action: undefined });
    columns.push({ text: row.alertFrequency, action: undefined });
    columns.push({ text: row.alertTime, action: undefined });
    columns.push({ text: row.createdBy, action: undefined });
    if (row.effectiveFrom && row.effectiveTo <= new Date().toISOString().split('T')[0]) {
        columns.push({
            text: null, action: [
                { name: "Edit", icon: <AiOutlineEdit />, type: "icon-Disabled", event: undefined, parameter: { index: index, row: row, status: row.status, message: row.message } },
                { name: "Delete", icon: <AiOutlineDelete />, type: "icon-Disabled", event: undefined, parameter: { index: index, status: row.status, message: row.message, queueid: row.queueid } }
            ]
        });
    }
    else {
        columns.push({
            text: null, action: [
                { name: "Edit", icon: <AiOutlineEdit />, type: "icon", event: btnEdit, parameter: { index: index, id: row.id, effectiveFrom: row.effectiveFrom, effectiveTo: row.effectiveTo, sheetType: row.sheetType, sheetName: row.sheetName, alertTime: row.alertTime, alertFrequency: row.alertFrequency } },
                { name: "Delete ", icon: <AiOutlineDelete />, type: "icon", event: btnDelete, parameter: { index: index, queueid: undefined, id: row.id } },]
        });
    }
    return columns;
}