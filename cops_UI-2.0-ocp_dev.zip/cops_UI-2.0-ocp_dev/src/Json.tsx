export const role = [
    {
        role:'Delhi-admin',
        stationCode:'DEL',
        isActive: true,
    },
    {
        role:'chennai-admin',
        stationCode:'MAA',
        isActive: true,
    },
    {
        role:'bombay-admin',
        stationCode:'BOM',
        isActive: true,
    },
]

