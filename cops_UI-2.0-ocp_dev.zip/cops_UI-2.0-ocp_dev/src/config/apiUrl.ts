import { environment } from "../environments/environment.dev";
const BASE_URL = environment.baseUrl;
const EMAIL_URl = environment.emailServiceURL

export const getapiUrl = {
    getAlertConfig: BASE_URL + '/api/Master/alertconfig?sheetName=',
    getProductionQueueData: BASE_URL + '/api/QueueManagement/productionsheet-bydate?',
    getManufacturingQueueData: BASE_URL + '/api/QueueManagement/manufacturesheet-bydate?',
    getTransitcateringInfo: BASE_URL + '/api/Planning/catering-planning?',
    getFreshCateringdata : BASE_URL + '/api/Planning/catering-planning?',
    createinventory : BASE_URL + '/api/Inventory/createinventory?',
    getEditInvenoryData : BASE_URL + '/api/Inventory/editinventory?'

};

export const postapiUrl = {
    UpdateSaveAlertConfig: BASE_URL + '/api/Master/alertconfig',
};

export const deleteapiUrl = {
    deleteAlertConfigRow: BASE_URL + '/api/Master/alertconfig?Id=',
    deleteProductionSheet: BASE_URL + '/api/QueueManagement/productionsheetdelete?id=',
    deleteManufacturingSheet: BASE_URL + '/api/QueueManagement/manufacturesheetqueue?id=',
    deleteInventory : BASE_URL + '/api/Inventory/deleteinventory?Id='
};

export const sheetTriggerUrl = {
    productionSheet: 'https://productionsheetgenerator-cops2-dev.apps.ocpnonprodcl01.goindigo.in',
    manufacturingsheet: 'https://manufactureinventorygenerator-cops2-dev.apps.ocpnonprodcl01.goindigo.in',
    // /api/Inventory/createinventory?flightDate=${flightDate}&flightGroupId=${groupId}
}

export const sendEmailUrl = {
    productionsheet: EMAIL_URl + '/api/Email/send-productionsheet-email',
    manufacturingsheet: EMAIL_URl + '/api/Email/send-manufacturingsheet-email',
}

export const getqueuestatusUrl = {
    productionsheet: BASE_URL + '/api/QueueManagement/productionsheetpaxmanifest-details',
    manufacturingsheet: BASE_URL + '/api/QueueManagement/manufacturesheetpaxmanifest-details'
}

export const sendQueue = {
    productionsheet: BASE_URL + '/api/QueueManagement/productionsheetqueues',
    manufacturingsheet: BASE_URL + '/api/QueueManagement/manufacturesheetqueue'
}

export const saveexecutiontimeUrl = {
    productionsheet: BASE_URL + '/api/QueueManagement/productionsheet-bytime',
    manufacturingsheet: BASE_URL + '/api/QueueManagement/manufacturesheet-bytime'
}



