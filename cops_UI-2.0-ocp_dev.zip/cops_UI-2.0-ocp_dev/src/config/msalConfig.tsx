export const msalConfig = {
    auth: {
      clientId: "7d088eff-3d1b-416e-8b0b-f27801e7ffaa",
      authority: "https://login.microsoftonline.com/73f2e714-a32e-4697-9449-dffe1df8a5d5", // This is a URL (e.g. https://login.microsoftonline.com/{your tenant ID})
      redirectUri: "http://localhost:3000/",
      postLogoutRedirectUri: "http://localhost:3000/"
    },
    cache: {
      cacheLocation: "sessionStorage", // This configures where your cache will be stored
      storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
    }
  };
  
  // Add scopes here for ID token to be used at Microsoft identity platform endpoints.
  export const loginRequest = {
   scopes: ["openid","api://7d088eff-3d1b-416e-8b0b-f27801e7ffaa/tasks.write"]
  };
  
  // Add the endpoints here for Microsoft Graph API services you'd like to use.
  export const graphConfig = {
      graphMeEndpoint: "Enter_the_Graph_Endpoint_Here/v1.0/me"
  };