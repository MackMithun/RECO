export const environment = {
    production: false,
     baseUrl: 'https://copsdataapi-cops2-dev.apps.ocpnonprodcl01.goindigo.in',
     //baseUrl:'https://localhost:7011',
    emailServiceURL:'https://copsemailservice-cops2-dev.apps.ocpnonprodcl01.goindigo.in',
    productionSheetTriggerURL:'https://productionsheetgenerator-cops2-dev.apps.ocpnonprodcl01.goindigo.in',
    user_key:''
  };
