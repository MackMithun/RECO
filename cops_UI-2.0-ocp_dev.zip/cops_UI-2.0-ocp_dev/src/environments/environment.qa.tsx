export const environment = {
    production: false,
    baseUrl: '',
    emailServiceURL:'',
    productionSheetTriggerURL:'',
    user_key:''
  };