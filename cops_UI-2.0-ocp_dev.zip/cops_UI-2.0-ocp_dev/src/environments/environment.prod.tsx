export const environment = {
    production: true,
    baseUrl: '',
    emailServiceURL:'',
    productionSheetTriggerURL:'',
    user_key:''
  };