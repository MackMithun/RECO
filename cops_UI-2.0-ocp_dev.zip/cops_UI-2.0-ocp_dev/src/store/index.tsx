import { configureStore, createSlice } from "@reduxjs/toolkit";


const authIntialState = {
    username: '',
    isAuthorized : false,
    userRole: '',
}

const authSlice =createSlice({
    name:'auth',
    initialState: authIntialState,
    reducers: {
        isAuthorised(state,action):any {
            console.group(state ,action ,'action')
            state.isAuthorized = action.payload.isAuth ,
            state.username= action.payload.username
        },
        updateUserRole(state,action) :any {
            state.userRole = action.payload
        }    
     }
})

const store = configureStore({
      reducer:authSlice.reducer
})

export default store;

export const authSliceAction = authSlice.actions;