export const GlobalApiNames = {
    catererStation : '/api/ProductionSheet/caterer-station',
    cateterBystationCode:'/api/ProductionSheet/caterer-by-stationcode',
    caterers:'/api/Master/caterers',
    ManufacturingflightDate:'/api/ManufacturingSheet/getflightno',
    getaircrafttype:'/api/ManufacturingSheet/getaircrafttype',
    getterminalbystation:'/api/ManufacturingSheet/getterminalbystation'
}