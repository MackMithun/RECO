import { AlertModal } from "../interface/Models/AlertModal";
import { ManufactureQueueModal } from "../interface/Models/ManufactureQueueModal";
import { ProductionQueueModal } from "../interface/Models/ProductionQueueModal";

export const MapAlertModalProduction = (id: any, fromdate: any, toDate: any, alertFrequencySelected: any, sheetTypeSelected: any, alertTime: any): AlertModal => {
    return {
        id: id,
        sheetType: sheetTypeSelected,
        sheetName: "Production",
        alertTime: alertTime,
        effectiveFrom: fromdate,
        effectiveTo: toDate == null ? "9999-12-31" : toDate,
        fromTime: null,
        toTime: null,
        createdDate: new Date().toISOString(),
        createdBy: "Admin",
        modifiedDate: new Date().toISOString(),
        modifiedBy: "Admin",
        isActive: true,
        flightFrequency: alertFrequencySelected === 'Same Day' ? "0" : "-1"
    } as AlertModal;
}

export const MapAlertModalManufacture = (id: any, fromdate: any, toDate: any, alertFrequencySelected: any, alertTime: any, fromTime: any, toTime: any): AlertModal => {
    return {
        id: id,
        sheetType: "Regular",
        sheetName: "Manufacturing",
        alertTime: alertTime,
        effectiveFrom: fromdate,
        effectiveTo: toDate == null ? "9999-12-31" : toDate,
        fromTime: fromTime,
        toTime: toTime,
        createdDate: new Date().toISOString(),
        createdBy: "Admin",
        modifiedDate: new Date().toISOString(),
        modifiedBy: "Admin",
        isActive: true,
        flightFrequency: alertFrequencySelected === 'Same Day' ? "0" : "-1"
    } as AlertModal;
}

export const TimeValidity = (alertTime: any) => {
    let timevalue = alertTime.split(":");
    if (alertTime.length === 5 && alertTime.includes(':') && alertTime.split(':').length === 2) {

        if (isNaN(parseInt(timevalue[0])) || isNaN(parseInt(timevalue[1]))) {
            return false;
        }

        if (parseInt(timevalue[0]) < 0 || parseInt(timevalue[0]) > 23 || parseInt(timevalue[1]) < 0 || parseInt(timevalue[1]) > 59) {
            return false;
        }
        else {
            return true;
        }

    }
    else {
        return false;
    }
}


export const MapProductionModal = (propsData:any) => {
    return [{
        id: "3fa85f64-5717-4562-b3fc-2c963f66afa5",
        flightDate: propsData.flightDate,
        departure: propsData.station,
        catererCode: propsData.caterer,
        sheetType: propsData.sheetType,
        time: propsData.executionTime,
        message: "Queue Message",
        status: "Yet to start",
        email: true,
        regenerate: true,
        isActive: true,
        createdBy: "Admin",
        createdOn: new Date().toISOString(),
        modifiedBy: "Admin",
        modifiedOn: new Date().toISOString(),
    } as ProductionQueueModal];
}

export const MapManufacturingModal = (propsData:any) => {
    return [{
        id: "3fa85f64-5717-4562-b3fc-2c963f66afa5",
        flightDate: propsData.flightDate,
        departure: propsData.station,
        catererCode: propsData.caterer,
        sheetType: "ManuFacturing",
        executionDateTime: propsData.execTime,
        fromTime: propsData.fromTime,
        toTime: propsData.toTime,
        message: "queue message",
        status: "Yet to start",
        email: true,
        regenerate: true,
        isActive: true,
        createdBy: "Admin",
        createdOn: new Date().toISOString(),
        modifiedBy: "Admin",
        modifiedOn: new Date().toISOString(),
    } as ManufactureQueueModal];
}

export const alwaysTrue = () => {
    
  };


