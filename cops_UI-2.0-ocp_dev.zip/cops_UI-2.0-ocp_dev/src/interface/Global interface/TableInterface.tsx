import { DataColumnInterface } from "./DataColumnInterface";
import { HeaderColumnInterface } from "./HeaderColumnInterface";

export interface TableInterface {
    headerRow: headerRow[],
    dataRow: dataRow[]
}

export interface headerRow {
    headerColumns: HeaderColumnInterface[],
}

export interface dataRow {
    [x: string]: any;
    dataColumns: DataColumnInterface[],
}
export interface dataCellAction {
    name: string;
    icon: any;
    type: string;
    event: any;
    parameter:any | undefined;

}