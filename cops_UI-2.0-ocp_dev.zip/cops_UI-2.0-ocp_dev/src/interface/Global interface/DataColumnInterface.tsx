import { dataCellAction } from "./TableInterface";

export interface DataColumnInterface {
    text : string | number | boolean | null,
    action: dataCellAction[] | undefined
}

