export interface HeaderColumnInterface {
    isLabel : boolean ,
    labelText : string,
    class:string|any
    type:any | undefined
}