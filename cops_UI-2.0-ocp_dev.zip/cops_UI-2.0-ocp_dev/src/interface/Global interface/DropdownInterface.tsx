import { Dropdownitems } from "../supporting Items/Dropdownitems";

export interface DropdownInterface {
    isDropdown : boolean ,
    dropdownValues : Dropdownitems[]
}