export interface Dropdownitems {
    text : string ,
    id : number ,
    value : string | number ,
    defaultselected : string | number
}