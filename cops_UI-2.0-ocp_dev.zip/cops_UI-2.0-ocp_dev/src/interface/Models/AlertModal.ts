import { DateType } from "react-tailwindcss-datepicker"

export interface AlertModal  {
        id: any ,
        sheetType : string | any ,
        sheetName: string | any ,
        alertTime : any ,
        fromTime:any,
        toTime:any,
        effectiveFrom : DateType | undefined | null,
        effectiveTo : DateType | undefined | null ,
        createdDate : any ,
        createdBy : string | any  ,
        modifiedDate : any
        modifiedBy : string | any ,
        isActive : any ,
        flightFrequency : any
}