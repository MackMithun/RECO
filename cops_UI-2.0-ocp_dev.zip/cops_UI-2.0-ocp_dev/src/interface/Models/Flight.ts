export interface Flight {
  ciid: number;
  groupId: number;
  routeNo: number;
  isEditInventory: null | boolean; // Depending on whether it can be boolean or null
  isBHS_Allocated: boolean | undefined | null;
  isCHS_Allocated: boolean | undefined | null;
  isMHS_Allocated: boolean | undefined | null;
  isBHS_InventoryExists: boolean | undefined | null;
  inventoryCreationFlag: boolean | undefined | null;
  flightInfo: FlightInfo[];
  aircraftTypeId: number | undefined | null;
  aircraftType: string | undefined | null;
  aircraftID: number | undefined | null;
  isMHS_Visible: boolean | undefined | null;
  acregid: string | undefined | null;
  userRole: boolean | undefined | null;
  flightType: string | undefined | null;
  stc: any | undefined | null; // Depending on the type
  category: number | undefined | null;
}



export interface FlightInfo {
  txnId: number;
  routeNo: number;
  groupId: number;
  flt_Dt: string;
  dep: string;
  arr: string;
  flt_No: number;
  r_flag: string;
  seqNo: number;
  isTopup: boolean | null; // Update the type if IsTopup can be null
  topuP_SeqNo: number,
  cater_Code: string;
  percentage: number;
  flightType: string;
  masterTemplateId: string | undefined | null;
  itemTemplate: string;
  varMatrixCode: string;
  fixedItemTemplate: string;
  fnbMatrixCode: string;
  ciid: number;
  isAdhoc: boolean;
  isTrash: boolean;
  shortSector: boolean | undefined | null;
  std: string | undefined | null;
  sta: string | undefined | null;
  atd: string | undefined | null;
  inventoryCreationFlag: boolean | undefined | null;
  isBHS_Allocated: boolean | undefined | null;
  isCHS_Allocated: boolean | undefined | null;
  isMHS_Allocated: boolean | undefined | null;
  isBON_Allocated: boolean | undefined | null;
  isBHS_InventoryExists: boolean | undefined | null;
  aircraftTypeId: number;
  aircraftType: string;
  aircraftID: number;
  isMHS_Visible: boolean;
  acregid: string;
  terminal: string | null;
  dept_Term: string | null;
  topupCategory: number | undefined | null;
  deP_Terminal: string | null;
  is_BaseStation: boolean | undefined | null;
  stc: any | undefined | null;
  mhsMatrixCode: string | undefined | null;
  bonMatrixCode: string | null;
  category: number | undefined | null;
}
