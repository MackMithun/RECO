import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AlertconfigView from './pages/Master/AlertconfigView';
import ProductionQueueManagementView from './pages/Queue Management/Production';
import ManufacuringQueueManagementView from './pages/Queue Management/Manufacuring';
import ProductionSheetView from './pages/Alert-Sheets/ProductionSheetView';
import ManufacturingSheetView from './pages/Alert-Sheets/ManufacturingSheetView';
import CartsheetView from './pages/Alert-Sheets/CartSheetView';
import FlightinfoSearchView from './pages/FlightInfo/FlightInfoSearchView';
import Home from './components/Home/Home';
import Pagenotfound from './components/Error/Pagenotfound';
import EditInventory from './components/Inventory/EditInventory';
import ActionItems from './components/Action/ActionItems';
import CartAlocationPage from './pages/FlightInfo/CartAllocationPage';


const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          {/* <Route path="/" element={
            <ProtectedRoute>
              <Home/>
            </ProtectedRoute>
          } > */}
          <Route path="/productionsheet" element={<ProductionSheetView />} />
          <Route path="/Queue_production" element={<ProductionQueueManagementView />} />
          <Route path="/Queue_manufacturing" element={<ManufacuringQueueManagementView />} />
          <Route path="/manufacturingsheet" element={<ManufacturingSheetView />} />
          <Route path="/cartsheet" element={<CartsheetView />} />
          <Route path="/alert" element={<AlertconfigView />} />
          <Route path="/fltinfo" element={<FlightinfoSearchView />} />
          <Route path="/fltinfo/edit" element={<EditInventory />} />
          <Route path='/fltinfo/action' element={<ActionItems />} />
          <Route path="CartAllocation" element={<CartAlocationPage/>} />
          <Route path="*" element={<Pagenotfound />} />
          <Route path="/*" element={<Home />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
