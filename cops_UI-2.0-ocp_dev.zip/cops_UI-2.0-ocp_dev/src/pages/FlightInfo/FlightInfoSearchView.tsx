import React, { useState } from "react";
import Header from '../../components/Header/Header';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import SearchFltInfo from "../../components/Search/SearchFltInfo";
import Footer from '../../components/Footer/Footer';
import TransitCateringTable from '../../components/Table/TrasitCateringTable';
import FreshCateringTable from "../../components/Table/FreshCateringTable";

const FlightInfoSearchView = () => {
  const [freshCateringData, setFreshCateringData] = useState(false);
  const [searchedData, setSearchedData] = useState(null);
  const [transitCateringData, setTransitCateringData] = useState(false);
  const [searchFilterData, setSearchFilterData] = useState({ inputdata: "", type: "" });

  const searchDataHandler = (searchData :any) => {
    setSearchedData(searchData)
    if (searchData.type === 'Transit Catering') {
      setTransitCateringData(true);
      setFreshCateringData(false)
    } else if (searchData.type === 'Fresh Catering') {
      setFreshCateringData(true);
      setTransitCateringData(false);
    }
    else {
      return null;
    }
  }

  const filterDataHandler = (inputData: any, inputType: any) => {
    setSearchFilterData({ inputdata: inputData, type: inputType})
  }

  return (
    <>
      <div className='min-h-screen flex flex-col'>
        <Header />
        <div className='scrollbar-hide flex flex-col'>

          <Breadcrumbs />
          <div className='h-102 w-full overflow-auto scrollbar-hide'>
            <SearchFltInfo flightinfoSearchData={searchDataHandler} onkeypress={filterDataHandler} />

            {freshCateringData && <FreshCateringTable searchData={searchedData} filterData={searchFilterData} />}
            {transitCateringData && <TransitCateringTable searchData={searchedData} />}

          </div>
        </div>
        <Footer />
      </div>
    </>
  );
};

export default FlightInfoSearchView;