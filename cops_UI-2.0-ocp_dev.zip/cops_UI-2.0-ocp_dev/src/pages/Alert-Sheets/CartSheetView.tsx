
import React from 'react';
import Footer from '../../components/Footer/Footer';
import Header from '../../components/Header/Header';
import SearchCart from '../../components/Search/SearchCart';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';

const CartSheetView = () => {
    return (
        <div className='min-h-screen flex flex-col'>
        <Header />
        <div className='ml-3 mt-2'> <Breadcrumbs /></div>
       
        <div className='flex-grow'>
            <SearchCart />
        </div>
        <Footer />
    </div>
    );

}

export default CartSheetView;