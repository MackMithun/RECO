import React, { useEffect, useState } from 'react';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import Footer from '../../components/Footer/Footer';
import Header from '../../components/Header/Header';
import SearchManufacture from '../../components/Search/SearchManufacture';
import ManufactureSheetTable from '../../components/Table/ManufactureSheetTable';
import data from '../../assets/manuafcturingdata.json';
import { environment } from '../../environments/environment.dev';
import Spinner from '../../components/Spinner/Spinner';

const ManufacturingSheetView = () => {
    const [tableData, setTableData] = useState<any>({});
    const [searchData, setsearchData] = useState<any>({});
    const [isLoading, setIsLoading] = useState<boolean | null>(false);
    const [dataFound, setDataFound] = useState<boolean | null>(null);
    const getTableData = () => {
        return data;
    }
    const BASE_URL = environment.baseUrl;
    const setManufactureTable = async (aircraftType: string, caterer: string) => {
        const rawData = getTableData();
        
    }
    const fetchData = async () => {
        if (searchData.fromDate != null || undefined) {
            setIsLoading(true);
            console.log(searchData);
            try {
                setTimeout(async () => {
                    const URL = `${BASE_URL}/api/Inventory/manufacturesheet-bydt?uploadStation=${searchData.stationName}&CatererCode=${searchData.catererName}
                    &fromDate=${searchData.fromDate}&toDate=${searchData.toDate}`;
                    const response = await fetch(URL);
                    if (response.status === 404) {
                        setDataFound(false);
                    } else {
                        const body = await response.json();
                        setTableData(body);
                        setDataFound(true);
                    }
                    setIsLoading(false);
                }, 1000);
            } catch (error) {
                console.error(error);
            }
        }
      }
    useEffect(() => {
        fetchData();
    }, [searchData]);

    const searchDataHandler = (searchData: any) => {
        setsearchData(searchData);
    }
    const GetmanufactureSheetTables = () => {
        return tableData.map((item: any) => {
            return (<ManufactureSheetTable Tableheader={item.tableHeader} tableRowData={item.tableRowData} />);
        })
    }
    return (
        <>
            <div className='min-h-screen flex flex-col max-h-96 overflow-auto scrollbar-hide'>
                <Header />
                <div className='ml-3 mt-2'><Breadcrumbs /></div>
                <div className='flex-grow'>
                    <SearchManufacture searchData={searchDataHandler} />
                </div>
                <div className='mt-5'>
                    {tableData.length > 0 ? GetmanufactureSheetTables() : <></>}
                    {dataFound != null && !dataFound && !isLoading && <h1 className='font-medium text-red-500'>No Data found</h1>}
                </div>
                {isLoading && <Spinner />}
                <Footer />
            </div>
        </>
    )
}

export default ManufacturingSheetView;
