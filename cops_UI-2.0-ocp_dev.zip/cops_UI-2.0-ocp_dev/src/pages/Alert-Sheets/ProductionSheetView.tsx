import React from 'react';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import Footer from '../../components/Footer/Footer';
import Header from '../../components/Header/Header';
import Productionsheet from '../../components/ProductionSheet/Poductionsheet';


const ProductionSheetView = () => {
    return (
        <>
            <div className='min-h-screen flex flex-col'>
                <Header />
                <div className='ml-3 mt-2'> <Breadcrumbs /></div>
               
                <div className='flex-grow'>
                    <Productionsheet />
                </div>
                <Footer />
            </div>
        </>
    )
}

export default ProductionSheetView;