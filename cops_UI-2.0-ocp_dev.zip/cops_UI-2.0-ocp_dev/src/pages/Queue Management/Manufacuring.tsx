import React, { useEffect, useState } from 'react';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import { DataColumnInterface } from '../../interface/Global interface/DataColumnInterface';
import { HeaderColumnInterface } from '../../interface/Global interface/HeaderColumnInterface';
import { dataRow, headerRow } from '../../interface/Global interface/TableInterface';
import SearchQueueManufacture from '../../components/Search/SearchQueueManufacture';
import SimpleTable from '../../components/Table/SimpleTable';
import { AiOutlineDelete, AiOutlineEdit, AiOutlineSave, AiOutlineSync, AiOutlineMail, AiOutlineRedo } from 'react-icons/ai'
import { constants } from '../../components/constants/Queue Management/ManufacturingQueueConstants';
import { ConfirmModal, DeleteModal, InfoModal } from '../../components/Modal/CustomModal';
import QueueModal from '../../components/Modal/QueueMangament/Manufacturing/QueueModal';
import NewQueueModal from '../../components/Modal/QueueMangament/Manufacturing/NewQueueModal';
import Spinner from '../../components/Spinner/Spinner';
import { AddNewQueue, DeleteProductionSheet, emailTrigger, GetManufacturingQueueData, saveExecutiontime, sendRetrigger } from '../../services/ManufacturingQueueService';
import { getQueueStatus } from '../../services/ProductionqueueService';
import { MapManufacturingModal, TimeValidity } from '../../helpers/mapper';

const ManufacuringQueueManagementView = () => {

    const datastyle = constants.dataStyle;
    const headerArray = constants.headerArrayManufacturing;
    const headerstyleindex = constants.headerstyleindexManufacturing;
    const [data, setData] = useState([])
    const [searchQueueData, setsearchQueueData] = useState([]);
    const [actioncolumn, setactioncolumn] = useState(false);
    const [editindex, seteditindex] = useState<number | null>(null);
    const [deleteRowId, setDeleteRowId] = useState<number | null | any>(null);
    const [executiontime, setexecutiontime] = useState<string | undefined>();
    const [emailmessage, setEmailMessage] = useState({ queueid: '', station: '', caterer: '' });
    const [searchData, setsearchData] = useState({ Date: new Date().toISOString().split('T')[0], caterer: 'Select', station: 'Select', AlertTime: '', })
    const [modalisOpen, setModalisOpen] = useState(
        { searchClick: false, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" }
    )
    const [conditions, setConditions] = useState({ isLoading: false, dataFound: false });
    const [toastError, setToastError] = useState<any>("");
    const [info, setinfo] = useState<any>({ isInfo: false,message: "",});

    if (modalisOpen.infoModalIsOpen || modalisOpen.addmodalIsOpen || modalisOpen.queuemodalIsOpen || modalisOpen.deletemodalIsOpen || modalisOpen.reTriggerModalIsOpen || modalisOpen.emailModalIsopen) {
        document.body.style.overflow = 'hidden';
    }
    else {
        document.body.style.overflow = 'auto';
    }

    const fetchData = (searchData: any) => {
        setConditions({ isLoading: true, dataFound: false });
        GetManufacturingQueueData(searchData, 1).then((data: any) => {
            SearchApply(data, searchData);
            setConditions({ isLoading: false, dataFound: true });
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        }).catch(() => {
            setData([]);
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
            setConditions({ isLoading: false, dataFound: false });
        });
    }

    const closeModal = () => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
    };
    const closeInfoModal  = () => {
        setinfo({ isInfo: false, message: "" }); 
    }

    const parseHeaderData = (headerArray: string[]) => {
        return {
            headerColumns: headerArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerstyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const parserowData = (data: any[]) => {
        return data.map((item: any) => {
            return {
                flightdate: item.flightDate.split('T')[0],
                status: item.status,
                sheettype: item.sheetType,
                email: item.email.toString(),
                queueid: item.id,
                executionDateTime: item.executionDateTime,
                stationcode: item.departure,
                catererCode: item.catererCode,
                fromTime: item.fromTime,
                toTime: item.toTime,
                message: item.message
            } as any;
        })
    };

    const parsecolumns = (row: any, index: number): DataColumnInterface[] => {
        let columns = [] as DataColumnInterface[];
        columns.push({ text: row.flightdate, action: undefined });
        columns.push({ text: row.fromTime, action: undefined });
        columns.push({ text: row.toTime, action: undefined });
        columns.push({ text: row.stationcode, action: undefined });
        columns.push({ text: row.catererCode, action: undefined });
        if (editindex != null && editindex == index) {
            columns.push({
                text: null,
                action: [{
                    name: row.executionDateTime,
                    icon: "time",
                    type: "timeinput",
                    event: updatesheetType,
                    parameter: { row: row, index: editindex, queueid: row.queueid, value: row.executionDateTime }
                }]
            });
        } else {
            columns.push({ text: row.executionDateTime, action: undefined });
        }
        columns.push({
            text: null, action: [{
                name: row.status, icon: undefined, type: "link", event: queueStatus, parameter: { index: index, queueid: row.queueid }
            }]
        });
        if ((row.status?.toLowerCase() === "yet to start") || (row.status?.toLowerCase() === "started") || (row.status?.toLowerCase() === "processing")) {
            columns.push({
                text: null, action: [{
                    name: 'Email', icon: <AiOutlineMail />, type: "icon-Disabled", event: undefined, parameter: { index: index, queueid: row.queueid, stationcode: row.stationcode, catererCode: row.caterercode }
                }]
            });
        } else {
            columns.push({
                text: null, action: [{
                    name: 'Email', icon: <AiOutlineMail />, type: "icon", event: btnemailTrigger, parameter: { index: index, queueid: row.queueid, stationcode: row.stationcode, catererCode: row.caterercode }
                }]
            });
        }
        if ((row.status?.toLowerCase() === ("success"))) {
            columns.push({
                text: null, action: [{
                    name: "Regenrate", icon: <AiOutlineSync />, type: "icon-Disabled", event: undefined, parameter: { index: index, status: row.status, message: row.message }
                }]
            });
        } else {
            columns.push({
                text: null, action: [{
                    name: "Regenrate", icon: <AiOutlineSync />, type: "icon", event: btnRetrigger, parameter: { index: index, status: row.status, message: row }
                }]
            });
        }
        if (row.flightdate <= new Date().toISOString().split('T')[0]) {
            columns.push({
                text: null, action: [
                    { name: "Edit", icon: <AiOutlineEdit />, type: "icon-Disabled", event: undefined, parameter: { index: index, row: row, status: row.status, message: row.message, toggle: actioncolumn } },
                    { name: "Delete", icon: <AiOutlineDelete />, type: "icon-Disabled", event: undefined, parameter: { index: index, status: row.status, message: row.message, queueid: row.queueid } }
                ]
            });
        }
        else {
            if (actioncolumn && editindex == index) {
                columns.push({
                    text: null, action: [
                        { name: "Save", icon: <AiOutlineSave />, type: "icon", event: btnSave, parameter: { index: index, status: row.status, row: row, toggle: actioncolumn, value: "" } },
                    ]
                });
            } else {
                columns.push({
                    text: null, action: [
                        { name: "Edit", icon: <AiOutlineEdit />, type: "icon", event: btnEdit, parameter: { index: index, row: row, status: row.status, message: row.message, toggle: actioncolumn } },
                        { name: "Delete", icon: <AiOutlineDelete />, type: "icon", event: btnDelete, parameter: { index: index, status: row.status, message: row.message, queueid: row.queueid } }
                    ]
                });
            }
        }
        return columns;
    }

    const parsedata = () => {
        let unmodifiedrows = parserowData(data);
        let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
            return {
                dataColumns: parsecolumns(row, index)
            } as dataRow;
        });
        return modifiedrows;
    };

    const queueStatus = ({ queueid }: any) => {
        getQueueStatus(queueid).then((data: any) => {
            setsearchQueueData(data)
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: true, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        }).catch(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Awaiting for execution to start." })
        })
    }

    const btnRetrigger = async ({ status, message }: any) => {
        console.log(message)
        console.log(status,"status")
        if (status == 'Failed') {
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: true, emailModalIsopen: false, reTriggerModalIsOpen: true, deletemodalIsOpen: false, message: "" })
        }
        else {
            await handleReTrigger(message)
        };
    }

    const handleReTrigger = (message: any) => {
        const data= {"Id":message.queueid,"fltDate":message.flightdate,"Dep":message.stationcode,"catererCode": message.catererCode,"SheetType": message.sheettype,"SheetName":"","FromTime":message.fromTime,"ToTime":message.toTime}
        sendRetrigger(data).then(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Retirgger started successfully" })
        }).catch((error: any) => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to Retirgger" })
        })
    }

    const btnemailTrigger = ({ queueid, departure, catererCode }: any) => {
        setEmailMessage({ queueid: queueid, station: departure, caterer: catererCode })
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: true, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
    }

    const sendEmail = () => {
        emailTrigger(emailmessage).then(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Email Sent Successfully" })
        }).catch(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to send" })
        })
    };

    const searchDataHandler = (propsdata: any) => {
        if (propsdata.Date != null) {
            setsearchData({ Date: propsdata.Date, caterer: propsdata.caterer, AlertTime: propsdata.AlertTime, station: propsdata.station });
            fetchData(propsdata);
        }
    };

    const SearchApply = (DefaultData: any, searchData: any) => {
        const searchStringDate = searchData.Date ? searchData.Date : '';
        const searchStringStation = searchData.station ? (searchData.station.toLowerCase() === 'select' ? '' : searchData.station.toLowerCase()) : '';
        const searchStringCaterer = searchData.caterer ? (searchData.caterer.toLowerCase() === 'select' ? '' : searchData.caterer.toLowerCase()) : '';
        const searchStringAlertName = searchData.AlertTime ? searchData.AlertTime : '';

        const filteredItems = DefaultData.filter((filterItem: any) => {

            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringStation == '') && (searchStringCaterer == '') && (searchStringAlertName == '')
            ) {
                return filterItem;
            }
            if ((searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringDate == '') && (searchStringCaterer == '') && (searchStringAlertName == '')
            ) {
                return filterItem;
            }
            if ((searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringAlertName == '') && (searchStringDate == '') && (searchStringStation == '')) {
                return filterItem;
            }
            if ((searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringCaterer == '') && (searchStringDate == '') && (searchStringStation == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate
            ) && (searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringCaterer == '') && (searchStringAlertName == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringStation == '') && (searchStringAlertName == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringStation == '') && (searchStringCaterer == '')) {
                return filterItem;
            }
            if ((searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringDate == '') && (searchStringAlertName == '')
            ) {
                return filterItem;
            }
            if ((searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringDate == '') && (searchStringCaterer == '')
            ) {
                return filterItem;
            }
            if ((searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer) &&
                (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringDate == '') && (searchStringStation == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringCaterer == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringStation == '')) {
                return filterItem;
            }
            if ((searchStringDate != '' && filterItem.flightDate.split("T")[0] == searchStringDate)
                && (searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringAlertName == '')) {
                return filterItem;
            }
            if ((searchStringStation != '' && filterItem.departure.toLowerCase() == searchStringStation)
                && (searchStringCaterer != '' && filterItem.catererCode.toLowerCase() == searchStringCaterer)
                && (searchStringAlertName != '' && filterItem.executionDateTime.split(" ")[1] == searchStringAlertName)
                && (searchStringDate == '')) {
                return filterItem;
            }
        });
        if (filteredItems.length > 0) {
            setData(filteredItems);
        }
        else {
            setData([])
        }

    };

    const ClearHandler = () => {
        const currentDate = new Date().toISOString().split('T')[0];
        setsearchData({
            Date: currentDate,
            caterer: 'Select',
            AlertTime: "",
            station: 'Select'
        });
    }

    const btnEdit = (row: any, status: any, message: any, toggle: any) => {
        setactioncolumn(true)
        seteditindex(row.index);
        setexecutiontime(row.row.executionDateTime);
    }

    const btnSave = async (parameter: any) => {
        const time = executiontime?.split(" ")[1]
        if (executiontime !== null && TimeValidity(time)) {
            parameter.row.executiontime = executiontime;
            setactioncolumn(false);
            seteditindex(null);
            saveExecutiontime(parameter).then(() => {
                fetchData(searchData);
                setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Execution time updated succesfully" })
            }).catch(() => {
                setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to save Data" })
            })
        }
        else {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Execution Time is Invalid" })

        }
    }

    const updatesheetType = (value: any) => {
        if (executiontime !== undefined) {
            let updatevalue = executiontime.trim().split(" ")[0] + " " + value;
            setexecutiontime(updatevalue);
        }
        return value;
    }

    const btnDelete = (row: any) => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: true, message: "" })
        setDeleteRowId(row.queueid);
    }

    const AddNewQueueHandler = async (propsdata: any) => {
        setToastError("")
        const { flightDate, station, caterer, fromTime, toTime, execTime } = propsdata;
        const newQueueData = MapManufacturingModal(propsdata);
        try {
            let duplicateDate = false;
            data.map((item: any) => {
                let flightdate = item.flightDate.split('T')[0];
                let dep = item.departure;
                let caterer = item.catererCode;
                let executiontime = item.executionDateTime;
                let fromtime = item.fromTime;
                let totime = item.toTime
                let date: string = (flightDate?.startDate != null && flightDate?.startDate != null) ? flightDate?.startDate.toString() : "";
                if (flightdate === flightDate && dep === station && caterer === caterer && executiontime >= execTime && executiontime <= execTime && fromtime == fromTime && totime == toTime) {
                    duplicateDate = true;
                }
            });
            if (!duplicateDate) {
                AddNewQueue(newQueueData).then((data) => {
                    setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Data Added Successfully" })
                    setConditions({ isLoading: false, dataFound: true });
                    fetchData(searchData);
                }).catch(() => {
                    setToastError("Failed to Add Data");
                })
            }
            else {
                setinfo({ isInfo: true, message: "Duplicate Data found" }); 
            }
        } catch {
            setToastError("Data already exist");
        }
    }

    const addnewDataHandler = () => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: true, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        setToastError("")
    }

    const handleDeleteConfirmation = () => {
        DeleteProductionSheet(deleteRowId).then(() => {
            const newData = [...data];
            newData.splice(deleteRowId, 1);
            fetchData(searchData);
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Deleted Successfully" })
        }).catch((error) => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        });
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        setDeleteRowId(null);
    };

    return (
        <>
            <div className="min-h-screen flex flex-col ">
                <Header />
                <div className='ml-3 mt-2'> <Breadcrumbs /></div>
                <div className='w-full'>
                    <SearchQueueManufacture onSearch={searchDataHandler} onClear={ClearHandler} />
                </div>
                <div className='grid grid-cols-1 w-11/12 mt-2 ml-14 justify-items-end'>
                    {modalisOpen.searchClick && <button className='hover:bg-white bg-green-400 text-white hover:text-black border-2 p-1 w-1/12 mt-2 rounded-md'
                        onClick={addnewDataHandler} >
                        Add new
                    </button>}
                </div>

                {conditions.isLoading && !conditions.dataFound && <Spinner />}

                <div className='w-full flex flex-grow'>
                    {modalisOpen.searchClick && !conditions.isLoading && conditions.dataFound && (
                        <div className='flex-grow w-11/12 mx-14 mt-2 my-auto justify-center items-center'>
                            <SimpleTable tableheader={parseHeaderData(headerArray)}
                                tableData={parsedata()} tdstyle={datastyle} background={'bg-customcolor'} />
                        </div>)}

                    {modalisOpen.searchClick && !conditions.isLoading && !conditions.dataFound && (
                        <h1 className='font-medium mt-10 text-red-500 w-full grid justify-items-center'>
                            No Data found
                        </h1>)}
                </div>
                <Footer />
            </div>

            <QueueModal isOpen={modalisOpen.queuemodalIsOpen} isClose={closeModal} fetchdata={searchQueueData} />
            <NewQueueModal isOpen={modalisOpen.addmodalIsOpen} isClose={closeModal} addNewData={AddNewQueueHandler} toastError={toastError} />
            <ConfirmModal isOpen={modalisOpen.emailModalIsopen} isClose={closeModal} action={sendEmail} message={'Do you want to send Email manually'} icon={<AiOutlineMail />} />
            <ConfirmModal isOpen={modalisOpen.reTriggerModalIsOpen} isClose={closeModal} action={(message: any) => handleReTrigger(message)} icon={<AiOutlineRedo />} message={"Click yes to re-trigger for all the failed flights"} />
            <DeleteModal isOpen={modalisOpen.deletemodalIsOpen} isClose={closeModal} handleDelete={() => handleDeleteConfirmation()} />
            <InfoModal isOpen={modalisOpen.infoModalIsOpen} message={modalisOpen.message} isClose={closeModal} />
            <InfoModal isOpen={info.isInfo} message={info.message} isClose={closeInfoModal} />
        </>
    )
}

export default ManufacuringQueueManagementView;