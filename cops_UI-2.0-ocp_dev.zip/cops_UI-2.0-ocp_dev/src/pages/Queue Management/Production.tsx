import React, { useEffect, useState } from 'react';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import SearchQueueProduction from '../../components/Search/SearchQueueProduction';
import SimpleTable from '../../components/Table/SimpleTable';
import { DataColumnInterface } from '../../interface/Global interface/DataColumnInterface';
import { HeaderColumnInterface } from '../../interface/Global interface/HeaderColumnInterface';
import { dataRow, headerRow } from '../../interface/Global interface/TableInterface';
import { AiOutlineSync, AiOutlineMail, AiOutlineEdit, AiOutlineDelete, AiOutlineSave, AiOutlineRedo } from 'react-icons/ai'
import { constants } from '../../components/constants/Queue Management/ProductionQueueConstants';
import QueueModal from '../../components/Modal/QueueMangament/Production/QueueModal';
import NewQueueModal from '../../components/Modal/QueueMangament/Production/NewQueueModal';
import Spinner from '../../components/Spinner/Spinner';
import { ConfirmModal, DeleteModal, InfoModal } from '../../components/Modal/CustomModal';
import { AddNewQueue, DeleteProductionSheet, emailTrigger, GetProductionQueueData, getQueueStatus, saveExecutiontime, SendRetrigger } from '../../services/ProductionqueueService';
import { MapProductionModal, TimeValidity } from '../../helpers/mapper';
import { ProductionQueueModal } from '../../interface/Models/ProductionQueueModal';
const currentDate = new Date().toISOString().split('T')[0];

const ProductionQueueManagementView = () => {
    const datastyle = constants.dataStyle;
    const headerArray = constants.headerArray;
    const headerstyleindex = constants.headerstyleindex;
    const [data, setData] = useState<any>([])
    const [searchQueueData, setsearchQueueData] = useState([]);
    const [actioncolumn, setactioncolumn] = useState(false);
    const [editindex, seteditindex] = useState<number | null>(null);
    const [executiontime, setexecutiontime] = useState<string | undefined>();
    const [deleteRowId, setDeleteRowId] = useState<number | null | any>(null);
    const [emailmessage, setEmailMessage] = useState({ queuid: '', station: '', caterer: '' });
    const [searchData, setsearchData] = useState({ Date: new Date().toISOString().split('T')[0], caterer: 'Select', sheetType: 'Select', station: 'Select', });
    const [conditions, setConditions] = useState({ isLoading: false, dataFound: false })
    const [retriggerBody, setretriggerBody] = useState({ isLoading: false, dataFound: false })
    const [toastError, setToastError] = useState<any>("");
    const [modalisOpen, setModalisOpen] = useState<any>({
        searchClick: false, infoModalIsOpen: false, isaddmodalIsOpen: false, isqueuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: ""
    })
    const [info, setinfo] = useState<any>({ isInfo: false,message: "",});

    if (modalisOpen.infoModalIsOpen || modalisOpen.addmodalIsOpen || modalisOpen.queuemodalIsOpen || modalisOpen.deletemodalIsOpen || modalisOpen.reTriggerModalIsOpen || modalisOpen.emailModalIsopen) {
        document.body.style.overflow = 'hidden';
    }
    else {
        document.body.style.overflow = 'auto';
    }

    const fetchData = (searchData: any) => {
        setConditions({ isLoading: true, dataFound: false });
        GetProductionQueueData(searchData, 1).then((data) => {
            SearchApply(data, searchData);
            setConditions({ isLoading: false, dataFound: true });
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        }).catch(() => {
            setData([]);
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
            setConditions({ isLoading: false, dataFound: false });
        });
    }


    const parseHeaderData = (headerArray: string[]) => {
        return {
            headerColumns: headerArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerstyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const parserowData = (data: any[]) => {
        return data.map((item: any) => {
            return {
                message: item.message,
                flightdate: item.flightDate.split('T')[0],
                executiondate: item.time.split(' ')[1],
                status: item.status,
                sheetType: item.sheetType,
                email: item.email.toString(),
                queueid: item.id,
                catererCode: item.catererCode,
                departure: item.departure,
                id: item.id,
                isActive: item.isActive,
                regenerate: item.regenerate,
                executiontime: item.time,
            } as any;
        })
    };

    const parsecolumns = (row: any, index: number): DataColumnInterface[] => {
        let columns = [] as DataColumnInterface[];
        columns.push({ text: row.flightdate, action: undefined });
        columns.push({ text: row.departure, action: undefined });
        columns.push({ text: row.catererCode, action: undefined });
        columns.push({ text: row.sheetType, action: undefined })
        if (editindex != null && editindex == index) {
            columns.push({
                text: null,
                action: [{
                    name: row.executiontime,
                    icon: "time",
                    type: "timeinput",
                    event: updatesheetType,
                    parameter: { row: row, index: editindex, queueid: row.queueid, value: row.time }
                }]
            });
        } else {
            columns.push({ text: row.executiontime, action: undefined });
        }
        columns.push({
            text: null, action: [{
                name: row.status, icon: undefined, type: "link", event: queueStatus, parameter: { index: index, queueid: row.queueid }
            }]
        });
        if ((row.status?.toLowerCase() === "yet to start") || (row.status?.toLowerCase() === "started") || (row.status?.toLowerCase() === "processing")) {
            columns.push({
                text: null, action: [{
                    name: 'Email', icon: <AiOutlineMail />, type: "icon-Disabled", event: undefined, parameter: { index: index, queueid: row.queueid, departure: row.departure, catererCode: row.catererCode }
                }]
            });
        } else {
            columns.push({
                text: null, action: [{
                    name: 'Email', icon: <AiOutlineMail />, type: "icon", event: btnemailTrigger, parameter: { index: index, queueid: row.queueid, departure: row.departure, catererCode: row.catererCode }
                }]
            });
        }
        if ((row.status?.toLowerCase() === ("success"))) {
            columns.push({
                text: null, action: [{
                    name: "Regenrate", icon: <AiOutlineSync />, type: "icon-Disabled", event: undefined, parameter: { index: index, status: row.status, message: row.message }
                }]
            })
        }
        else {
            columns.push({
                text: null, action: [{
                    name: "Regenrate", icon: <AiOutlineSync />, type: "icon", event: btnRetrigger, parameter: { index: index, status: row.status, message: row.message }
                }]
            })
        }
        if (row.flightdate <= new Date().toISOString().split('T')[0]) {
            columns.push({
                text: null, action: [
                    { name: "Edit", icon: <AiOutlineEdit />, type: "icon-Disabled", event: undefined, parameter: { index: index, row: row, status: row.status, message: row.message, toggle: actioncolumn } },
                    { name: "Delete", icon: <AiOutlineDelete />, type: "icon-Disabled", event: undefined, parameter: { index: index, status: row.status, message: row.message, queueid: row.queueid } }
                ]
            });
        }
        else {
            if (actioncolumn && editindex === index) {
                columns.push({
                    text: null, action: [
                        { name: "Save", icon: <AiOutlineSave />, type: "icon", event: btnSave, parameter: { index: index, status: row.status, row: row, toggle: actioncolumn, value: "" } },
                    ]
                });
            } else {
                columns.push({
                    text: null, action: [
                        { name: "Edit", icon: <AiOutlineEdit />, type: "icon", event: btnEdit, parameter: { index: index, row: row, status: row.status, message: row.message, toggle: actioncolumn } },
                        { name: "Delete", icon: <AiOutlineDelete />, type: "icon", event: btnDelete, parameter: { index: index, status: row.status, message: row.message, queueid: row.queueid } }
                    ]
                });
            }
        }
        return columns;
    }

    const parsedata = () => {
        let unmodifiedrows = parserowData(data);
        let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
            return {
                dataColumns: parsecolumns(row, index)
            } as dataRow;
        });
        return modifiedrows;
    };

    const btnRetrigger = ({ status, message }: any) => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, isaddmodalIsOpen: false, isqueuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: true, deletemodalIsOpen: false, message: "" })
        setretriggerBody(message);
    }

    const handleReTrigger = () => {
        SendRetrigger(retriggerBody).then(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Retirgger started successfully" })
        }).catch((error) => {
            // console.log(error)
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: true, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to Retirgger" })
        })
    }

    const btnemailTrigger = ({ queueid, departure, catererCode }: any) => {
        setEmailMessage({ queuid: queueid, station: departure, caterer: catererCode })
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: true, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
    }

    const sendEmail = () => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: true, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        emailTrigger(emailmessage).then(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Email Sent Successfully" })
        }).catch(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to send" })
        })
    };

    const btnEdit = (row: any) => {
        setactioncolumn(true)
        seteditindex(row.index);
        setexecutiontime(row.row.executiontime);
    }

    const updatesheetType = (value: any) => {
        if (executiontime !== undefined) {
            let updatevalue = executiontime.trim().split(" ")[0] + " " + value;
            setexecutiontime(updatevalue);
        }
        return value;
    }

    const btnSave = (parameter: any,) => {
        const time = executiontime?.split(" ")[1]
        if (executiontime !== null && TimeValidity(time)) {
            parameter.row.executiontime = executiontime;
            setactioncolumn(false);
            seteditindex(null);
            saveExecutiontime(parameter).then(() => {
                fetchData(searchData);
                setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Execution time updated succesfully" })
            }).catch(() => {
                setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Failed to save Data" })
            })
        }
        else {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Execution Time is Invalid" })
        }
    }

    const searchDataHandler = (propsdata: any) => {
        if (propsdata.Date != null) {
            setsearchData({ Date: propsdata.Date, caterer: propsdata.caterer, sheetType: propsdata.sheetType, station: propsdata.station })
            fetchData(propsdata);
        }
    };

    const SearchApply = (DefaultData: any, searchData: any) => {
        const searchStringDate = searchData.Date ? searchData.Date : '';
        const searchStringStation = searchData.station ? (searchData.station.toLowerCase() === 'select' ? '' : searchData.station.toLowerCase()) : '';
        const searchStringCaterer = searchData.caterer ? (searchData.caterer.toLowerCase() === 'select' ? '' : searchData.caterer.toLowerCase()) : '';
        const searchStringSheetType = searchData.sheetType ? (searchData.sheetType.toLowerCase() === 'select' ? '' : searchData.sheetType.toLowerCase()) : '';

        const filteredItems = DefaultData.filter((filterItem: any) => {

            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringStation === '') && (searchStringCaterer === '') && (searchStringSheetType === '')
            ) {
                return filterItem;
            }
            if ((searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringDate === '') && (searchStringCaterer === '') && (searchStringSheetType === '')
            ) {
                return filterItem;
            }
            if ((searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringSheetType === '') && (searchStringDate === '') && (searchStringStation === '')) {
                return filterItem;
            }
            if ((searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringCaterer === '') && (searchStringDate === '') && (searchStringStation === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate
            ) && (searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringCaterer === '') && (searchStringSheetType === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringStation === '') && (searchStringSheetType === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringStation === '') && (searchStringCaterer === '')) {
                return filterItem;
            }
            if ((searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringDate === '') && (searchStringSheetType === '')
            ) {
                return filterItem;
            }
            if ((searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringDate === '') && (searchStringCaterer === '')
            ) {
                return filterItem;
            }
            if ((searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer) &&
                (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringDate === '') && (searchStringStation === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringCaterer === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringStation === '')) {
                return filterItem;
            }
            if ((searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)
                && (searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringSheetType === '')) {
                return filterItem;
            }
            if ((searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringDate === '')) {
                return filterItem;
            }
            if ((searchStringStation !== '' && filterItem.departure.toLowerCase() === searchStringStation)
                && (searchStringCaterer !== '' && filterItem.catererCode.toLowerCase() === searchStringCaterer)
                && (searchStringSheetType !== '' && filterItem.sheetType.toLowerCase() === searchStringSheetType)
                && (searchStringDate !== '' && filterItem.flightDate.split("T")[0] === searchStringDate)) {
                return filterItem;
            }
        });

        if (filteredItems.length > 0) {
            setData(filteredItems);
        }
        else {
            setData([])
        }
    }

    const ClearHandler = () => {
        setsearchData({ Date: currentDate, caterer: 'Select', sheetType: 'Select', station: 'Select' });
    };

    const queueStatus = ({ queueid }: any) => {
        getQueueStatus(queueid).then((data: any) => {
            setsearchQueueData(data)
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: true, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        }).catch(() => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Awaiting for execution to start." })
        })
    }

    const addNewDataHandler = () => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: true, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        setToastError('')
    }

    const AddNewQueueHandler = (propsData: any) => {
        setToastError("")
        const newQueueData = MapProductionModal(propsData);
        try {
            if (!Duplicate(newQueueData[0])) {
                AddNewQueue(newQueueData).then((data) => {
                    setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Data Added Successfully" })
                    setConditions({ isLoading: false, dataFound: true });
                    fetchData(searchData);
                }).catch(() => {
                    setToastError("Failed to Add Data");
                })
        } else {
            // setToastError("Duplicate data found.");
            setinfo({ isInfo: true, message: "Duplicate Data found" }); 
        }
        } catch {
            setToastError("Data already exist");
        }
    }
    const Duplicate = (newQueueData: ProductionQueueModal) => {
        let duplicate = false;
        data.map((item: any) => {
            let flightdate = item.flightDate.split('T')[0]
            let dep = item.departure;
            let caterer = item.catererCode;
            let executiontime = item.time
            let date: string = (newQueueData.flightDate != null && newQueueData.flightDate != null) ? newQueueData.flightDate.toString() : "";
            let time = newQueueData.time !== null ? newQueueData.time : '';
            // if (flightdate === date && dep === newQueueData.departure && caterer === newQueueData.catererCode && executiontime === newQueueData.time) {
                if (flightdate === date && dep === newQueueData.departure && caterer === newQueueData.catererCode && (executiontime >= time || executiontime<= time )) {
                duplicate = true
            }
        });
        return duplicate;
    }
    const btnDelete = (row: any) => {
        setModalisOpen({searchClick: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: true })
        setDeleteRowId(row.queueid);
    }

    const handleDeleteConfirmation = () => {
        DeleteProductionSheet(deleteRowId).then(() => {
            const newData = [...data];
            newData.splice(deleteRowId, 1);
            fetchData(searchData);
            setModalisOpen({ searchClick: true, infoModalIsOpen: true, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "Deleted Successfully" })
        }).catch((error) => {
            setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        });
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, addmodalIsOpen: false, queuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
        setDeleteRowId(null);
    };

    const closeModal = () => {
        setModalisOpen({ searchClick: true, infoModalIsOpen: false, isaddmodalIsOpen: false, isqueuemodalIsOpen: false, emailModalIsopen: false, reTriggerModalIsOpen: false, deletemodalIsOpen: false, message: "" })
      
    };

    const closeInfoModal  = () => {
        setinfo({ isInfo: false, message: "" }); 
    }

    return (
        <>
            <div className='min-h-screen flex flex-col'>
                <Header />
                <div className='ml-3 mt-2'><Breadcrumbs /></div>
                <div className='w-full'>
                    <SearchQueueProduction onSearch={searchDataHandler} onClear={ClearHandler} />
                </div>
                <div className='grid grid-cols-1 w-11/12 mt-2 ml-14 justify-items-end'>
                    {modalisOpen.searchClick && <button className='hover:bg-white bg-green-400 text-white hover:text-black border-2 p-1 w-1/12 mt-2 rounded-md'
                        onClick={addNewDataHandler} >
                        Add new
                    </button>}
                </div>
                {conditions.isLoading && !conditions.dataFound && <Spinner />}
                <div className='w-full flex flex-grow'>
                    {modalisOpen.searchClick && !conditions.isLoading && conditions.dataFound && (
                        <div className='flex-grow w-11/12 mx-14 mt-2 my-auto justify-center items-center'>
                            <SimpleTable tableheader={parseHeaderData(headerArray)} tableData={parsedata()}
                                tdstyle={datastyle} background={'bg-customcolor'} />
                        </div>)}

                    {modalisOpen.searchClick && !conditions.isLoading && !conditions.dataFound && (
                        <h1 className='font-medium mt-10 text-red-500 w-full grid justify-items-center'>
                            No Data found
                        </h1>)}
                </div>
                <Footer />
            </div>

            <QueueModal isOpen={modalisOpen.queuemodalIsOpen} isClose={closeModal} fetchdata={searchQueueData} />
            <NewQueueModal isOpen={modalisOpen.addmodalIsOpen} isClose={closeModal} addNewData={AddNewQueueHandler} toastError={toastError} />
            <ConfirmModal isOpen={modalisOpen.emailModalIsopen} isClose={closeModal} action={sendEmail} message={'Do you want to send Email manually'} icon={<AiOutlineMail />} />
            <ConfirmModal isOpen={modalisOpen.reTriggerModalIsOpen} isClose={closeModal} action={handleReTrigger} icon={<AiOutlineRedo />} message={"Click yes to re-trigger for all the failed flights"} />
            <DeleteModal isOpen={modalisOpen.deletemodalIsOpen} isClose={closeModal} handleDelete={() => handleDeleteConfirmation()} />
            <InfoModal isOpen={modalisOpen.infoModalIsOpen} message={modalisOpen.message} isClose={closeModal} />
            <InfoModal isOpen={info.isInfo} message={info.message} isClose={closeInfoModal} />
        </>
    )
}

export default ProductionQueueManagementView;