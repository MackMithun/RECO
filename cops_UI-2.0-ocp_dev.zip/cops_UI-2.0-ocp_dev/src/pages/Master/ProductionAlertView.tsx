import React, { useEffect, useState } from 'react';
import { constants } from '../../components/constants/Master/AlertMasterConstant';
import AddProductionModal from '../../components/Modal/alertConfig/AddProductionModal';
import EditProductionModal from '../../components/Modal/alertConfig/EditProductionModal';
import { DeleteModal, InfoModal } from '../../components/Modal/CustomModal';
import Spinner from '../../components/Spinner/Spinner';
import SimpleTable from '../../components/Table/SimpleTable';
import { MapAlertModalProduction } from '../../helpers/mapper';
import { HeaderColumnInterface } from '../../interface/Global interface/HeaderColumnInterface';
import { headerRow } from '../../interface/Global interface/TableInterface';
import { AlertModal } from '../../interface/Models/AlertModal';
import { DeleteProductionSheetAlertConfig, GetProductionSheetAlertConfigData, rowChange$, rowdelete$, SaveProductionSheetAlert, UpdateProductionSheetAlert } from '../../services/alertConfigProduction';

const ProductionAlertView = (props: any) => {

    const headerArray = constants.headerArray;
    const datastyle = constants.datastyle;
    const headerstyleindex = constants.headerstyleindex;
    const [editrow, setEditrow] = useState<any>({});
    const [deletedrow, setdeletedrow] = useState<any>({});
    const [tableData, SettableData] = useState<any>({});
    const [alertConfigData, SetalertConfigData] = useState<any>({});
    const [toastError, setToastError] = useState<any>("");
    const [info, setinfo] = useState<any>({
        isInfo: false,
        message: "",
    });
    const [conditions, setconditions] = useState<any>({
        isLoading: false, dataFound: false,  AddProductionModalIsOpen: false,  EditProductionModalIsOpen: false, isDeleteConfirm: false,
    });
    const [saveClick, setSaveClick] = useState(false);

    if (conditions.AddProductionModalIsOpen || conditions.addmodalIsOpen || conditions.isDeleteConfirm) {
        document.body.style.overflow = 'hidden';
    }
    else {
        document.body.style.overflow = 'auto';
    }

    useEffect(() => {
        rowChange$.subscribe((rowedit: AlertModal) => { 
            if (rowedit != null && editrow != rowedit) {
                setToastError("");
                setEditrow(rowedit);
                setconditions({ isLoading: false, dataFound: true, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: true, }); 
            }
        });

        rowdelete$.subscribe((deleted: any) => {
            if (deleted != null && deleted?.id != "") {
                setdeletedrow(deleted);
                setconditions({ isLoading: false, dataFound: true, AddProductionModalIsOpen: false, isDeleteConfirm: true, EditProductionModalIsOpen: false, });
            }
        });
    }, []);

    useEffect(() => {
        FetchData();
    }, [saveClick, props.searchClick]);

    const FetchData = () => {
        setconditions({ isLoading: true, dataFound: false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
        GetProductionSheetAlertConfigData(props.searchFilter).then((data: any) => {
            SettableData(data.tableData);
            SetalertConfigData(data.resultData);
            setconditions({ isLoading: false, dataFound: data.tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });

        }).catch(() => {
            SettableData([]);
            setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
        });
    }
    const addnewProductionAlertData = () => {
        setToastError('');
        setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: true, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
    }

    const parseHeaderData = (headerArray: string[]) => {
        return {
            headerColumns: headerArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerstyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const SaveNewProductionAlertDataHandler = async (propsdata: any) => {
        const { fromdate, toDate, alertFrequencySelected, sheetTypeSelected, alertTime } = propsdata;
        let reqBody = MapAlertModalProduction(0, fromdate, toDate, alertFrequencySelected, sheetTypeSelected, alertTime);
        try {
            let duplicateData = await duplicateFinder(reqBody); 
            if (!duplicateData.duplicate) {
                await SaveProductionSheetAlert(reqBody); 
                setSaveClick(!saveClick);
                setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
                setinfo({ isInfo: true, message: "Saved Successfully" });
            } else {
                setinfo({ isInfo: true, message: `Duplicate data found in S.No ${duplicateData.duplicateIndex + 1}` });
            }
        } catch (error) {
            setinfo({ isInfo: true, message: "Error" });
        }
    };
    

    const UpdateProductionAlertDataHandler = async (propsData: any) => {
        const { id, fromdate, toDate, alertFrequencySelected, sheetTypeSelected, alertTime } = propsData;
        let reqBody = MapAlertModalProduction(id, fromdate, toDate, alertFrequencySelected, sheetTypeSelected, alertTime);
        try {
            let duplicateData = await duplicateFinder(reqBody); 
            if (!duplicateData.duplicate) {
                await UpdateProductionSheetAlert(reqBody); 
                setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
                setSaveClick(!saveClick);
                setinfo({ isInfo: true, message: "Updated Successfully" });   
            } else {
                setinfo({ isInfo: true, message: `Duplicate data found in S.No ${duplicateData.duplicateIndex + 1}` }); 
            }
        } catch (error) {
            setinfo({ isInfo: true, message: "Error" });       
        }
    };
    
    const DeleteProductionAlertDataHandler = async () => {
        DeleteProductionSheetAlertConfig(deletedrow.id).then((res) => {
            FetchData();
            closeModal();
            setinfo({ isInfo: true, message: "Deleted Successfully" });  
            setconditions({ isLoading: false, dataFound: true, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, }); 
        }).catch((error) => {
            setinfo({ isInfo: true, message: "Error" });  
        });
    };

    const closeModal = () => {
        setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
        setToastError("");     
    };

    const closeInfoModal = () =>{
        setinfo({ isInfo: false, message: "" });  
    }
   
    const duplicateFinder = (reqBody: AlertModal) => {
        if (alertConfigData.length > 0) {
            let duplicateIndex = -1;
            let duplicate = alertConfigData.some((item: any, index: number) => {
                if (editrow.index !== index) {
                    let effectiveFromDate = item.effectiveFrom.split('T')[0];
                    let effectiveToDate = item.effectiveTo.split('T')[0];
                    let startDate: string = (reqBody.effectiveFrom != null && reqBody.effectiveFrom != null) ? reqBody.effectiveFrom.toString() : "";
                    let endDate: string = (reqBody.effectiveTo != null && reqBody.effectiveTo != null) ? reqBody.effectiveTo.toString() : "";
                    let alertTime: string = item.alertTime;
                    if (
                        (startDate <= effectiveToDate && endDate >= effectiveFromDate) &&
                        (alertTime === reqBody.alertTime)
                    ) {
                        duplicateIndex = index;
                        return true;
                    }
                }
                return false;
            });
    
            return { duplicate, duplicateIndex };
        } else {
            return { duplicate: false, duplicateIndex: -1 };
        }
    }
    
    
    
    return (
        <div className='w-full flex flex-col'>
            <div className='grid w-11/12 mt-2 ml-14 justify-items-end'>
                <button className='hover:bg-white bg-green-400 text-white hover:text-black border-2 p-1 w-1/12 mt-2 rounded-md'
                    onClick={addnewProductionAlertData} >
                    Add new
                </button>
            </div>
            {!conditions.isLoading && conditions.dataFound &&
                <div className='flex-grow w-11/12 mx-14 mt-2 my-auto justify-center items-center'>
                    <SimpleTable tableheader={parseHeaderData(headerArray)}
                        tableData={tableData} tdstyle={datastyle} background={'bg-customcolor'}
                    />
                </div>
            }
            {!conditions.dataFound && !conditions.isLoading &&
                <h1 className='font-medium mt-10 text-red-500 w-full grid justify-items-center'>No Data found</h1>}

            <EditProductionModal isOpen={conditions.EditProductionModalIsOpen} isClose={closeModal} saveData={UpdateProductionAlertDataHandler} rowData={editrow} toastError={toastError} />

            <AddProductionModal isOpen={conditions.AddProductionModalIsOpen} isClose={closeModal} saveData={SaveNewProductionAlertDataHandler} toastError={toastError} />

            {conditions.isLoading && <Spinner />}

            {<DeleteModal isOpen={conditions.isDeleteConfirm} handleDelete={DeleteProductionAlertDataHandler} isClose={closeModal} />}

            {<InfoModal isOpen={info.isInfo} message={info.message} isClose={closeInfoModal} />}
        </div>);
}

export default ProductionAlertView;