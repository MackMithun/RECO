import React, { useEffect, useState } from 'react';
import Footer from '../../components/Footer/Footer';
import Header from '../../components/Header/Header';
import Breadcrumbs from '../../components/Breadcrumbs/Breadcrumbs';
import SearchAlert from '../../components/Search/SearchAlert';
import ProductionAlertView from './ProductionAlertView';
import ManufactureAlertView from './ManufactureAlertView';

const AlertconfigView = () => {

    const [searchFilter, setSearchFilter] = useState<any>({});
    const [ps_searchClick, setps_searchClick] = useState<any>(false);
    const SearchDataHandler = (search: any) => {
        setSearchFilter(search);
        setps_searchClick(!ps_searchClick);
    }
    const ClearDataHandler = (clear: any) => {
        setSearchFilter(clear);
        setps_searchClick(!ps_searchClick);
    }
    return (
        <div className='min-h-screen flex flex-col'>
            <Header />
            <div className='ml-3 mt-2'> <Breadcrumbs /></div>
            <div className='w-full'>
                <SearchAlert onSearch={SearchDataHandler}
                    onClear={ClearDataHandler} />
            </div>
            <div className='w-full flex flex-grow'>
                {searchFilter.sheetName?.toLowerCase() === "production" && <ProductionAlertView searchFilter={searchFilter} searchClick={ps_searchClick} />}
                {searchFilter.sheetName?.toLowerCase() === "manufacturing" && <ManufactureAlertView searchFilter={searchFilter} searchClick={ps_searchClick} />}
                {!["production", "manufacturing"].includes(searchFilter.sheetName?.toLowerCase()) && null}
            </div>
                <Footer />
        </div >
    );
};

export default AlertconfigView;