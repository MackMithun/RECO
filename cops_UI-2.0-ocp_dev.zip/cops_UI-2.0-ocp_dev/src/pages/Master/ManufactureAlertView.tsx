import React from "react";
import { useEffect, useState } from "react";
import { constants } from "../../components/constants/Master/AlertMasterConstant";
import AddManufactureModal from "../../components/Modal/alertConfig/AddManufactureModal";
import EditManufactureModal from "../../components/Modal/alertConfig/EditManufactureModal";
import {  DeleteModal, InfoModal } from '../../components/Modal/CustomModal';
import Spinner from "../../components/Spinner/Spinner";
import SimpleTable from "../../components/Table/SimpleTable";
import { MapAlertModalManufacture } from "../../helpers/mapper";
import { HeaderColumnInterface } from "../../interface/Global interface/HeaderColumnInterface";
import { headerRow } from "../../interface/Global interface/TableInterface";
import { AlertModal } from "../../interface/Models/AlertModal";
import { DeleteManufactureSheetAlertConfig, GetManufactureSheetAlertConfigData, rowChange$, rowdelete$, SaveManufacturingSheetAlert, UpdateManufacturingSheetAlert } from "../../services/alertConfigManufacture";

const ManufactureAlertView = (props: any) => {
    const headerArray = constants.headerArrayManufacture;
    const datastyle = constants.datastyle;
    const headerstyleindex = constants.headerstyleindex;
    const [editrow, setEditrow] = useState<any>({});
    const [deletedrow, setdeletedrow] = useState<any>({});
    const [tableData, SettableData] = useState<any>({});
    const [alertConfigData, SetalertConfigData] = useState<any>({});
    const [toastError, setToastError] = useState<any>("");
    const [info, setinfo] = useState<any>({
        isInfo: false,
        message: "",
    });
    const [conditions, setconditions] = useState<any>({
        isLoading: false,
        dataFound: false,
        AddManufactureModalIsOpen: false,
        EditManufactureModalIsOpen: false,
        isDeleteConfirm: false,
    });
    const [saveClick, setSaveClick] = useState(false);

    if (conditions.AddManufactureModalIsOpen || conditions.EditManufactureModalIsOpen || conditions.isDeleteConfirm) {
        document.body.style.overflow = 'hidden';
    }
    else {
        document.body.style.overflow = 'auto';
    }

    useEffect(() => {
        setconditions({ isLoading: false, dataFound: true, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });

        rowChange$.subscribe((rowedit: AlertModal) => {
            if (rowedit != null && editrow != rowedit) {
                setToastError("")
                setEditrow(rowedit);
                setconditions({ isLoading: false, dataFound: true, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: true, });
            }
        });

        rowdelete$.subscribe((deleted: any) => {
            if (deleted != null && deleted?.id != "") {
                setdeletedrow(deleted);
                setconditions({ isLoading: false, dataFound: true, AddManufactureModalIsOpen: false, isDeleteConfirm: true, EditManufactureModalIsOpen: false, });
            }
        });
    }, []);

    useEffect(() => {
        FetchData();
    }, [saveClick, props.searchClick]);

    const FetchData = () => {
        setconditions({ isLoading: true, dataFound: false, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });
        GetManufactureSheetAlertConfigData(props.searchFilter).then((data: any) => {
            SettableData(data.tableData);
            SetalertConfigData(data.resultData);
            setconditions({ isLoading: false, dataFound: data.tableData.length > 0 ? true : false, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });

        }).catch(() => {
            SettableData([]);
            setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });
        });
    }

    const addnewManufactreAlertData = () => {
        setToastError('');
        setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddManufactureModalIsOpen: true, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });
    }

    const parseHeaderData = (headerArray: string[]) => {
        return {
            headerColumns: headerArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerstyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const UpdateManufactureAlertDataHandler = async (propsData: any) => {
        const { id, fromdate, toDate, alertFrequencySelected, alertTime, fromTime, toTime } = propsData;
        let reqBody = MapAlertModalManufacture(id, fromdate, toDate, alertFrequencySelected, alertTime, fromTime, toTime);
        try {
            let duplicateData = await duplicateFinder(reqBody); 
            if (!duplicateData.duplicate) {
                await UpdateManufacturingSheetAlert(reqBody); 
                setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
                setSaveClick(!saveClick);
                setinfo({ isInfo: true, message: "Updated Successfully" });   
            } else {
                setinfo({ isInfo: true, message: `Duplicate data found in S.No ${duplicateData.duplicateIndex + 1}` }); 
            }
        } catch (error) {
            setinfo({ isInfo: true, message: "Error" });       
        }
    };


    const DeleteProductionAlertDataHandler = async () => {
        DeleteManufactureSheetAlertConfig(deletedrow.id).then((res) => {
            FetchData();
            closeModal();
            setinfo({ isInfo: true, message: "Deleted Successfully" });   
        }).catch((error) => {
            setinfo({ isInfo: true, message: "Error" });  
        });
    };

    const closeModal = () => {
        setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddManufactureModalIsOpen: false, isDeleteConfirm: false, EditManufactureModalIsOpen: false, });
    };

    const closeInfoModal = () =>{
        setinfo({ isInfo: false, message: "" });  
    }

    const duplicateFinder = (reqBody: AlertModal) => {
        if (alertConfigData.length > 0) {
            let duplicateIndex = -1;
            let duplicate = alertConfigData.some((item: any, index: number) => {
                if (editrow.index !== index) {
                    let effectiveFromDate = item.effectiveFrom.split('T')[0];
                    let effectiveToDate = item.effectiveTo.split('T')[0];
                    let startDate: string = (reqBody.effectiveFrom != null && reqBody.effectiveFrom != null) ? reqBody.effectiveFrom.toString() : "";
                    let endDate: string = (reqBody.effectiveTo != null && reqBody.effectiveTo != null) ? reqBody.effectiveTo.toString() : "";
                    let alertTime: string = item.alertTime;
                    if (
                        (startDate <= effectiveToDate && endDate >= effectiveFromDate) &&
                        (alertTime === reqBody.alertTime)
                    ) {
                        duplicateIndex = index;
                        return true;
                    }
                }
                return false;
            });
    
            return { duplicate, duplicateIndex };
        } else {
            return { duplicate: false, duplicateIndex: -1 };
        }
    }

    const SaveNewManufactureAlertDataHandler = async (propsdata: any) => {
        const { fromdate, toDate, alertFrequencySelected, alertTime, fromTime, toTime } = propsdata
        let reqBody = MapAlertModalManufacture(0, fromdate, toDate, alertFrequencySelected, alertTime, fromTime, toTime);
        try {
            let duplicateData = await duplicateFinder(reqBody); 
            if (!duplicateData.duplicate) {
                await SaveManufacturingSheetAlert(reqBody); 
                setSaveClick(!saveClick);
                setconditions({ isLoading: false, dataFound: tableData.length > 0 ? true : false, AddProductionModalIsOpen: false, isDeleteConfirm: false, EditProductionModalIsOpen: false, });
                setinfo({ isInfo: true, message: "Saved Successfully" });
            } else {
                setinfo({ isInfo: true, message: `Duplicate data found in S.No ${duplicateData.duplicateIndex + 1}` });
            }
        } catch (error) {
            setinfo({ isInfo: true, message: "Error" });
        }
    };

    return (
        <div className='w-full flex flex-col'>
            <div className='grid w-11/12 mt-2 ml-14 justify-items-end'>
                <button className='hover:bg-white bg-green-400 text-white hover:text-black border-2 p-1 w-1/12 mt-2 rounded-md'
                    onClick={addnewManufactreAlertData} >
                    Add new
                </button>
            </div>
            {!conditions.isLoading && conditions.dataFound &&
                <div className='flex-grow w-11/12 mx-14 mt-2 my-auto justify-center items-center'>
                    <SimpleTable tableheader={parseHeaderData(headerArray)}
                        tableData={tableData} tdstyle={datastyle} background={'bg-customcolor'}
                    />
                </div>
            }
            {!conditions.dataFound && !conditions.isLoading &&
                <h1 className='font-medium mt-10 text-red-500 w-full grid justify-items-center'>No Data found</h1>}

            <EditManufactureModal isOpen={conditions.EditManufactureModalIsOpen} isClose={closeModal} saveData={UpdateManufactureAlertDataHandler} rowData={editrow} toastError={toastError} />

            <AddManufactureModal isOpen={conditions.AddManufactureModalIsOpen} isClose={closeModal} saveData={SaveNewManufactureAlertDataHandler} toastError={toastError} />

            {conditions.isLoading && <Spinner />}

            {<DeleteModal isOpen={conditions.isDeleteConfirm} handleDelete={DeleteProductionAlertDataHandler} isClose={closeModal} />}
          
            {<InfoModal isOpen={info.isInfo} message={info.message} isClose={closeInfoModal} />}
           
        </div>);
}

export default ManufactureAlertView;