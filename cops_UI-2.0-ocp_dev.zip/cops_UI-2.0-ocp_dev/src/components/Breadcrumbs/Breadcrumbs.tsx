import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import useBreadcrumbs from 'use-react-router-breadcrumbs';


const routes = [
  { path: '/', breadcrumb: 'Home' },
  { path: '/alert', breadcrumb: 'Alert Configuration' },
  { path: '/productionsheet', breadcrumb: 'Production Sheet' },
  { path: '/cartsheet', breadcrumb: 'Cart Sheet' },
  { path: '/manufacturingsheet', breadcrumb: 'Manufacturing Sheet' },
  { path: '/Queue_production', breadcrumb: 'Production Queue' },
  { path: '/Queue_manufacturing', breadcrumb: 'Manufacturing Queue' },
  { path: '/fltinfo' ,breadcrumb: 'Flight Info'},
  { path: '/fltinfo/action' ,breadcrumb: 'Action'},
  { path:'/action',breadcrumb: 'Action'}
]

function Breadcrumbs() {
  const breadcrumbs = useBreadcrumbs(routes);
  const location = useLocation()

  return (
    <nav className="m-4">
      {breadcrumbs.map(({ match, breadcrumb }) => (
        <Link 
          key={match.pathname} 
          to={match.pathname}
          className={match.pathname === location.pathname ? "text-gray-600 font-semibold hover:font-bold" : "text-gray-400 hover:font-semibold"}
        > &nbsp;
          {breadcrumb} &gt;
        </Link>
      ))}
    </nav>
  );
}

export default Breadcrumbs;


