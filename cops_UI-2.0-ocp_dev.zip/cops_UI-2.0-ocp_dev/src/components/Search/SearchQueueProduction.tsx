
import React, { useEffect, useState } from 'react';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { SHEET_TYPES } from '../constants/Dropdown/dropdownConstants';
import { CatererStation, Caterers, ByCatererData } from '../../services/api-service';
let currentDate = new Date().toISOString().split('T')[0];

const SearchQueueProduction = (props: any) => {

  const [datepickerCss, setDatepickerCss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2  border border-gray-400  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500" }) });
  const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: null, endDate: null });
  const [stationSelected, setStationSelected] = useState('Select');
  const [catererSelected, setCatererSelected] = useState('Select');
  const [sheetSelected, setSheetSelected] = useState('Select');
  const [allFieldsTouched, setAllFieldsTouched] = useState(false);
  const [stationList, setStationList] = useState([{ station_Code: 'Select', stationID: 0 },]);
  const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);

  const sheetTypeList = SHEET_TYPES;
  const stationData = CatererStation();

  const fetchStationData = () => {
    try {
      setStationList([
        { station_Code: 'Select', stationID: 0 },
        ...stationData.state.post,
      ]);
    } catch (error) {
      console.error(error);
    }
  }

  const CatererByStation = async () => {
    if (stationSelected !== 'Select') {
      const QueryString = `?stationCode=${stationSelected}`
      try {
        const catererData = await ByCatererData(QueryString);
        setCatererList([catererList[0], ...catererData.caterer]);
      } catch (error) {
        console.error(error);
      }
    } else {
      allCatererStation();
    }
  }

  const allCatererStation = async () => {
    try {
      const CatereData = await Caterers();
      setCatererList([catererList[0], ...CatereData]);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    fetchStationData();
    CatererByStation();
  }, [stationData.state, stationSelected, catererSelected]);

  useEffect(() => {
    if (
      flightDate?.startDate !== null) {
      setAllFieldsTouched(true)
    }
    else {
      setAllFieldsTouched(false)
    }
  }, [flightDate?.startDate])


  const searchDataHandler = () => {

    if (allFieldsTouched) {
      const data = {
        Date: flightDate?.startDate,
        sheetType: sheetSelected,
        caterer: catererSelected,
        station: stationSelected
      }
      props.onSearch(data);
    }
  }

  const clearDataHandler = () => {
    props.onClear();
    setStationSelected('Select');
    setCatererSelected('Select');
    setSheetSelected('Select');
    setFlightDate({ startDate: null, endDate: null });
  }

  return (
    <>

      <div className='w-full flex justify-center items-center mt-2'>
        <div className='w-full md:w-10/12 lg:w-11/12 grid md:grid-cols-2 h-32 lg:grid-cols-5 gap-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>
          <div className='md:w-5/6 xl:w-6/6  xl:ml-5 lg:ml-5 lg:mt-5 md:ml-5'>
            <label className='text-black text-sm w-11/12'>Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
            <Datepicker
              value={flightDate}
              onChange={(newValue: any) => setFlightDate(newValue)}
              classNames={datepickerCss}
              useRange={false}
              asSingle={true}
              popoverDirection="down"
              displayFormat={"YYYY-MM-DD"}
              readOnly
            />
          </div>
          <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
            <label className='text-black text-sm w-11/12 '>Departure</label>
            <select
              className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''}`}
              value={stationSelected}
              onChange={(e) => setStationSelected(e.target.value)}
            >
              {stationList !== undefined ? (
                stationList.map((item: any, index: number) => {
                  return (
                    <option
                      value={item.value}
                      disabled={item.disabled}
                      id={item.id}
                      key={index}
                    >
                      {item.station_Code}
                    </option>
                  );
                })
              ) : (
                <></>
              )}
            </select>
          </div>
          <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
            <label className='text-black text-sm w-11/12 '>Caterer</label>
            <select
              className={`form-select  w-full  p-2 font-light bg-white
                                    border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown  ${catererSelected === 'Select' ? 'text-gray-400' : ''} `}
              value={catererSelected}
              onChange={(e) => setCatererSelected(e.target.value)}
            >F
              {catererList.map((item: any, index: number) => (
                <option value={item.cater_Code}
                  id={item.id} key={index}>
                  {item.cater_Code}
                </option>
              ))}
            </select>
          </div>
          <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
            <label className='text-black text-sm w-11/12 '>Sheet Type</label>
            <select
              className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${sheetSelected === 'Select' ? 'text-gray-400' : ''}`}
              value={sheetSelected}
              onChange={(e) => setSheetSelected(e.target.value)}
            >
              {sheetTypeList !== undefined ? (
                sheetTypeList.map((item: any, index: number) => {
                  return (
                    <option
                      value={item.value}
                      disabled={item.disabled}
                      id={item.id}
                      key={index}
                    >
                      {item.value}
                    </option>
                  );
                })
              ) : (
                <></>
              )}
            </select>
          </div>
          <div className='lg:w-11/12 xl:w-11/12 md:w-10/12 md:ml-3 lg:mr-8 xl:mr-8 flex float-right h-10 mt-11 text-md'>
            <button onClick={searchDataHandler} className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  text-white font-semibold rounded-lg
             ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={!allFieldsTouched}>
              Search
            </button>

            <button onClick={clearDataHandler} className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
              Clear
            </button>

          </div>
        </div>
      </div>
    </>
  );
};

export default SearchQueueProduction;
