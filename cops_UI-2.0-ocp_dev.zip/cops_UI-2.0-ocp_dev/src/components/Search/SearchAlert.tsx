
import React, { useEffect, useState } from 'react';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { SHEET_TYPES, SHEET_NAMES_ALERT } from '../constants/Dropdown/dropdownConstants';

const SearchAlert = (props: any) => {
  const sheetTypeList = SHEET_TYPES;
  const sheetNamelist = SHEET_NAMES_ALERT;

  const [fromDate, setFromDate] = useState<any>({ startDate: null, endDate: null });
  const [toDate, setToDate] = useState<any>({ startDate: null, endDate: null });
  const [toMinDate, setToMinDate] = useState<any>({ startDate: null, endDate: null });
  const [sheetTypeSelected, setSheetTypeSelected] = useState('Select');
  const [alertTime, setAlertTime] = useState('');
  const [allFieldsTouched, setAllFieldsTouched] = useState(false);
  const [sheetNameSelected, setSheetNameSelected] = useState('Production');
  const [datepickerCustomCss, setDatepickerCustomCss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2 border border-gray-400 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500"; }), });

  useEffect(() => {
    if (fromDate?.startDate || toDate?.endDate || sheetTypeSelected !== 'Select' || alertTime !== '' || sheetNameSelected !== 'Select') {
      setAllFieldsTouched(true);
    } else {
      setAllFieldsTouched(false);
    }
  }, [sheetTypeSelected, alertTime, fromDate?.startDate, toDate?.endDate, sheetNameSelected]);

  const SearchAlertDataHandler = () => {
    if (allFieldsTouched) {
      const Searchdata = {
        effectiveFrom: fromDate?.startDate,
        effectiveTo: toDate?.endDate,
        sheettype: sheetTypeSelected,
        sheetName: sheetNameSelected,
        AlertTime: alertTime
      };
      props.onSearch(Searchdata);
    }
  };

  const ClearHandler = () => {
    const Searchdata = {
      effectiveFrom: null,
      effectiveTo: null,
      sheettype: 'select',
      sheetName: 'Production',
      AlertTime: ''
    };
    props.onClear(Searchdata);
    setFromDate({ startDate: null, endDate: null });
    setToDate({ startDate: null, endDate: null });
    setAlertTime('');
    setSheetTypeSelected('Select');
    setSheetNameSelected('Production')
  };
   


  return (
    <>

      <div className='w-full flex justify-center items-center mt-2'>
        <div className='w-full md:w-10/12 lg:w-11/12 grid md:grid-cols-2 h-28 lg:grid-cols-5 gap-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>
          <div className='md:w-5/6 xl:w-full xl:ml-5 p-4 lg:ml-5  md:ml-5'>
            <label className='text-black text-sm w-11/12'>Effective from</label>
            <Datepicker
              value={fromDate} 
              onChange={(date: any) => { setFromDate(date); setToDate({ startDate: null, endDate: null }); setToMinDate(date)}}
              classNames={datepickerCustomCss}
              displayFormat={"YYYY-MM-DD"}
              popoverDirection="down"
              useRange={false}
              asSingle={true}
              placeholder="Effective from"
              readOnly
            />
          </div>
          <div className='md:w-5/6 xl:w-full xl:ml-5 p-4 lg:ml-5  md:ml-5'>
            <label className='text-black text-sm w-11/12'>Effective to </label>
            <Datepicker
              value={toDate}
              onChange={(date: any) => { setToDate(date); setToMinDate({ startDate: null, endDate: null }); }}
              classNames={datepickerCustomCss}
              displayFormat={"YYYY-MM-DD"}
              popoverDirection="down"
              useRange={false}
              placeholder="Effective to"
              asSingle={true}
              readOnly
              minDate={new Date(toMinDate?.startDate)}
            />
          </div>
          <div className='md:w-5/6 xl:w-full xl:ml-5 p-4 lg:ml-5  md:ml-5'>
            <label className='text-black text-sm'>Sheet Type</label>
            <select
              className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500   ${sheetTypeSelected === 'Select' ? 'text-gray-400' : ''} ${sheetNameSelected === 'Select' ? 'text-gray-400' : ''} ${ sheetNameSelected ==='Manufacturing' ? 'opacity-50 cursor-not-allowed' : ''}`}
              value={sheetTypeSelected} disabled={sheetNameSelected.toLowerCase() === 'manufacturing' }
              onChange={(e) => setSheetTypeSelected(e.target.value)}
            >
              {sheetTypeList !== undefined
                ? sheetTypeList.map((item: any, index: number) => {
                  return (
                    <option
                      value={item.value}  id={item.value} key={index}
                    >
                      {item.value}
                    </option>
                  );
                }) : <></>
              }
            </select>
          </div>
          <div className='md:w-5/6 xl:w-full xl:ml-5 p-4 lg:ml-5  md:ml-5'>
            <label className='text-black text-sm'>Sheet Name</label>
            <select className={`form-select appearance-none w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500   `}
              value={sheetNameSelected} 
              onChange={(e) => setSheetNameSelected(e.target.value)}
            >
              {sheetNamelist !== undefined
                ? sheetNamelist.map((item: any, index: number) => {
                  return (
                    <option
                      value={item.dep}  disabled={item.disabled} id={item} key={index}
                    >
                      {item.value}
                    </option>
                  );
                }) : <></>
              }
            </select>
          </div>
          <div className='lg:w-10/12 xl:w-10/12 md:w-10/12 md:ml-3 lg:mr-8 xl:mr-8 flex float-right h-10 mt-10 text-md'>
            <button onClick={SearchAlertDataHandler}
              className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  text-white font-semibold rounded-lg 
                             ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={!allFieldsTouched}>
              Search
            </button>
            <button onClick={ClearHandler} className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
              Clear
            </button>
          </div>


        </div>
      </div>
    </>
  );
};


export default SearchAlert;
