
import React, { useEffect, useState } from 'react';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { TimeValidity } from '../../helpers/mapper';
import { ByCatererData, Caterers, CatererStation } from '../../services/api-service';
let currentDate = new Date().toISOString().split('T')[0];

const SearchQueueManufacture = (props: any) => {
    
    const [datepickerCss, setDatepickerCss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2  border border-gray-400  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500" }) });
    const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: null, endDate: null });
    const [stationSelected, setStationSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [alertTime, setAlertTime] = useState("");
    const [errorAlerttime, setErrorAlerttime] = useState(false);
    const [stationList, setStationList] = useState([{ station_Code: 'Select', stationID: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const stationData = CatererStation();

    useEffect(() => {
        fetchStationData();
        CatererByStation();
    }, [stationData.state, stationSelected, catererSelected]);

    useEffect(() => {
        if (
            flightDate?.startDate !== null 
        ) {
            setAllFieldsTouched(true)
        }
        else {
            setAllFieldsTouched(false)
        }
    }, [ flightDate?.startDate, errorAlerttime])

    const fetchStationData = () => {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    const CatererByStation = async () => {
        if (stationSelected !== 'Select') {
            const QueryString = `?stationCode=${stationSelected}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        } else {
            allCatererStation();
        }
    }

    const allCatererStation = async () => {
        try {
            const CatereData = await Caterers();
            setCatererList([catererList[0], ...CatereData]);
        } catch (error) {
            console.error(error);
        }
    }

    const searchDataHandler = () => {

        if (allFieldsTouched) {
            const data = {
                Date: flightDate?.startDate,
                AlertTime: alertTime,
                caterer: catererSelected,
                station: stationSelected
            };
            props.onSearch(data);

        } else {
            setErrorAlerttime(false);
        }
    };

    const clearDataHandler = () => {
        props.onClear();
        setStationSelected('Select');
        setCatererSelected('Select');
        setAlertTime('');
        setFlightDate({ startDate: null, endDate: null });
        setErrorAlerttime(false)
    }

    const validateAlerttime = (e: any) => {
        setErrorAlerttime(false);
        const value = e.target.value;
        if(!TimeValidity(value))
        {
            setErrorAlerttime(true);
        }
        else
        {   
            setErrorAlerttime(false);
        }
    }

    return (
        <div className='w-full flex justify-center items-center mt-2'>
            <div className='w-full md:w-10/12 lg:w-11/12 grid md:grid-cols-2 h-32 lg:grid-cols-5 gap-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>
                <div className='md:w-5/6 xl:w-6/6  xl:ml-5 lg:ml-5 lg:mt-5 md:ml-5'>
                    <label className='text-black text-sm w-11/12'>Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                    <Datepicker
                        value={flightDate}
                        onChange={(newValue: any) => setFlightDate(newValue)}
                        classNames={datepickerCss}
                        useRange={false}
                        asSingle={true}
                        popoverDirection="down"
                        placeholder='Flight date'
                        displayFormat={"YYYY-MM-DD"}
                        readOnly
                    />
                </div>

                <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
                    <label className='text-black text-sm w-11/12 '>Departure</label>
                    <select
                        className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''}`}
                        value={stationSelected}
                        onChange={(e) => setStationSelected(e.target.value)}
                    >
                        {stationList !== undefined ? (
                            stationList.map((item: any, index: number) => {
                                return (
                                    <option
                                        value={item.value}
                                        disabled={item.disabled}
                                        id={item.id}
                                        key={index}
                                    >
                                        {item.station_Code}
                                    </option>
                                );
                            })
                        ) : (
                            <></>
                        )}
                    </select>
                </div>

                <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
                    <label className='text-black text-sm w-11/12 '>Caterer</label>
                    <select
                        className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${catererSelected === 'Select' ? 'text-gray-400' : ''}`}
                        value={catererSelected}
                        onChange={(e) => setCatererSelected(e.target.value)}
                    >
                        {catererList !== undefined ? (
                            catererList.map((item: any, index: number) => {
                                return (
                                    <option
                                        value={item.value}
                                        disabled={item.disabled}
                                        id={item.id}
                                        key={index}
                                    >
                                        {item.cater_Code}
                                    </option>
                                );
                            })
                        ) : (
                            <></>
                        )}
                    </select>
                </div>

                <div className='md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5'>
                    <label className='text-black text-sm w-11/12'>Alert Time</label>
                    <input
                        type="text"
                        className='p-2 text-white-900 border border-gray-400 grid grid-cols-2 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full hover:border-blue-500'
                        placeholder='hh:mm'
                        onBlur={validateAlerttime}
                        onChange={(e) => setAlertTime(e.target.value)}
                        value={alertTime}
                        required
                        maxLength={5}
                    />
                    {errorAlerttime && <span className='text-sm font-sans text-red-700 ml-6'>Valid format <span className='font-sans'>hh:mm</span> </span>}
                </div>

                <div className='lg:w-10/12 xl:w-10/12 md:w-10/12 md:ml-3 lg:mr-8 xl:mr-8 flex float-right h-10 mt-10 '>
                    <button onClick={searchDataHandler} className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6 p-2 mx-0 my-0   text-white font-semibold rounded-lg first-letter: ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`}
                        disabled={!allFieldsTouched}>
                        Search
                    </button>
                    <button onClick={clearDataHandler} className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6 p-2 ml-5   text-white font-semibold rounded-lg'>
                        Clear
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SearchQueueManufacture;
