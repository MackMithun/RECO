import React, { useEffect, useState } from "react";
import Datepicker, { ClassNamesTypeProp, DateValueType, } from "react-tailwindcss-datepicker";
import { environment } from "../../environments/environment.dev";
import { CatererStation } from '../../services/api-service';
import { Input } from "@material-tailwind/react";
import { FLT_TYPES } from "../constants/Dropdown/dropdownConstants";
import { InfoModal } from "../Modal/CustomModal";

let currentDate = new Date().toISOString().split("T")[0];

const SearchFltInfo = (props: any) => {
  const BASE_URL = environment.baseUrl;

  const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: currentDate, endDate: currentDate, });
  const [infoModal, setInfoModal] = useState({ isOpen: false, message: "" })
  const [datepickerCss, setDatepickerCss] = useState<ClassNamesTypeProp>({ input: () => { return "w-full p-2  border border-gray-400  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500"; }, });
  const flightTypeList = FLT_TYPES;
  const [stationSelected, setStationSelected] = useState("Select");
  const [aircraftTypeSelected, setAircraftTypeSelected] = useState(0);
  const [checkboxselected, setCheckboxSelected] = useState("Fresh Catering");
  const [stationList, setStationList] = useState([{ station_Code: "Select", stationID: 0 },]);
  const [aircraftList, setAircraftList] = useState([{ aircraftType: "All", id: 0 },]);
  const [allFieldsTouched, setAllFieldsTouched] = useState(false);
  const [flightTypeSelected, setFlightTypeSelected] = useState('Flight Type');
  const [searchclicked, setSearchclicked] = useState(false);
  const stationData = CatererStation();
  const [departure, setDeparture] = useState("");
  const [flightNumber , setFlightNumber] = useState("");
  const [caterer, setCaterer] = useState("")
  const [routeId, setRouteId] = useState("");

  const fetchStationData = () => {
    try {
      setStationList([
        { station_Code: 'Select', stationID: 0 },
        ...stationData.state.post,
      ]);
    } catch (error) {
      console.error(error);
    }
  }

  async function aircraftType() {
    try {
      const response = await fetch(
        `${BASE_URL}/api/ManufacturingSheet/getaircrafttype`
      );
      const aircraftType = await response.json();
      setAircraftList((actype) => [actype[0], ...aircraftType]);
    } catch (error) {
      console.error(error);
    }
  }

  useEffect(() => {
    if (flightDate?.startDate !== null && stationSelected !== 'Select') {
      setAllFieldsTouched(true);
    } else {
      setAllFieldsTouched(false);
    }
  }, [flightDate, stationSelected]);

  useEffect(() => {
    fetchStationData();
    aircraftType();
  }, [stationData.state]);

  const SearchDataHandler = () => {
    if (allFieldsTouched) {
      setSearchclicked(true);
      const searchData = {
        flightDate: flightDate?.startDate,
        station: stationSelected,
        aircraftType: aircraftTypeSelected,
        type: checkboxselected
      }
      props.flightinfoSearchData(searchData);
    }
    else {
      setInfoModal({ isOpen: true, message: "Please select all mandatory fields." });
    }
  }

  const clearSearchHandler = () => {
    setFlightDate({ startDate: currentDate, endDate: currentDate });
    setStationSelected("Select");
    setAircraftTypeSelected(0);
    setCheckboxSelected("Fresh Catering")
    setSearchclicked(false);
  };

  const handleInputChange = (event: any, InputType: any) => {
    const inputValue = (event.target.value).toUpperCase();
    const regexfortext = /^[A-Z]*$/;
    const regexforNumber = /^[0-9]*$/;
    if (InputType == "Departure") {
      if (regexfortext.test(inputValue)) {
        setDeparture(inputValue);
        props.onkeypress(event.target.value, InputType);
      }
    }
    if(InputType == "Flight Number"){
      if (regexforNumber.test(inputValue)) {
        setFlightNumber(inputValue);
        props.onkeypress(event.target.value, InputType);
      }
    }
    if(InputType == "Caterer"){
      if (regexfortext.test(inputValue)) {
        setCaterer(inputValue);
        props.onkeypress(event.target.value, InputType);
      }
    }
    if(InputType == "Route ID"){
      if (regexforNumber.test(inputValue)) {
        setRouteId(inputValue);
        props.onkeypress(event.target.value, InputType);
      }
    }
      if(InputType == "Flight Type"){
        console.log("hello")
          props.onkeypress(event.target.value, InputType);
    }
  };

  const closeModal = () => {
    setInfoModal({ isOpen: false, message: "" })
  }

  return (
    <>
      <div className="w-full flex justify-center items-center mt-1">
        <div className="w-10/12 h-44  grid grid-cols-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50">
          <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
            <label className="text-black text-sm w-11/12 ">Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
            <Datepicker classNames={datepickerCss} value={flightDate}
              onChange={(date) => setFlightDate(date)} useRange={false}
              asSingle={true} placeholder={"Flight Date"}
              displayFormat={"YYYY-MM-DD"}
              readOnly />
          </div>

          <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
            <label className="text-black text-sm w-11/12 ">Station<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
            <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === "Select" ? "text-gray-400" : ""}`}
              value={stationSelected} onChange={(e) => setStationSelected(e.target.value)}
            >
              {stationList !== undefined ? (
                stationList.map((item: any, index: number) => {
                  return (
                    <option value={item.value} disabled={item.disabled} id={item.id} key={index}>
                      {item.station_Code}
                    </option>
                  );
                })) : (<></>)}
            </select>
          </div>

          <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
            <label className="text-black text-sm w-11/12 ">
              Aircraft Type
            </label>
            <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 }`}
              onChange={(e) => setAircraftTypeSelected(e.target.selectedIndex)} >
              {aircraftList !== undefined ? (
                aircraftList.map((item: any, index: number) => {
                  return (
                    <option value={item.value} disabled={item.disabled} id={item.id} key={index} >
                      {item.aircraftType}
                    </option>
                  );
                })) : (<></>)}
            </select>
          </div>

          <div className="w-8/12 h-2/3 items-center ml-10 mt-5">
            <label className="text-black text-sm w-11/12 ">Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
            <div className="flex items-center mb-2">
              <input
                id="default-radio-1"
                type="radio" value="Fresh Catering"
                checked={checkboxselected === "Fresh Catering"} onChange={(e) => setCheckboxSelected("Fresh Catering")}
                name="default-radio" className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
              />
              <label htmlFor="default-radio-1"
                className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"  >
                Fresh Catering
              </label>
            </div>
            <div className="flex items-center">
              <input
                id="default-radio-2"
                type="radio"
                value="Transit Catering"
                checked={checkboxselected === "Transit Catering"}
                onChange={(e) => setCheckboxSelected("Transit Catering")}
                name="default-radio"
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300"
              />
              <label
                htmlFor="default-radio-2"
                className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"
              >
                Transit Catering
              </label>
            </div>
          </div>

          <div className="lg:w-10/12 xl:w-10/12 md:w-10/12 md:ml-3  flex float-right h-10 mt-10 ">
            <button onClick={SearchDataHandler} className="bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  mx-0 my-0   text-white font-semibold rounded-lg">
              Search
            </button>
            <button onClick={clearSearchHandler} className="bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg" >
              Clear
            </button>
          </div>
          {
            allFieldsTouched && searchclicked && checkboxselected == 'Fresh Catering' && <>
              <div className="md:w-5/6 md:ml-5">
                <label className='text-black text-sm w-11/12'>Departure</label>
                <input
                  placeholder={"Departure"} type="text" value={departure}
                  onChange={(event: any) => handleInputChange(event, "Departure")}
                  className='p-1.5 text-white-900 border border-gray-400 grid grid-cols-2 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full hover:border-blue-500 '
                  maxLength={3} pattern="[A-Za-z]+" />
              </div>

              <div className="md:w-5/6 md:ml-5">
                <label className='text-black text-sm w-11/12'>Flight Number</label>
                <input placeholder={"Flight Number"} type="text" value={flightNumber}
                  className='p-1.5 text-white-900 border border-gray-400 grid grid-cols-2 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full hover:border-blue-500 '
                  onChange={(event: any) => handleInputChange(event, "Flight Number")}
                  maxLength={4}
                />
              </div>

              <div className="md:w-5/6 md:ml-5">
                <label className='text-black text-sm w-11/12'>Caterer</label>
                <input placeholder={"Caterer"} type="text" value={caterer}
                  onChange={(event: any) => handleInputChange(event, "Caterer")}
                  className='p-1.5 text-white-900 border border-gray-400 grid grid-cols-2 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full hover:border-blue-500 '
                  maxLength={4} />
              </div>

              <div className="md:w-5/6 md:ml-5">
                <label className='text-black text-sm w-11/12'>Route ID</label>
                <input placeholder={"Route ID"} type="text" value={routeId}
                  onChange={(event: any) => handleInputChange(event, "Route ID")}
                  className='p-1.5 text-white-900 border border-gray-400 grid grid-cols-2 rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full hover:border-blue-500 '
                  maxLength={3} />
              </div>

              <div className="md:w-5/6 md:ml-5">
                <label className='text-black text-sm w-11/12'>Flight Type</label>
                <select className={`form-select  w-full  p-2  font-normal  bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown  ${flightTypeSelected === 'Flight Type' ? 'text-gray-400' : 'text-black'}  `}
                  onChange={(event: any) => handleInputChange(event, "Flight Type")}
                >
                  {flightTypeList.map((item: any, index: number) => (
                    <option id={item.id} key={index}>
                      {item.value}
                    </option>
                  ))}
                </select>
              </div>
            </>
          }
        </div>
        <InfoModal isOpen={infoModal.isOpen} message={infoModal.message} isClose={closeModal} />
      </div>
    </>
  );
};

export default SearchFltInfo;
