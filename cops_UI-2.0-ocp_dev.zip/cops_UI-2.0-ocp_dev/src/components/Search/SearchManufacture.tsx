import React, { useEffect, useState, useReducer } from "react";
import Datepicker, { ClassNamesTypeProp, DateValueType } from "react-tailwindcss-datepicker";
import 'react-toastify/dist/ReactToastify.css';
import Toast from '../Toast/Toast';
import { CatererStation, ByCatererData, FlightNumber, AircraftType, Terminal } from '../../services/api-service';
import { SHIFT_TYPES, FLIGHT_TYPES, TOPUP, ACTUALEDITED_QUANTITIES } from "../constants/Dropdown/dropdownConstants";
import { InfoModal } from "../Modal/CustomModal";
const currentDate = new Date().toLocaleDateString();

const SearchManufacture = (props: any) => {

    const [stationSelected, setStationSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const [shiftSelected, setShiftSelected] = useState('Select');
    const [flightTypeSelected, setFlightTypeSelected] = useState('Select')
    const [flightnumberSelected, setFlightnumberSelected] = useState('Select');
    const [topupSelected, setTopupSelected] = useState('Select');
    const [aircraftTypeSelected, setAircraftTypeSelected] = useState('Select');
    const [terminalSelected, setTerminalSelected] = useState('Select');
    const [actualQuantitySelected, setActualQuantitySelected] = useState('Select')
    const [checkboxselected, setCheckboxSelected] = useState('Perishable');
    const [toMinDate, setToMinDate] = useState<any>({ startDate: null, endDate: null });
    const [customcss, setcustomcss] = useState<ClassNamesTypeProp>({
        input: (() => { return "w-full p-2  border border-gray-400  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" })
    });
    const [fromDate, setFromDate] = useState<any>({ startDate: currentDate, endDate: currentDate });
    const [toDate, setToDate] = useState<any>({ startDate: currentDate, endDate: currentDate });
    const [aircraftList, setAircraftList] = useState([{ aircraftType: 'Select', id: 0 },])
    const [stationList, setStationList] = useState([{ station_Code: 'Select', stationID: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [flightNumberList, setFlightNumberList] = useState([{ fltno: 'Select', id: 0 },]);
    const [terminalList, setTerminalList] = useState([{ depTerminal: 'Select', id: 0 }]);
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const shiftType = SHIFT_TYPES;
    const flightType = FLIGHT_TYPES;
    const topup = TOPUP;
    const actualeditedQty = ACTUALEDITED_QUANTITIES;

    useEffect(() => {
        if (
            stationSelected !== 'Select' && catererSelected !== 'Select' && shiftSelected !== 'Select' &&
            flightTypeSelected !== 'Select' && fromDate.startDate != null && toDate.startDate != null
        ) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [stationSelected, catererSelected, shiftSelected, flightTypeSelected, fromDate.startDate, toDate.startDate]);

    const SearchDataHandler = async () => {

        if (allFieldsTouched) {
            let shiftValue = '';
            if (shiftSelected === 'All') {
                shiftValue = 'A';
            } else if (shiftSelected === 'Morning') {
                shiftValue = 'M';
            } else if (shiftSelected === 'Evening') {
                shiftValue = 'E';
            }
            const data = {
                stationName: stationSelected,
                catererName: catererSelected,
                shiftType: shiftValue,
                fromDate: fromDate?.startDate,
                toDate: toDate?.endDate,
                flightType: flightTypeSelected === 'Domestic' ? 'D' : 'I',
                flightNumber: flightnumberSelected,
                aircraft: aircraftTypeSelected,
                actualeditedQty: actualQuantitySelected,
                topup: topupSelected,
                perishable: checkboxselected === 'Perishable' ? true : false,
                terminal: terminalSelected
            };
            props.searchData(data);
        }
        else {
            openModal()
        }
    };

    const clearDataHandler = () => {
        setStationSelected('Select');
        setCatererSelected('Select');
        setTopupSelected('Select');
        setFlightnumberSelected('Select');
        setAircraftTypeSelected('Select');
        setActualQuantitySelected('Select');
        setCheckboxSelected('Perishable');
        setShiftSelected('Select');
        setFlightTypeSelected('Select');
        setTerminalSelected('Select');
        setFromDate({ startDate: currentDate, endDate: currentDate });
        setToDate({ startDate: currentDate, endDate: currentDate });
    }

    const stationData = CatererStation();

    function fetchStationData() {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    async function CatererByStation() {
        if (stationSelected !== 'Select') {
            const param = stationSelected
            const QueryString = `?stationCode=${param}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }


    async function flightnumber() {
        if (stationSelected !== 'Select' && catererSelected !== 'Select' && flightTypeSelected !== 'Select') {
            try {
                const flightType = flightTypeSelected === 'Domestic' ? 'd' : 'i';
                const queryString = `?flightDate=${fromDate?.startDate}&dep=${stationSelected}&flightType=${flightType}`
                console.log(queryString);
                const flightNumberBydate = await FlightNumber(queryString);
                const fltdata: any = flightNumberBydate.map((fltno: any) => {
                    return {
                        fltno
                    }
                })
                setFlightNumberList((flightNumberList) => [flightNumberList[0], ...fltdata]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    async function aircraftType() {
        try {
            const aircraftTypeData = await AircraftType();

            setAircraftList((actype) => [actype[0], ...aircraftTypeData]);
        } catch (error) {
            console.error(error);
        }
    }

    async function terminal() {
        if (stationSelected !== 'Select') {
            try {
                const param = stationSelected
                const QueryString = `?depStation=${param}`
                const terminalDto = await Terminal(QueryString);
                setTerminalList((terminalList) => [terminalList[0], ...terminalDto[0].terminalDto]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    const openModal = () => {
        setIsModalOpen(true);
    };
    const closeModal = () => {
        setIsModalOpen(false);
    };

    const isCatererDisabled = stationSelected === 'Select';
    const isTerminalDisabled = stationSelected === 'Select';
    const isFlightnumberDisabled = (flightTypeSelected || stationSelected || catererSelected) === 'Select';

    useEffect(() => {
        if (stationSelected === 'Select') {
            setCatererSelected('Select');
            setFlightnumberSelected('Select');
        }
        fetchStationData();
    }, [stationData.state, stationSelected == "Select"])


    useEffect(() => {
        CatererByStation();
        terminal();
        aircraftType();
    }, [stationSelected]);


    useEffect(() => {
        flightnumber();
    }, [stationSelected, flightTypeSelected, flightnumberSelected]);

    return (
        <>
            <div className='w-full flex justify-center items-center mt-1'>
                <div className='w-11/12 h-64  grid grid-cols-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>

                    <div className='w-10/12 h-2/3 items-center ml-10 mt-2'>
                        <label className='text-black text-sm'>Station<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={stationSelected}
                            onChange={(e) => setStationSelected(e.target.value)}
                            required
                        >
                            {stationList !== undefined
                                ? stationList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.dep}
                                            disabled={item.disabled}
                                            id={item.stationID}
                                            key={index}
                                            className="font-2xl bg-wallpaper"
                                        >
                                            {item.station_Code}
                                        </option>
                                    );
                                })
                                : <></>
                            }
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14  mt-2'>
                        <label className='text-black text-sm'>Caterer<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select  w-full  p-2 font-light bg-white
                                    border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${isCatererDisabled ? 'text-gray-100' : ''} ${catererSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={catererSelected}
                            onChange={(e) => setCatererSelected(e.target.value)}
                            required disabled={isCatererDisabled}
                        >
                            {catererList !== undefined
                                ? catererList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.cater_Code}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.cater_Code}
                                        </option>
                                    );
                                })
                                : <></>
                            }
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14  mt-2'>
                        <label className='text-black text-sm w-11/12 '>Shift Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${shiftSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={shiftSelected}
                            onChange={(e) => setShiftSelected(e.target.value)}
                        >
                            {shiftType !== undefined ? (
                                shiftType.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.value}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 ml-14 items-center mt-2 '>
                        <label className='text-black text-sm w-12/12 ml-2 '>From Date</label>
                        <Datepicker
                            value={fromDate}
                            onChange={(date: any) => { setFromDate(date); setToDate({ startDate: null, endDate: null }); setToMinDate(date) }}
                            classNames={customcss}
                            displayFormat={"YYYY-MM-DD"}
                            asSingle={true}
                            useRange={false}
                            popoverDirection="down"
                            readOnly
                        />
                    </div>

                    <div className='w-9/12 h-2/3 ml-14 items-center  mt-2 '>
                        <label className='text-black text-sm w-12/12 ml-2 '>To Date</label>
                        <Datepicker
                            value={toDate}
                            onChange={(value) => setToDate(value)}
                            classNames={customcss}
                            displayFormat={"YYYY-MM-DD"}
                            asSingle={true}
                            useRange={false}
                            readOnly
                            minDate={new Date(new Date(fromDate?.startDate))}
                        />
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-10'>
                        <label className='text-black text-sm w-11/12 '>Flight Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${flightTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={flightTypeSelected}
                            onChange={(e) => setFlightTypeSelected(e.target.value)}
                        >
                            {flightType !== undefined ? (
                                flightType.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.value}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14'>
                        <label className='text-black text-sm w-11/12 '>Flight Number</label>
                        <select
                            className={`form-select  w-full  p-2 font-light bg-white
                            border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${isFlightnumberDisabled ? 'text-gray-100' : ''} ${flightnumberSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={flightnumberSelected}
                            onChange={(e) => setFlightnumberSelected(e.target.value)}
                            disabled={isFlightnumberDisabled}
                        >
                            {flightNumberList !== undefined ? (
                                flightNumberList.map((item: any, index: number) => {
                                    return (
                                        <option value={item.value} disabled={item.disabled} id={item.id} key={index} >
                                            {item.fltno}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14 '>
                        <label className='text-black text-sm'>Is TopUp<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select className={`form-select  w-full  p-2 font-light bg-white
                            border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  ${topupSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={topupSelected} onChange={(e) => setTopupSelected(e.target.value)}
                        >
                            {topup !== undefined ?
                                topup.map((item: any, index: number) => {
                                    return (
                                        <option value={item.value} disabled={item.disabled} id={item.id} key={index}>{item.value}</option>
                                    );
                                }) : <></>
                            }
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14 '>
                        <label className='text-black text-sm w-11/12 '>Aircraft Type</label>
                        <select
                            className={`form-select  w-full  p-2 font-light bg-white
                        border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  ${aircraftTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={aircraftTypeSelected}
                            onChange={(e) => setAircraftTypeSelected(e.target.value)}
                        >
                            {aircraftList !== undefined ? (
                                aircraftList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.aircraftType}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-9/12 h-1/3 items-center ml-14 '>
                        <label className='text-black text-sm w-11/12 '>Terminal</label>
                        <select
                            className={`form-select  w-full  p-2 font-light bg-white
                            border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${isTerminalDisabled ? 'text-gray-100' : ''} ${terminalSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={terminalSelected}
                            onChange={(e) => setTerminalSelected(e.target.value)}
                            disabled={isTerminalDisabled}
                        >
                            {terminalList !== undefined ? (
                                terminalList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.depTerminal}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-10 '>
                        <label className='text-black text-sm w-11/12 '>Actual/Edited Quantity</label>
                        <select
                            className={`form-select  w-full  p-2 font-light bg-white
                      border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  ${actualQuantitySelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={actualQuantitySelected}
                            onChange={(e) => setActualQuantitySelected(e.target.value)}
                        >
                            {actualeditedQty !== undefined ? (
                                actualeditedQty.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.value}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-14 '>
                        <label className='text-black text-sm w-11/12 '>Type</label>
                        <div className="flex items-center mb-1">
                            <input
                                id="default-radio-1"
                                type="radio"
                                value={checkboxselected}
                                checked
                                name="default-radio"
                                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-400 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                onChange={(e) => setCheckboxSelected('Perishable')}
                            />
                            <label
                                htmlFor="default-radio-1"
                                className="ml-2 text-sm font-medium text-black  dark:text-gray-300"
                            >
                                Perishable
                            </label>
                        </div>
                        <div className="flex items-center">
                            <input
                                id="default-radio-2"
                                type="radio"
                                value={checkboxselected}

                                name="default-radio"
                                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-400 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                onChange={(e) => setCheckboxSelected('Non Perishable')}
                            />
                            <label
                                htmlFor="default-radio-2"
                                className="ml-2 text-sm font-medium text-black  dark:text-gray-300"
                            >
                                Non Perishable
                            </label>
                        </div>
                    </div>

                    <div></div>
                    <div></div>

                    <div className='lg:w-11/12 xl:w-11/12 md:w-10/12 md:ml-3 flex float-right h-10 mt-10 '>
                        <button onClick={SearchDataHandler} className='bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  mx-0 my-0   text-white font-semibold rounded-lg'>
                            Search
                        </button>
                        <button onClick={clearDataHandler} className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
                            Clear
                        </button>
                    </div>
                </div>
            </div>
            <Toast />

            {isModalOpen && <InfoModal isOpen={openModal}
                isClose={closeModal} message={`Please select all mandatory  fields.`} />}
        </>
    )
}


export default SearchManufacture;