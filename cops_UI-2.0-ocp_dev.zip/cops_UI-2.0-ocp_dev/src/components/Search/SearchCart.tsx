import React, { useEffect, useState } from 'react'
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { toast } from 'react-toastify';
import { environment } from '../../environments/environment.dev';
import 'react-toastify/dist/ReactToastify.css';
import Toast from '../Toast/Toast';
import {SHIFT_TYPES , FLIGHT_TYPES} from  '../constants/Dropdown/dropdownConstants';

const currentDate = new Date().toLocaleDateString();

const SearchCart = () => {

    const BASE_URL = environment.baseUrl

    const [stationSelected, setStationSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const [shiftSelected, setShiftSelected] = useState('All');
    const [flightTypeSelected, setFlightTypeSelected] = useState('Select')
    const [flightnumberSelected, setFlightnumberSelected] = useState('Select');
    const [aircraftTypeSelected, setAircraftTypeSelected] = useState('Select');
    const [flightDatevalue, setFlightDatevalue] = useState<DateValueType>({ startDate: currentDate, endDate: currentDate  })
    const [customcss, setcustomcss] = useState<ClassNamesTypeProp>({
        input: (() => { return "w-full p-2  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" })
    });
    const [aircraftList, setAircraftList] = useState([{ aircraftType: 'All', id: 0 },])
    const [stationList, setStationList] = useState([  { station_Code: 'Select', stationID: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [flightNumberList, setFlightNumberList] = useState([ { fltno: 'Select', id: 0 },]);

    const shiftType = SHIFT_TYPES;
    const flightType = FLIGHT_TYPES;


    useEffect(() => {
        fetchStationData();
        CatererByStation();
        flightnumber();       
    }, [stationSelected]);


    useEffect(() => {
        aircraftType();
    },[])

    async function fetchStationData() {
        try {
            const response = await fetch(`${BASE_URL}/api/ProductionSheet/caterer-station`);
            const stationsData = await response.json();
            const uniqueStationCodes = stationsData.reduce((uniqueCodes: any[], station: { station_Code: any; }) => {
                if (!uniqueCodes.includes(station.station_Code)) {
                    uniqueCodes.push(station.station_Code);
                }
                return uniqueCodes;
            }, []);

            const updatedStationList = [
                ...stationList,
                ...uniqueStationCodes.map((code: any) => ({ station_Code: code })),
            ];
            setStationList(updatedStationList);
        } catch (error) {
            console.error(error);
        }
    }

    async function CatererByStation() {
        if (stationSelected !== 'Select') {
            const param = stationSelected
            const QueryString = `?stationCode=${param}`
            try {
                const response = await fetch(`${BASE_URL}/api/ProductionSheet/caterer-by-stationcode${QueryString}`);
                const CatereData = await response.json();
                setCatererList([catererList[0], ...CatereData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    async function flightnumber() {
        if ( stationSelected!=='Select' &&  flightTypeSelected !== 'Select') {
            try {       
            const flightType = flightTypeSelected === 'Domestic' ? 'd' : ''      
            const QueryString = `?flightDate=${"2023-05-05"}&dep=${stationSelected}&flightType=${flightType}`
            console.log(QueryString);
            const response = await fetch(`${BASE_URL}/api/ManufacturingSheet/getflightno${QueryString}`);
            const Flightnumber:any = await response.json();
            const fltdata:any  = Flightnumber.map((fltno:any) => {
                return {
                    fltno
                }
            })
            setFlightNumberList((flightNumberList) => [flightNumberList[0], ...fltdata]);    
        } catch (error) {
            console.error(error);     
    }
}
    }

    async function aircraftType() {
        try {
            const response = await fetch(`${BASE_URL}/api/ManufacturingSheet/getaircrafttype`);
            const aircraftType = await response.json();
            setAircraftList((actype) => [actype[0], ...aircraftType]);
        } catch (error) {
            console.error(error);
        }
    }
    const isCatererDisabled = stationSelected === 'Select';

    const [allFieldsTouched, setAllFieldsTouched] = useState(false);

    useEffect(() => {
        if (
            flightTypeSelected !== 'Select'
        ) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [shiftSelected,flightTypeSelected]);

    const logData = async() => {
    
        if (allFieldsTouched) { 

            const data = {
                stationName: stationSelected,
                catererName: catererSelected,
                shiftType: shiftSelected,
                fromDate:flightDatevalue?.startDate,
                flightType:flightTypeSelected,
                flightNumber: flightnumberSelected,
                aircraft: aircraftTypeSelected,        
            };
            setStationSelected('Select');
            setCatererSelected('Select');
            setFlightnumberSelected('Select');
            setAircraftTypeSelected('Select');
            setShiftSelected('Select');
            setFlightTypeSelected('Select');
        }
        else{
           toast.error("please provide all Mandatory inputs")
        }

    };


    return (
        <>
            <div className='w-full flex justify-center items-center mt-1'>
                <div className='w-9/12 h-52  grid grid-cols-4 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>
                   
                       <div className='w-8/12 h-2/3 items-center ml-10 mt-2'>
                        <label className='text-gray-500 text-sm'>Station</label>
                        <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''}`}
                        value={stationSelected} 
                        onChange={(e) => setStationSelected(e.target.value)} 
                        required
                        >
                            {stationList !== undefined
                                ? stationList.map((item: any, index: number) => {
                                    return (
                                        <option value={item.dep} disabled={item.disabled} id={item.stationID} key={index} 
                                        >
                                            {item.station_Code}
                                        </option>
                                    );}): <></> }
                        </select>
                    </div>

                    <div className='w-8/12 h-2/3 items-center ml-14  mt-2'>
                        <label className='text-gray-500 text-sm'>Caterer</label>
                        <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${catererSelected === 'Select' ? 'text-gray-400' : ''} ${isCatererDisabled ? 'text-gray-100' : ''}`}
                             value={catererSelected}
                            onChange={(e) => setCatererSelected(e.target.value)}
                            required disabled={isCatererDisabled}
                        >
                            {catererList !== undefined
                                ? catererList.map((item: any, index: number) => {
                                    return (
                                        <option value={item.cater_Code} disabled={item.disabled} id={item.id} key={index}
                                        >
                                            {item.cater_Code}
                                        </option>
                                    );
                                }): <></> }
                        </select>
                    </div>

                    <div className='w-8/12 h-2/3 items-center ml-14  mt-2'>
                        <label className='text-gray-500 text-sm w-11/12 '>Shift Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${shiftSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={shiftSelected}
                            onChange={(e) => setShiftSelected(e.target.value)}
                        >
                            {shiftType !== undefined ? (
                                shiftType.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.value}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-8/12 h-2/3 ml-10 mt-2 items-center  '>
                        <label className='text-gray-500 text-sm w-12/12 ml-2 '>Flight Date</label>
                        <Datepicker
                            value={flightDatevalue}
                            onChange={(e) => setFlightDatevalue(e)}
                            classNames={customcss}
                            displayFormat={"YYYY-MM-DD"}
                            asSingle={true}
                            useRange={false}
                            readOnly
                        />
                    </div>


                    <div className='w-8/12 h-2/3 items-center ml-10  '>
                        <label className='text-gray-500 text-sm w-11/12 '>Flight Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${flightTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={flightTypeSelected}
                            onChange={(e) => setFlightTypeSelected(e.target.value)}
                        >
                            {flightType !== undefined ? (
                                flightType.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.value}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-8/12 h-2/3 items-center ml-14 '>
                        <label className='text-gray-500 text-sm w-11/12 '>Flight Number</label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${flightnumberSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={flightnumberSelected}
                            onChange={(e) => setFlightnumberSelected(e.target.value)}
                        >
                            {flightNumberList !== undefined ? (
                                flightNumberList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.fltno}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div className='w-8/12 h-2/3 items-center ml-14 '>
                        <label className='text-gray-500 text-sm w-11/12 '>Aircraft Type</label>
                        <select
                            className='form-select appearance w-full p-2 font-thin text-gray-700 bg-white bg-clip-padding bg-no-repeat border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none'
                            value={aircraftTypeSelected}
                            onChange={(e) => setAircraftTypeSelected(e.target.value)}
                        >
                            {aircraftList !== undefined ? (
                                aircraftList.map((item: any, index: number) => {
                                    return (
                                        <option
                                            value={item.value}
                                            disabled={item.disabled}
                                            id={item.id}
                                            key={index}
                                        >
                                            {item.aircraftType}
                                        </option>
                                    );
                                })
                            ) : (
                                <></>
                            )}
                        </select>
                    </div>

                    <div>
                        <button onClick={logData}
                            className="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-1  ml-10 px-2 h-10 w-4/6 mt-5 rounded-lg">
                            Search
                        </button>
                    </div>

                </div>
            </div>
            <Toast/>
        </>
    )
}


export default SearchCart;