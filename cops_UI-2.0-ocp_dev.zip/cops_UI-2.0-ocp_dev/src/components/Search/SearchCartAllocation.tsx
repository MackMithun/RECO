
import React, { useEffect, useState } from 'react';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { toast } from 'react-toastify';
import { AircraftType, ByCatererData, CatererStation, FlightNumber } from '../../services/api-service';
import SpillCartAddModal from '../Modal/Inventory/SpillCartAddModal';

import Toast from '../Toast/Toast';

const SearchCartAllocation = (props: any) => {
    const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: null, endDate: null });
    const [datepickerCss, setCustomCss] = useState<ClassNamesTypeProp>({
        input: (() => "w-full p-2  border border-solid border-gray-400 rounded-lg focus:border-blue-600 focus:outline-none md:border-width-6/6  md:w-5/6 sm:w-6/6 xl:w-6/6 xl:w-full sm:w-full md:w-full hover:border-blue-600")
    });
    const [stationSelected, setStationSelected] = useState("Select");
    const [aircraftTypeSelected, setAircraftTypeSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const [flightTypeSelected, setFlightTypeSelected] = useState('Select');
    const [flightnumberSelected, setFlightnumberSelected] = useState('Select');
    
    const [stationList, setStationList] = useState([{ station_Code: "Select", stationID: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [aircraftList, setAircraftList] = useState([{ aircraftType: "All", id: 0 },]);
    const [flightNumberList, setFlightNumberList] = useState([{ fltno: 'Select', id: 0 },]);

    const stationData = CatererStation();

    function fetchStationData() {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    async function CatererByStation() {
        if (stationSelected !== 'Select') {
            const param = stationSelected
            const QueryString = `?stationCode=${param}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    async function flightnumber() {
        if (stationSelected !== 'Select' && aircraftTypeSelected !== 'Select') {
            try {
                // const flightNumberBydate = await FlightNumber();
                // const fltdata: any = flightNumberBydate.map((fltno: any) => {
                //     return {
                //         fltno
                //     }
                // })
                // setFlightNumberList((flightNumberList) => [flightNumberList[0], ...fltdata]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    async function aircraftType() {
        try {
            const aircraftTypeData = await AircraftType();
            setAircraftList((actype) => [actype[0], ...aircraftTypeData]);
        } catch (error) {
            console.error(error);
        }
    }

    useEffect(() => {
        fetchStationData();
    }, [stationData.state, stationSelected == "Select"]);

    useEffect(() => {
        CatererByStation();
        flightnumber();
        aircraftType();
    }, [stationSelected]);

    useEffect(() => {
        flightnumber();
    }, [stationSelected, aircraftTypeSelected]);

    const isCatererDisabled = stationSelected === 'Select';
    const isFlightnumberDisabled = aircraftTypeSelected  === 'Select';

    const helpHandler = () => {
        window.location.href = "https://uatz-cops.goindigo.in/CartTracking";
    }

    const searchDatahandler = () => {
        if(flightDate?.startDate !== null && aircraftTypeSelected !=='Select' && stationSelected !=='Select'){
           const data = {
            flightdate: flightDate?.startDate,
            aircrafttype:aircraftTypeSelected ,
            station:stationSelected,
            flightnumber: flightnumberSelected,
            caterer: catererSelected
           }
           console.log(data);
        }
        else{
            toast.error("Please select all mandatory fields")
        }
    }

    const [adhocModelisOpen, setAdhocModelisOpen] = useState(true)
  const closeModal =() => {
    setAdhocModelisOpen(false)
  }

    return (
        <>
            <div className="w-full flex justify-center items-center mt-1">
                <div className="w-10/12 h-44 grid grid-cols-5 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50">
                    <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
                        <label className="text-gray-500 text-sm w-12/12 ">Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <Datepicker
                            classNames={datepickerCss}
                            value={flightDate}
                            onChange={(date: any) => setFlightDate(date)}
                            useRange={false}
                            asSingle={true}
                            placeholder={"Flight Date"}
                            readOnly
                        />
                    </div>

                    <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
                        <label className="text-gray-500 text-sm w-11/12 "> Aircraft Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 }`}
                            onChange={(e) => setAircraftTypeSelected(e.target.value)} value={aircraftTypeSelected}
                        >
                            {aircraftList.map((item: any, index: number) => {
                                return (
                                    <option value={item.value} id={item.id} key={index}>
                                        {item.aircraftType}
                                    </option>
                                ); })}
                           </select>
                    </div>

                    <div className="md:w-5/6 lg:ml-5 lg:mt-5 md:ml-5">
                        <label className="text-gray-500 text-sm w-11/12 ">Station<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === "Select" ? "text-gray-400" : ""}`}
                            value={stationSelected} onChange={(e) => setStationSelected(e.target.value)}
                        >
                            {stationList.map((item: any, index: number) => {
                                return (
                                    <option value={item.value} id={item.id} key={index} >
                                        {item.station_Code}
                                    </option>
                                );
                            })}
                        </select>
                    </div>

                    <div className="md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 mt-5">
                        <label className='text-gray-500 hover:text-gray-700 text-sm'>Caterer</label>
                        <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === "Select" ? "text-gray-400" : ""}`}
                            value={catererSelected} onChange={(e) => setCatererSelected(e.target.value)}
                            disabled={isCatererDisabled}
                        >
                            {catererList.map((item: any, index: number) => (
                                <option value={item.cater_Code} disabled={item.disabled}
                                    id={item.id} key={index}>
                                    {item.cater_Code}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="w-10/12 h-2/3 items-center ml-5 mt-5">
                        <label className='text-gray-500 text-sm w-11/12 '>Flight Number</label>
                        <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${isFlightnumberDisabled ? 'text-gray-100' : ''} ${flightnumberSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={flightnumberSelected} onChange={(e) => setFlightnumberSelected(e.target.value)}
                            disabled={isFlightnumberDisabled}
                        >
                            {flightNumberList.map((item: any, index: number) => {
                                return (
                                    <option value={item.value} disabled={item.disabled} id={item.id} key={index} >
                                        {item.fltno}
                                    </option>
                                )
                            })}
                        </select>
                    </div>
                   
                    <div className="lg:w-6/12 xl:w-6/12 md:w-10/12 ml-3 flex float-right h-10 mt-5 ">
                        <button onClick={helpHandler} className="bg-gray-400 hover:bg-blue-gray-800 hover:text-white border-2 w-5/6 ml-2  mx-0 my-0   text-black font-semibold rounded-lg">
                            help
                        </button>
                    </div>
                    <div></div>
                    <div></div>
                    <div></div>

                    <div className="lg:w-11/12 xl:w-11/12 md:w-10/12 ml-3 flex float-right h-10 mt-5 ">
                        <button onClick={searchDatahandler} className="bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6 ml-2  mx-0 my-0   text-white font-semibold rounded-lg">
                            Search
                        </button>
                        <button className="bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg">
                            Clear
                        </button>
                    </div>
                </div>
                <Toast />
            </div>
           
           {/* <AdhocModal  isOpen={adhocModelisOpen} isClose={closeModal} /> */}
           <SpillCartAddModal  isOpen={adhocModelisOpen} isClose={closeModal} />
 
        </>
    );
}

export default SearchCartAllocation;
