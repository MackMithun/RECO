import { SetStateAction, useState } from "react";
import Datepicker, { ClassNamesTypeProp, DateValueType } from "react-tailwindcss-datepicker";
import { Navigate, useNavigate } from "react-router";
import React from 'react';



export function SearchbarVertical(props: any) {

  // const navigate = useNavigate();

  const [value, setValue] = useState<DateValueType>({
    startDate: null,
    endDate: null
  });

  const [customcss, secustomcss] = useState<ClassNamesTypeProp>({
    input: (() => { return "w-full p-2 border rounded-lg " })
  });


  const handleValueChange = (newValue: any) => {
    setValue(newValue);
  }

  const [Stationselected, setStationSelected] = useState('Station');
  const [sidesearchbar, setsidesearchbar] = useState(true);
  const [aircraftTypeSelected, setaircraftTypeSelected] = useState('Aircraft Type');
  const [flightTypeSelected, setflightTypeSelected] = useState('FlightType');


  const stationHandleChange = (event: any) => {
    console.log(event.target.value);
    setStationSelected(event.target.value);
  };



  const SubmitHandler = () => {
    // props.onSearchClicked("clicked from horizontal");
      console.log("Hello")
  }


  const aircraftHandleChange = (event: any) => {
    console.log(event.target.value);
    setaircraftTypeSelected(event.target.value);
  };





  const stationName = [
    { value: 'Station', disabled: true },
    { value: 'ALL', id: 0 },
    { value: 'MAA', id: 1 },
    { value: 'DEL', id: 2 },
    { value: 'BOM', id: 3 },
    { value: 'BLR', id: 1 },
  ]


  const AircraftType = [
    { value: 'Aircraft Type', disabled: true },
    { value: 'ALL', id: 0 },
    { value: '320', id: 1 },
    { value: '321', id: 2 },
    { value: 'ATR', id: 3 },
  ]

  const FlightType = [
    { value: 'FlightType', disabled: true },
    { value: 'Domestic', id: 0 },
    { value: 'International', id: 1 }
  ]

  const flightTypeHandleChange = (event: any) => {
    console.log(event.target.value);
    setflightTypeSelected(event.target.value);
  }


  return (
    <>
   
      <div className="bg-white h-4/6 ml-3" >
        <div className="border grid grid-rows-6 bg-white-300 w-52  rounded-lg m-1 p-8 justify-between ">
          {/* Radio */}
          <div className="ml-1">
            <div className="flex items-center mb-2">
              <input
                id="default-radio-1"
                type="radio"
                value=""
                name="default-radio"
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label
                htmlFor="default-radio-1"
                className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"
              >
                Fresh Catering
              </label>
            </div>
            <div className="flex items-center">
              <input
                id="default-radio-2"
                type="radio"
                value=""
                name="default-radio"
                className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label
                htmlFor="default-radio-2"
                className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"
              >
                Transit Catering
              </label>
            </div>
          </div>

          {/* DatePicker */}
          <div className="flex items-center h-8 mt-4 mr-4 w-36">
            <Datepicker classNames={customcss} readOnly value={value} onChange={handleValueChange} useRange={false} asSingle={true} placeholder={"Flight Date"} />
          </div>


          {/* Station */}
          <div className="flex items-center mt-0.5">
            <div className="w-36 h-13 grid items-center text-sm text-center justify-items-center">
              <select className="form-select appearance w-full mt-1 p-2 text-sm font-normal text-gray-700  bg-white bg-clip-padding bg-no-repeat 
                    border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" aria-label="Default select example"
                value={Stationselected} onChange={stationHandleChange}
              >
                {stationName !== undefined ?
                  stationName.map((item: any, index: number) => {
                    return (
                      <option value={item.value} disabled={item.disabled} id={item.id} key={index}>{item.value}</option>
                    );
                  }) : <></>
                }
              </select>
            </div>
          </div>

          {/* flighttype */}
          <div className="flex items-center mt--1">
            <div className="w-36 h-13 grid items-center text-sm text-center justify-items-center">
              <select className="form-select appearance w-full mt-1 p-2 text-sm font-normal text-gray-700  bg-white bg-clip-padding bg-no-repeat 
                    border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" aria-label="Default select example"
                value={aircraftTypeSelected} onChange={aircraftHandleChange}
              >
                {AircraftType !== undefined ?
                  AircraftType.map((item: any, index: number) => {
                    return (
                      <option value={item.value} disabled={item.disabled} id={item.id} key={index}>{item.value}</option>
                    );
                  }) : <></>
                }
              </select>
            </div>
          </div>

          {/* SearchFilters */}

          <input type="text" id="small-input" className="block w-36 p-2 h-10 mt-5 text-white-900 border border-gray-300 rounded-lg bg-white sm:text-xs focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Depature" />

          <input type="text" id="small-input" className="block w-36 p-2 h-10 mt-5 text-white-900 border border-gray-300 rounded-lg bg-white sm:text-xs focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Flight NO." />

          <input type="text" id="small-input" className="block w-36 p-2 h-10 mt-5 text-white-900 border border-gray-300 rounded-lg bg-white sm:text-xs focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Caterer" />

          <input type="text" id="small-input" className="block w-36 p-2 h-10 mt-5 text-white-900 border border-gray-300 rounded-lg bg-white sm:text-xs focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Flight Type" />

          <input type="text" id="small-input" className="block w-36 p-2 h-10 mt-5 text-white-900 border border-gray-300 rounded-lg bg-white sm:text-xs focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Route ID" />


          <div className="flex items-center mt-6">
            <div className="w-36 h-13 grid items-center text-sm text-center justify-items-center">

              <select  className="form-select appearance w-full mt-1 p-2 text-sm font-normal text-gray-700  bg-white bg-clip-padding bg-no-repeat 

                    border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" aria-label="Default select example"
                value={flightTypeSelected} onChange={flightTypeHandleChange}
              >
                {FlightType !== undefined ?
                  FlightType.map((item: any, index: number) => {
                    return (
                      <option value={item.value} disabled={item.disabled} id={item.id} key={index}>{item.value}</option>
                    );
                  }) : <></>
                }
              </select>
            </div>
          </div>


          {/* Buttons */}
          <div >
            <button onClick={SubmitHandler}
              className="bg-indigo-500 hover:bg-indigo-700 text-white font-bold py-1  px-8 ml-2 mt-5 h-10 w-32 rounded-full">
              Search
            </button>


          </div>
          <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-8 mt-2 ml-2 h-10 w-32  rounded-full">
            Clear
          </button>

        </div>


      </div>

    
    </>

  );
}
