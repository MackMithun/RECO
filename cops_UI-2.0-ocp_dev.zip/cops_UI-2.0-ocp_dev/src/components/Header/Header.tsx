import React, { useEffect, useState } from 'react';
import { useMsal } from '@azure/msal-react';
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router';
import logo from '../../assets/images/logo.png';
import { AiOutlineMenu } from 'react-icons/ai';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import { Link } from 'react-router-dom';
import { loginRequest, msalConfig } from '../../config/msalConfig';
import store from '../../store';
import {authSliceAction} from '../../store/index';

const Header = () => {
  const [showMenu, setShowMenu] = useState(true);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const navigate = useNavigate();
  // //  const dispatch = useDispatch();
  // const { instance } = useMsal();
  const [loggedIn, setloggedIn] = useState(false);
  const [ssologin, setssologin] = useState(false);
  const [show, setshow] = useState(false);
  const [cssclassname, setcssclassname] = useState('hidden');
 
  // const username = useSelector((state:any)=>state.username)
 
  // const { isAuthorised } = authSliceAction;
  // const loginclickhandler = () => {
  //   console.log("hi");
  //   // instance.loginPopup(loginRequest).then(res => {
  //   //   console.log(res,'res')
  //   //   //dispatch(isAuthorised({username:res?.account.username,isAuth:true}))
  //   // }).catch(err => console.log(err));
  // }

  // const logoutclickhandler = () => {
  //   dispatch(updateusername(''));
  //   instance.logoutRedirect({ postLogoutRedirectUri: msalConfig.auth.postLogoutRedirectUri }).catch(err => { console.log(err) });
  // }

  // const logoutclickhandler = () => {}

  // useEffect(() => {
  //    let storedvalue = store.getState().login;
  //   if (storedvalue.username != '') {
  //     setloggedIn(true);
  //     navigate('/Menu/AuthScreen')
  //   }
  // }, [ssologin]);


  const ToggleHandler = () => {
    if (showMenu) {
      setShowMenu(false);
      setModalIsOpen(true);
    } else {
      setShowMenu(true);
      closemodal();
    }
  }

  const closemodal = () => {
    setModalIsOpen(false);
    setShowMenu(true);
  }

  return (
    <>
      <header className="bg-customcolor py-2 px-2 w-full">
        <div className="flex justify-start ">
          <img src={logo} alt="catering Automation" />

          {showMenu && (
            <button onClick={ToggleHandler} className="text-light-blue-900 text-3xl font-thin">
              <AiOutlineMenu />
            </button>
          )}
          {!showMenu && (
            <button onClick={ToggleHandler} className="text-light-blue-900 font-thin text-3xl">
              <AiOutlineClose />
            </button>
          )}
            {/* <div className='min-h-full w-64 grid grid-cols-3 gap-3 justify-items-center items-center'>
              {loggedIn ?
                  <div className='w-24 h-8 rounded-md grid justify-items-end'>
                    <h2 className='text-center m-1 cursor-pointer text-light-blue-900 ' onClick={logoutclickhandler}>Sign out</h2>
                  </div>
                  :
                  <button className='w-24 h-8 text-light-blue-900  font-normal' onClick={loginclickhandler}>Login</button>
              }
          </div> */}
        </div>
      </header>

      <Modal
        isOpen={modalIsOpen}
        contentLabel="Alert Modal"
        ariaHideApp={false}
        style={customModalStyles}
        onRequestClose={closemodal}
      >
        <div className="m-2">
          <div className='flex items-cener '>
            <div className='mt-2  w-full grid grid-cols-7'>
              <div className='ml-10'>
                <h3 className='text-white text-2xl  font-light'>Masters</h3>
                <hr className='w-24'></hr>
                <Link to="/alert" className="text-white grid   py-1  hover:font-bold text-sm  " >Alert Config</Link>

              </div>

              <div>
                <h3 className='text-white text-xl  font-light'>Sheets</h3>
                <hr className='w-24'></hr>
                <Link to="/productionsheet" className="text-white grid  py-1 hover:font-bold text-sm   " >Production Sheet</Link>
                {/* <Link to="/cartsheet" className="text-white grid   py-1 hover:font-bold text-sm   ">Cart sheet</Link> */}
                <Link to="/manufacturingsheet" className="text-white grid  py-1  hover:font-bold text-sm   ">Manufacturing sheet</Link>

              </div>
              <div>
                <h3 className='text-white text-xl font-light'>Queue Management</h3>
                <hr className='w-48'></hr>
                <Link to="/Queue_production" className="text-white grid   py-1 hover:font-bold text-sm">Production Sheet Queue</Link>
                <Link to="/Queue_manufacturing" className="text-white grid   py-1 hover:font-bold text-sm  ">Manufacturing Sheet Queue</Link>
              </div>
              <div className="ml-10">
                <h3 className='text-white text-xl font-light'>Transactions</h3>
                <hr className='w-48'></hr>
                <Link to="/fltinfo" className="text-white grid   py-1 hover:font-bold text-sm">Pre flight planning</Link>
              </div>
              <div>
                <h3 className='text-white text-xl ml-2 font-light'></h3>

              </div>
              <div>
                <h3 className='text-white text-xl ml-2 font-light'></h3>

              </div>
            </div>
          </div>
        </div>
      </Modal>
      
    </>
    
  );
  
};
const customModalStyles = {
  overlay: {
    backgroundColor: 'rgba(0, 0, 0, 0)',
    zIndex: 1000,
  },
  content: {
    top: '50%',
    left: '50%',
    width: '100%',
    height: '86%',
    transform: 'translate(-50%, -50%)',
    overflow: 'auto',
    backgroundColor: 'rgb(8 47 53)',
    border: '0px',
  },
};

export default Header;
