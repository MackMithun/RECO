import React, { useEffect } from 'react';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';

const Home = () => {

    return (
        <>
            <div className='min-h-screen flex flex-col'>
                <Header />
                <div className='flex-grow mt-5'></div>
                <Footer />
            </div>
        </>
    );
}

export default Home;






