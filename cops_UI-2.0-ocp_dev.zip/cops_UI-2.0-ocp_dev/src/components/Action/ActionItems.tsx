import React, { useState } from "react";
import { Radio } from '@material-tailwind/react';
import AddTailTable from "../Table/ActionTable/AddTailTable"; 
import CancelFlightTable from "../Table/ActionTable/CancelFlightTable";
import ChangeAircraftType from "../Table/ActionTable/ChangeAircraftType";
import ChangeCatererCodeTable from "../Table/ActionTable/ChangeCatererCodeTable";
import ChangeFlightNumberTable from "../Table/ActionTable/ChangeFlightNumberTable";
import ChangeMatricesandPercentageTable from "../Table/ActionTable/ChangeMatricesandPercentageTable";
import IROPSTable from "../Table/ActionTable/IROPSTable";
import MovetoTransitTable from "../Table/ActionTable/MovetoTransitTable";
import ChangeTerminal from "../Table/ActionTable/ChangeTerminal";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import Breadcrumbs  from '../Breadcrumbs/Breadcrumbs';
import { useLocation } from "react-router";
import { alwaysTrue } from "../../helpers/mapper";

const ActionItems = () => {
  const [selectedOption, setSelectedOption] = useState(null);
  const handleCheckboxChange = (event: any) => {
    setSelectedOption(event.target.id);
  };
  
  let locationdata = useLocation();
  let flt = locationdata.state.obj;
  const { groupId, flt_No, dep, flt_Dt, aircraftType } = flt[0];
 

  const selectedGrid = () => {
    switch (selectedOption!) {
      case "Move to Transit":
        return <MovetoTransitTable data={locationdata.state.obj} />;
      case "Cancel Flight":
        return <CancelFlightTable data={locationdata.state.obj}/>;
      case "Change Flight No":
        return <ChangeFlightNumberTable data={locationdata.state.obj}/>;
      case "Change Caterer Code":
        return <ChangeCatererCodeTable data={locationdata.state.obj}/>;
      case "Add Tail":
        return <AddTailTable data={locationdata.state.obj}/>;
      case "IROPS":
        return <IROPSTable data={locationdata.state.obj}/>;
      case "Change Aircraft Type":
        return <ChangeAircraftType data={locationdata.state.obj}/>;
      case "Change Flight Type":
        return <h1>Change Flight Type</h1>;
      case "Change Matrices and Percentage":
        return <ChangeMatricesandPercentageTable data={locationdata.state.obj}/>
      case "Change Terminal":
        return <ChangeTerminal data={locationdata.state.obj}/>;
      default:
        return null;
    }
  };

  return (
    <>
    <div className="min-h-screen flex flex-col">
      <Header />
      <div className='ml-3 mt-2'> <Breadcrumbs /></div>
      <div className="mx-left-42 max-w-screen-xl sm:w-10/12 md:w-10/12 lg:w-9/12 xl:w-9/12 h-auto p-1 border bg-white-300 rounded-lg">
                <span className="ml-20">Groupid: </span><span className="font-bold text-red-500 mr-10"> {groupId}</span>
                 Flight Number: <span className=" mr-10 font-bold text-red-500"> {flt_No}</span>
                Departure: <span className="font-bold text-red-500 mr-10"> {dep}</span>
                 Flight date: <span className="font-bold text-red-500 mr-10"> {flt_Dt.split("T")[0]} </span>
                 Aircraft Type:  <span className="font-bold text-red-500"> {aircraftType}</span> 
          </div>
      <div className="flex justify-center items-center">
     
        <div className="mt-2 max-w-screen-xl  w-full sm:w-10/12 md:w-10/12 lg:w-9/12 xl:w-9/12 h-auto p-2 grid grid-cols-3 md:grid-cols-3 xl:grid-cols-5 sm:gap-1 md-gap-1 lg:gap-3 xl:gap-3 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50">
          {[
            "Move to Transit",
            "Cancel Flight",
            "Change Flight No",
            "Change Caterer Code",
            "Add Tail",
            "IROPS",
            "Change Aircraft Type",
            "Change Flight Type",
            "Change Matrices and Percentage",
            "Change Terminal",
          ].map((option) => (
            <div key={option} className="flex items-center mt-1">
              <Radio
                id={option}
                checked={selectedOption === option}
                onChange={handleCheckboxChange}
                name="type"
                crossOrigin={false}
                color={"pink" }
                className={`peer relative h-4 w-4 cursor-pointer appearance-none rounded-full border border-pink-200 text-pink-900 transition-all before:absolute before:top-2/4 before:left-2/4 before:block before:h-12 before:w-12 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-pink-500 before:opacity-0 before:transition-opacity checked:border-pink-900 checked:before:bg-pink-200 hover:before:opacity-10 !important`}
                onPointerEnterCapture= {()=>{alwaysTrue()}}
                onPointerLeaveCapture= {()=>{alwaysTrue()}}
              />
              <label
                htmlFor={option}
                className="ml-2 text-sm font-normal hover:text-gray-800 text-gray-700 cursor-pointer select-none"
              >
                {option}
              </label>
            </div>
          ))}
        </div>
      </div>

      {selectedGrid()}


      <div className="mt-auto">
        <Footer />
      </div>
    </div>

    </>
  );
};

export default ActionItems;
