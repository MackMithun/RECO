import { Radio } from '@material-tailwind/react';
import React, { useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import AddTailTable from '../Table/ActionTable/AddTailTable';
import CancelFlightTable from '../Table/ActionTable/CancelFlightTable';
import ChangeAircraftType from '../Table/ActionTable/ChangeAircraftType';
import ChangeCatererCodeTable from '../Table/ActionTable/ChangeCatererCodeTable';
import ChangeFlightNumberTable from '../Table/ActionTable/ChangeFlightNumberTable';
import ChangeMatricesandPercentageTable from '../Table/ActionTable/ChangeMatricesandPercentageTable';
import ChangeTerminal from '../Table/ActionTable/ChangeTerminal';
import IROPSTable from '../Table/ActionTable/IROPSTable';
import MovetoTransitTable from '../Table/ActionTable/MovetoTransitTable';
import Modal from 'react-modal'
import { ACTION_CUSTOMMODALSTYLES } from '../constants/Modal_Styles/customModalStyles';
import { alwaysTrue } from '../../helpers/mapper';

const ActionModal = (props: any) => {

    const [selectedOption, setSelectedOption] = useState(null);

    const handleCheckboxChange = (event: any) => {
        setSelectedOption(event.target.id);
    };

    let flt = props.state;

    const { groupId, flt_No, dep, flt_Dt, aircraftType } = flt[0];

    const selectedGrid = () => {
        switch (selectedOption!) {
            case "Move to Transit":
                return <MovetoTransitTable data={props.state} />;
            case "Cancel Flight":
                return <CancelFlightTable data={props.state} />;
            case "Change Flight No":
                return <ChangeFlightNumberTable data={props.state} />;
            case "Change Caterer Code":
                return <ChangeCatererCodeTable data={props.state} />;
            case "Add Tail":
                return <AddTailTable data={props.state} />;
            case "IROPS":
                return <IROPSTable data={props.state} />;
            case "Change Aircraft Type":
                return <ChangeAircraftType data={props.state} />;
            case "Change Flight Type":
                return <h1>Change Flight Type</h1>;
            case "Change Matrices and Percentage":
                return <ChangeMatricesandPercentageTable data={props.state} />
            case "Change Terminal":
                return <ChangeTerminal data={props.state} />;
            default:
                return null;
        }
    };

    return (<>
        <Modal
            isOpen={props.isOpen}
            contentLabel="Aircraft Modal"
            ariaHideApp={false}
            style={ACTION_CUSTOMMODALSTYLES}
        >
            <div className=" right-0 flex justify-end items-center w-full p-1">
                <div className="mx-left-40 max-w-screen-xl sm:w-10/12 md:w-10/12 lg:w-9/12 xl:w-9/12 h-auto p-1 border bg-white-300 rounded-lg mt-5">
                    <span className="ml-10">Groupid: </span><span className="font-bold text-red-500 mr-10"> {groupId}</span>
                    Flight Number: <span className=" mr-10 font-bold text-red-500"> {flt_No}</span>
                    Departure: <span className="font-bold text-red-500 mr-10"> {dep}</span>
                    Flight date: <span className="font-bold text-red-500 mr-10"> {flt_Dt.split("T")[0]} </span>
                    Aircraft Type:  <span className="font-bold text-red-500"> {aircraftType}</span>
                </div>
                <button className="text-black text-xl mb-2 focus:outline-none"
                    onClick={props.isClose}>
                    <AiOutlineClose />
                </button>
            </div>
            <div className="flex justify-center items-center">

                <div className="mt-2 max-w-screen-xl  w-full sm:w-10/12 md:w-10/12 lg:w-9/12 xl:w-9/12 h-auto p-2 grid grid-cols-3 md:grid-cols-3 xl:grid-cols-5 sm:gap-1 md-gap-1 lg:gap-3 xl:gap-3 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50">
                    {[
                        "Move to Transit",
                        "Cancel Flight",
                        "Change Flight No",
                        "Change Caterer Code",
                        "Add Tail",
                        "IROPS",
                        "Change Aircraft Type",
                        "Change Flight Type",
                        "Change Matrices and Percentage",
                        "Change Terminal",
                    ].map((option) => (
                        <div key={option} className="flex items-center mt-1">
                            <Radio
                                id={option}
                                checked={selectedOption === option}
                                onChange={handleCheckboxChange}
                                name="type"
                                crossOrigin={false}
                                color={"pink"}
                                className={`peer relative h-4 w-4 cursor-pointer appearance-none rounded-full border border-pink-200 text-pink-900 transition-all before:absolute before:top-2/4 before:left-2/4 before:block before:h-12 before:w-12 before:-translate-y-2/4 before:-translate-x-2/4 before:rounded-full before:bg-pink-500 before:opacity-0 before:transition-opacity checked:border-pink-900 checked:before:bg-pink-200 hover:before:opacity-10 !important`}
                                onPointerEnterCapture= {()=>{alwaysTrue()}}
                                onPointerLeaveCapture= {()=>{alwaysTrue()}}
                            />
                            <label
                                htmlFor={option}
                                className="ml-2 text-sm font-normal hover:text-gray-800 text-gray-700 cursor-pointer select-none"
                            >
                                {option}
                            </label>
                        </div>
                    ))}
                </div>
                
            </div>

            {selectedGrid()}
        </Modal>
    </>);
}

export default ActionModal;
