import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal'
import { AircraftType } from '../../../services/api-service';
import { Transit_CUSTOMMODALSTYLES } from '../../constants/Modal_Styles/customModalStyles';

const AircraftModal = (props: any) => {

    const [aircraftList, setAircraftList] = useState([{ aircraftType: 'Select', id: 0 },])
    const [aircraftTypeSelected, setAircraftTypeSelected] = useState('Select');

    async function aircraftType() {
        try {
            const aircraftTypeData = await AircraftType();

            setAircraftList((actype) => [actype[0], ...aircraftTypeData]);
        } catch (error) {
            console.error(error);
        }
    }

    useEffect (() => {
        aircraftType()
    },[])
    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Aircraft Modal"
                ariaHideApp={false}
                style={Transit_CUSTOMMODALSTYLES}
            >
                <div className=' fixed-top h-10 p-4  bg-customcolor flex justify-between items-center w-full mb-5'>
                    <h3 className="text-center 0 flex-grow text-xl text-white ">Change Aircraft Type</h3>
                    <button
                        className="text-white text-xl focus:outline-none"
                        onClick={props.isClose}
                    >
                        <AiOutlineClose />
                    </button>
                </div>
                <p className="ml-5 mb-1">Flight No: 238 | ARR: MAA | DEP: AMD | A/C Type: A</p>
                <div className='w-3/6 h-20 items-center ml-14 mb-4'>
                    <label className='text-gray-500 text-sm w-11/12 '>Aircraft Type</label>
                    <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  ${aircraftTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                        value={aircraftTypeSelected} onChange={(e) => setAircraftTypeSelected(e.target.value)}
                    >
                        {aircraftList !== undefined ? (
                            aircraftList.map((item: any, index: number) => {
                                return (
                                    <option value={item.value} id={item.id} key={index}>
                                        {item.aircraftType}
                                    </option>
                                );
                            })) : (<></>)}
                    </select>
                </div>

                <div className='lg:w-3/6 xl:w-3/6 md:w-10/12 md:ml-3 lg:mr-8 xl:mr-8 flex float-right h-10  '>
                    <button onClick={props.confirm} className='bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  mx-0 my-0   text-white font-semibold rounded-lg'>
                        Confirm
                    </button>
                    <button className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
                        Cancel
                    </button>
                </div>

            </Modal>
        </>
    )
}


export default AircraftModal;