import React, { useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal'
import { Transit_CUSTOMMODALSTYLES } from '../../constants/Modal_Styles/customModalStyles';


const CatererModal = (props:any) => {
    const [catererList, setcatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [CatererSelected, setCatererSelected] = useState('Select');

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Caterer Modal"
                ariaHideApp={false}
                style={Transit_CUSTOMMODALSTYLES}
            >
                <div className=' fixed-top h-10 p-4  bg-customcolor flex justify-between items-center w-full mb-5'>
                    <h1 className="text-center 0 flex-grow text-2xl text-white ">Caterer Change Confirmation</h1>
                    <button className="text-white text-xl focus:outline-none"
                        onClick={props.isClose}>
                        <AiOutlineClose />
                    </button>
                </div>
                <div className="ml-10">Do you want to Move Flight?</div>
                <div className="md:w-3/6 ml-10 mt-3 ">
                    <label className='text-gray-500 hover:text-gray-700 text-sm'>Caterer<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                    <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none `}
                        value={CatererSelected} onChange={(e) => setCatererSelected(e.target.value)}
                    >
                        {catererList !== undefined
                            ? catererList.map((item: any, index: number) => {
                                return (
                                    <option value={item.cater_Code}  id={item.id} key={index}>
                                        {item.cater_Code}
                                    </option>
                                );}) : <></>}
                    </select>
                </div>

                <div className='lg:w-3/6 xl:w-3/6 md:w-10/12 md:ml-3 lg:mr-8 xl:mr-8 flex float-right h-10 mt-10 '>
                    <button onClick={props.confirm} className='bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  mx-0 my-0   text-white font-semibold rounded-lg'>
                        Confirm
                    </button>
                    <button className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
                        Cancel
                    </button>
                </div>

            </Modal>
        </>
    )
}

export default CatererModal;