import React from 'react';
import Modal from 'react-modal';
import { AiFillWarning } from 'react-icons/ai';

const AlertModal = (props: any) => {

    const customModalStyles = {
        overlay: {
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
        },
        content: {
            top: '50%',
            left: '50%',
            minWidth: '300px',
            maxWidth: '400px',
            maxHeight: '220px',
            transform: `translate(-50%, ${props.isOpen ? '-50%' : '0%'})`,
            border: 'none',
            borderRadius: '10px',
            padding: '20px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            background: '#FFFFFF',
            width: '100%',
            
        },
    };

    return (
        <Modal
            isOpen={props.isOpen}
            contentLabel="Alert Modal"
            ariaHideApp={false}
            style={customModalStyles}
        >
            <div className='text-center'>
                <div className="flex flex-col items-center justify-center mb-3">
                    <div className="text-red-500 text-5xl mb-2">
                        <AiFillWarning />
                    </div>
                    <h2 className="text-gray-700 mb-2">
                        Please select all mandatory <span className="text-red-500">*</span> fields before downloading.
                    </h2>
                    <button className='bg-red-500 hover:bg-red-800 text-white py-2 px-4 rounded-lg focus:outline-none mt-3' onClick={props.isClose}>
                        Ok
                    </button>
                </div>
            </div>
        </Modal>
    );
}

export default AlertModal;
