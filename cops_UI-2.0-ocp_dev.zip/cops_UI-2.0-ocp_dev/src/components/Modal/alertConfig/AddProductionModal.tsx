import { Input, Typography } from '@material-tailwind/react';
import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { alwaysTrue, TimeValidity } from '../../../helpers/mapper';
import { ALERT_FREQUENCY, SHEET_TYPES } from '../../constants/Dropdown/dropdownConstants';
import { ADD_MODALSTYLES_PRODUCTION } from '../../constants/Modal_Styles/customModalStyles';
import { InfoModal } from '../CustomModal';
// import ErrorModal  from '../ErrorModal';

const AddProductionModal = (props: any) => {

    const addcustomModalStyles = ADD_MODALSTYLES_PRODUCTION
    const sheetTypeList = SHEET_TYPES;
    const alertFrequencyList = ALERT_FREQUENCY;
    const [fromDate, setFromDate] = useState<any>({ startDate: new Date(), endDate: null });
    const [toDate, setToDate] = useState<any>({ startDate: null, endDate: null });
    const [toMinDate, setToMinDate] = useState<any>({ startDate: null, endDate: null });
    const [alertFrequencySelected, setalertFrequencySelected] = useState('Select');
    const [sheetTypeSelected, setSheetTypeSelected] = useState('Select');
    const [alertTime, setAlertTime] = useState('12:00');
    const [errorAlerttime, setErrorAlerttime] = useState(false);
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [customcss, setcustomcss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500 " }) });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [error, seterror] = useState(props.toastError);

    useEffect(() => {
        seterror(props.toastError)
    }, [props.toastError])

    const minDate = new Date();
    minDate.setDate(minDate.getDate())

    const handleAlerttime = (e: any) => {
        setErrorAlerttime(false);
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("Alert Time is not in Valid Format");
            setErrorAlerttime(true);
        }
        else {
            seterror("");
            setErrorAlerttime(false);
        }
    }

    useEffect(() => {
        if (
            fromDate.startDate !== null &&
            sheetTypeSelected !== 'Select' &&
            alertFrequencySelected !== 'Select' &&
            alertTime !== '' &&
            !errorAlerttime
        ) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [fromDate.startDate, sheetTypeSelected, alertFrequencySelected, alertTime, errorAlerttime]);


    const SaveDataHandler = () => {
        if (!TimeValidity(alertTime)) {
            seterror("Alert Time is not in Valid Format");
            setErrorAlerttime(true);
            return;
        }
        else if (allFieldsTouched) {
            seterror("");
            setErrorAlerttime(false);
            const data = {
                fromdate: fromDate.startDate,
                toDate: toDate.startDate,
                alertFrequencySelected: alertFrequencySelected,
                sheetTypeSelected: sheetTypeSelected,
                alertTime: alertTime
            }
            props.saveData(data);
        }
    }

    const openModal = () => {
        setIsModalOpen(true);
    };
    const closeModal = () => {
        setIsModalOpen(false);
    };

    const clearHandler = () => {
        setFromDate({ startDate: null, endDate: null });
        setToDate({ startDate: null, endDate: null });
        setSheetTypeSelected('Select');
        setalertFrequencySelected('Select');
        setAlertTime("10:00")
        seterror("")
        setErrorAlerttime(false);
    }

    useEffect(() => {
        clearHandler()
    }, [props.isOpen])


    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="add Modal"
                ariaHideApp={false}
                style={addcustomModalStyles}
                shouldCloseOnOverlayClick={false}
                onRequestClose={props.isClose}
            >
                <div className='w-full h-fit flex flex-col justify-center items-center '>
                    <div className='w-full sm:w-12/12  grid grid-cols-3 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 bg-white-300 rounded-lg'>
                        <div className='col-span-3 mt-5 flex justify-between items-center text-center'>
                            <div className='fixed-top h-5 flex justify-between items-center w-full'>

                                <h3 className="text-center font-medium flex-grow text-xl text-customcolor ml-4">New  Alert Configuration </h3>
                                <button
                                    className="text-customcolor text-xl mr-5 focus:outline-none "
                                    onClick={props.isClose}
                                >
                                    <AiOutlineClose />
                                </button>
                            </div>
                        </div>

                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                            <label className='text-black text-sm w-11/12 '>Effective from<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <Datepicker
                                value={fromDate}
                                onChange={(date: any) => { setFromDate(date); setToDate({ startDate: null, endDate: null }); setToMinDate(date) }}
                                classNames={customcss}
                                displayFormat={"YYYY-MM-DD"}
                                popoverDirection="down"
                                useRange={false}
                                placeholder="Effective from"
                                asSingle={true}
                                readOnly
                                minDate={minDate}
                            />
                        </div>
                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                            <label className='text-black text-sm w-11/12 '>Effective to</label>
                            <Datepicker
                                value={toDate}
                                onChange={(date: any) => { setToDate(date); setToMinDate({ startDate: null, endDate: null }); }}
                                classNames={customcss}
                                displayFormat={"YYYY-MM-DD"}
                                popoverDirection="down"
                                useRange={false}
                                placeholder="Effective to "
                                asSingle={true}
                                readOnly
                                minDate={new Date(new Date(fromDate?.startDate))}
                            />
                        </div>

                        <div className='w-10/12 h-2/3 items-center  mt-5 ml-5'>
                            <label className='text-black text-sm'>SheetType<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown  hover:border-blue-500 ${sheetTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={sheetTypeSelected}
                                onChange={(e) => setSheetTypeSelected(e.target.value)}
                                required
                            >
                                {sheetTypeList !== undefined
                                    ? sheetTypeList.map((item: any, index: number) => {
                                        return (
                                            <option value={item.dep} id={item.stationID} key={index} >
                                                {item.value}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center  mt-5 ml-5'>
                            <label className='text-black text-sm'>Alert Frequency<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${alertFrequencySelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={alertFrequencySelected}
                                onChange={(e) => setalertFrequencySelected(e.target.value)}
                                required
                            >
                                {alertFrequencyList !== undefined
                                    ? alertFrequencyList.map((item: any, index: number) => {
                                        return (
                                            <option value={item.dep} id={item.stationID} key={index}
                                            >
                                                {item.value}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                        <label className='text-black text-sm'>Alert Time<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=''

                                onBlur={handleAlerttime}
                                value={alertTime}
                                maxLength={5}
                                onChange={(e) => { setAlertTime(e.target.value) }}
                            />
                            {!errorAlerttime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {alertTime}
                                </div>
                            )}
                            {errorAlerttime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    Format- HH:MM
                                </div>
                            )}
                        </div>

                        <div className='w-5/6 flex float-right h-10 mt-11 ml-4 '>
                            <button
                                onClick={SaveDataHandler}
                                className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6 px-1 text-white font-semibold rounded-lg 
                             ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`}
                                disabled={!allFieldsTouched}
                            >
                                Save
                            </button>
                            <button onClick={() => { clearHandler(); seterror(""); }}
                                className='bg-red-500 hover:bg-white hover:text-red-500 border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'
                            >
                                Clear
                            </button>

                        </div>

                    </div>
                    {error != undefined && error != "" &&
                        <div className='w-11/12 mt-8 grid grid-cols-1 items-center bg-red-200 h-10  rounded-sm text-white text-center'>
                            {error}
                        </div>
                    }
                </div>

            </Modal>

            {isModalOpen && <InfoModal isOpen={openModal} isClose={closeModal} message={"Please select all mandatory fields."} />}
        </>
    );
}

export default AddProductionModal;
