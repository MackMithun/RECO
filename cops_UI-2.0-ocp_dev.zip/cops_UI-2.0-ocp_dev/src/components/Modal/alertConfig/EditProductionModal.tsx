import { Input, Typography } from '@material-tailwind/react';
import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { alwaysTrue, TimeValidity } from '../../../helpers/mapper';
import { ALERT_FREQUENCY, SHEET_TYPES } from '../../constants/Dropdown/dropdownConstants';
import { ADD_MODALSTYLES_PRODUCTION } from '../../constants/Modal_Styles/customModalStyles';

const EditProductionModal = (props: any) => {

    const addcustomModalStyles = ADD_MODALSTYLES_PRODUCTION
    const sheetTypeList = SHEET_TYPES;
    const alertFrequencyList = ALERT_FREQUENCY;

    const [fromDate, setFromDate] = useState({ startDate: null, endDate: null });
    const [toDate, setToDate] = useState({ startDate: null, endDate: null });
    const [editSheetSelected, setEditSheetSelected] = useState('Select');
    const [editAlertFrequencySelected, setEditAlertFrequencySelected] = useState("Select");
    const [editAlertTime, seteditAlertTime] = useState('');
    const [errorAlerttime, setErrorAlerttime] = useState(false);
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [customcss, setcustomcss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2 cursor-not-allowed  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500 " }) });
    const [error, seterror] = useState("");

    useEffect(() => {
        seterror(props.toastError)
    }, [props.toastError])

    useEffect(() => {
        setErrorAlerttime(false);
        seterror("")
        setFromDate({ startDate: props.rowData.effectiveFrom, endDate: props.rowData.effectiveFrom });
        setToDate({ startDate: props.rowData.effectiveTo, endDate: props.rowData.effectiveTo });
        setEditSheetSelected(props.rowData.sheetType);
        setEditAlertFrequencySelected(props.rowData.alertFrequency);
        seteditAlertTime(props.rowData.alertTime);
    }, [props.rowData, props.isOpen]);

    const handleAlerttime = (e: any) => {
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("Alert Time is not in Valid Format");
            setErrorAlerttime(true);
        }
        else {
            seterror("");
            setErrorAlerttime(false);
        }
    }

    useEffect(() => {
        if (
            editSheetSelected !== 'Select' && editAlertFrequencySelected !== 'Select' && editAlertTime !== " " && errorAlerttime === false) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [editSheetSelected, editAlertFrequencySelected, editAlertTime, errorAlerttime]);

    const SaveDataHandler = () => {

        if (!TimeValidity(editAlertTime)) {
            seterror("Alert Time is not in Valid Format");
            setErrorAlerttime(true);
            return;
        }
        else if (allFieldsTouched) {
            const data = {
                fromdate: fromDate.startDate,
                toDate: toDate.startDate,
                alertFrequencySelected: editAlertFrequencySelected,
                sheetTypeSelected: editSheetSelected,
                alertTime: editAlertTime,
                id: props.rowData.id
            }
            props.saveData(data);
        }
    }

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="add Modal"
                ariaHideApp={false}
                style={addcustomModalStyles}
                shouldCloseOnOverlayClick={false}
                onRequestClose={props.isClose}
            >
                <div className='w-full flex flex-col justify-center items-center '>
                    <div className='w-full sm:w-12/12  grid grid-cols-3 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 bg-white-300 rounded-lg'>
                        <div className='col-span-3 mt-5  flex justify-between items-center text-center'>
                            <div className='fixed-top h-10  flex justify-between items-center w-full'>

                                <h3 className="text-center font-medium flex-grow text-xl text-customcolor ml-4">Update Alert Configuration </h3>
                                <button
                                    className="text-customcolor text-xl mr-5 focus:outline-none "
                                    onClick={props.isClose}
                                >
                                    <AiOutlineClose />
                                </button>
                            </div>
                        </div>

                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                            <label className='text-black text-sm w-11/12 '>Effective from <span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <Datepicker
                                value={fromDate}
                                onChange={(date: any) => { setFromDate(date) }}
                                classNames={customcss}
                                displayFormat={"YYYY-MM-DD"}
                                popoverDirection="down"
                                useRange={false}
                                placeholder="Effective from"
                                asSingle={true}
                                readOnly
                                disabled={true}
                            />
                        </div>

                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                            <label className='text-black text-sm w-11/12 '>Effective to</label>
                            <Datepicker
                                value={toDate}
                                onChange={(date: any) => { setToDate(date) }}
                                classNames={customcss}
                                displayFormat={"YYYY-MM-DD"}
                                popoverDirection="down"
                                useRange={false}
                                placeholder="Effective to"
                                asSingle={true}
                                readOnly
                                disabled={true}
                            />
                        </div>

                        <div className='w-10/12 h-2/3 items-center  mt-5 ml-5'>
                            <label className='text-black text-sm'>SheetType<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown  hover:border-blue-500 ${editSheetSelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={editSheetSelected}
                                onChange={(e) => setEditSheetSelected(e.target.value)}
                                required
                            >
                                {sheetTypeList !== undefined
                                    ? sheetTypeList.map((item: any, index: number) => {
                                        return (
                                            <option value={item.dep} id={item.stationID} key={index} >
                                                {item.value}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center  mt-5 ml-5'>
                            <label className='text-black text-sm'>Alert Frequency<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${editAlertFrequencySelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={editAlertFrequencySelected}
                                onChange={(e) => setEditAlertFrequencySelected(e.target.value)}
                                required
                            >
                                {alertFrequencyList !== undefined
                                    ? alertFrequencyList.map((item: any, index: number) => {
                                        return (
                                            <option value={item.dep} id={item.stationID} key={index}
                                            >
                                                {item.value}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                        <label className='text-black text-sm'>Alert Time<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=''
                                onBlur={handleAlerttime}
                                value={editAlertTime}
                                maxLength={5}
                                onChange={(e) => { seteditAlertTime(e.target.value) }}
                            />
                            {!errorAlerttime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {editAlertTime}
                                </div>
                            )}
                            {errorAlerttime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    HH:MM in 24hrs format
                                </div>
                            )}
                        </div>
                        <div className='w-6/6 flex float-right h-10 mt-11 ml-4 '>
                            <button onClick={SaveDataHandler}
                                className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6  px-1   text-white font-semibold rounded-lg
                                ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={!allFieldsTouched}
                            >
                                Update
                            </button>
                        </div>
                    </div>
                    {error != undefined && error != "" &&
                        <div className='w-11/12 mt-8 grid grid-cols-1 items-center bg-red-200 h-10  rounded-sm text-white text-center'>
                            {error}
                        </div>
                    }
                </div>

            </Modal>
        </>
    );
}

export default EditProductionModal;
