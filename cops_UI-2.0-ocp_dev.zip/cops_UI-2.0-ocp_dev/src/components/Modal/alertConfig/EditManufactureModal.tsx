import React, { useEffect, useState } from 'react';
import Datepicker, { ClassNamesTypeProp } from 'react-tailwindcss-datepicker';
import Modal from 'react-modal';
import { AiOutlineClose } from 'react-icons/ai';
import { ADD_MODALSTYLES_PRODUCTION } from '../../constants/Modal_Styles/customModalStyles';
import { ALERT_FREQUENCY } from '../../constants/Dropdown/dropdownConstants';
import { Input, Typography } from '@material-tailwind/react';
import { alwaysTrue, TimeValidity } from '../../../helpers/mapper';

const EditManufactureModal = (props: any) => {
    const addcustomModalStyles = ADD_MODALSTYLES_PRODUCTION;
    const alertFrequencyList = ALERT_FREQUENCY;

    const [fromDate, setFromDate] = useState({ startDate: null, endDate: null });
    const [toDate, setToDate] = useState({ startDate: null, endDate: null });
    const [editAlertFrequencySelected, setEditAlertFrequencySelected] = useState("Select");
    const [editAlertTime, seteditAlertTime] = useState('');
    const [editFromTime, setEditFromTime] = useState('');
    const [editToTime, setEditToTime] = useState('')
    const [errorAlerttime, setErrorAlerttime] = useState(false);
    const [errorFromTime, setErrorFromTime] = useState(false);
    const [errorToTime, setErrorToTime] = useState(false);
    const [allFieldsTouched, setAllFieldsTouched] = useState(false)
    const [customcss, setcustomcss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full cursor-not-allowed p-2  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500 " }) });
    const [error, seterror] = useState("");

    useEffect(() => {
        seterror(props.toastError)
    }, [props.toastError])

    const minDate = new Date();
    minDate.setDate(minDate.getDate());

    const handleFromtime = (e: any) => {
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("From Time is not in Valid Format");
            setErrorFromTime(true);
        }
        else {
            seterror("");
            setErrorFromTime(false);
            setErrorAlerttime(false);
        }
    };

    const handletotime = (e: any) => {
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("To Time is not in Valid Format");
            setErrorToTime(true);
        } else {
            setErrorToTime(false);
            seterror('');
            if (value > editFromTime) {
                const fromTimeInMinutes = parseInt(editFromTime.slice(0, 2)) * 60 + parseInt(editFromTime.slice(3));
                const toTimeInMinutes = parseInt(value.slice(0, 2)) * 60 + parseInt(value.slice(3));
                if (toTimeInMinutes - fromTimeInMinutes >= 239) {
                    if (value.length === 5 && value.includes(':') && value.split(':').length === 2) {
                        setEditToTime(value);
                        setErrorToTime(false);
                    }
                } else {
                    setErrorToTime(true);
                    seterror("To time should be 4 hours greater than from time");
                }
            } else {
                setErrorToTime(true);
                seterror("To time should be greater than from time");
            }
        }
    };

    const handleAlerttime = (e: any) => {
        setErrorAlerttime(false);
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("Alert Time is not in Valid Format");
            setErrorAlerttime(true);
        } else {
            setErrorAlerttime(false);
            seterror('');
            const fromTimeInMinutes = parseInt(editFromTime.slice(0, 2)) * 60 + parseInt(editFromTime.slice(3));
            const alertTimeInMinutes = parseInt(value.slice(0, 2)) * 60 + parseInt(value.slice(3));
            if (alertTimeInMinutes + 240 <= fromTimeInMinutes) {
                seteditAlertTime(value);
            } else {
                setErrorAlerttime(true);
                seterror("Alert time should be at least 4 hours before from time");
            }
        }
    }

    const SaveDataHandler = () => {
        console.log('hit')
        if (!TimeValidity(editFromTime)) {
            seterror("Time is not in Valid Format");
            setErrorFromTime(true);
            return;
        }
        else if (!TimeValidity(editAlertTime)) {
            seterror("Time is not in Valid Format");
            setErrorAlerttime(true);
            return;
        }
        else if (!TimeValidity(editToTime)) {
            seterror("Time is not in Valid Format");
            setErrorToTime(true);
            return;
        }
        else if (allFieldsTouched) {
            const data = {
                fromdate: fromDate.startDate,
                toDate: toDate.startDate,
                alertFrequencySelected: editAlertFrequencySelected,
                fromTime: editFromTime,
                toTime: editToTime,
                alertTime: editAlertTime,
                id: props.rowData.id
            }
            props.saveData(data);
        }
    }

    useEffect(() => {
        setFromDate({ startDate: props.rowData.effectiveFrom, endDate: props.rowData.effectiveFrom });
        setToDate({ startDate: props.rowData.effectiveTo, endDate: props.rowData.effectiveTo })
        setEditAlertFrequencySelected(props.rowData.alertFrequency);
        seteditAlertTime(props.rowData.alertTime);
        setEditFromTime(props.rowData.fromTime);
        setEditToTime(props.rowData.toTime)
        seterror("");
        setErrorFromTime(false)
        setErrorToTime(false)
        setErrorAlerttime(false);
    }, [props.rowData, props.isOpen]);


    useEffect(() => {
        if (editAlertFrequencySelected !== 'Select' && editFromTime !== "" && editToTime !== "" && editAlertTime !== "" && errorFromTime === false && errorToTime === false && errorAlerttime === false) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [editAlertFrequencySelected, editAlertTime, editFromTime, editToTime, errorFromTime, errorToTime, errorAlerttime]);

    return (
        <Modal
            isOpen={props.isOpen}
            contentLabel="add Manufacture Alert Modal"
            ariaHideApp={false}
            style={addcustomModalStyles}
            shouldCloseOnOverlayClick={false}
            onRequestClose={props.isClose}
        >
            <div className='w-full flex flex-col justify-center items-center '>
                <div className='w-full sm:w-12/12  grid grid-cols-3 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 bg-white-300 rounded-lg'>
                    <div className='col-span-3 flex justify-between items-center text-center'>
                        <div className='fixed-top h-10  flex justify-between items-center w-full'>
                            <h3 className="text-center font-medium flex-grow text-xl text-customcolor ml-4">Update  Alert Configuration </h3>
                            <button
                                className="text-customcolor text-xl mr-5 focus:outline-none "
                                onClick={props.isClose}
                            >
                                <AiOutlineClose />
                            </button>
                        </div>
                    </div>

                    <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                        <label className='text-black text-sm w-11/12 '>Effective from<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <Datepicker
                            value={fromDate}
                            onChange={(date: any) => { setFromDate(date) }}
                            classNames={customcss}
                            displayFormat={"YYYY-MM-DD"}
                            popoverDirection="down"
                            useRange={false}
                            placeholder="Effectiveto date"
                            asSingle={true}
                            readOnly
                            disabled={true}
                        />
                    </div>

                    <div className='w-10/12 h-2/3 items-center mt-5 ml-5'>
                        <label className='text-black text-sm w-11/12 '>Effective to</label>
                        <Datepicker
                            value={toDate}
                            onChange={(date: any) => { setFromDate(date) }}
                            classNames={customcss}
                            displayFormat={"YYYY-MM-DD"}
                            popoverDirection="down"
                            useRange={false}
                            placeholder="Effectiveto date"
                            asSingle={true}
                            readOnly
                            disabled={true}
                        />
                    </div>

                    <div className='w-10/12 h-2/3 items-center  mt-5 ml-5'>
                        <label className='text-black text-sm'>Alert Frequency<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${editAlertFrequencySelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={editAlertFrequencySelected}
                            onChange={(e) => { setEditAlertFrequencySelected(e.target.value) }}
                            required
                        >
                            {alertFrequencyList !== undefined
                                ? alertFrequencyList.map((item, index) => (
                                    <option key={index}>
                                        {item.value}
                                    </option>
                                ))
                                : <></>}
                        </select>
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-5 lg:mt-5'>
                        <label className='text-black text-sm'>From Time<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <input
                            className="border border-gray-300 rounded-md px-3 py-2 w-full"
                            type="text"
                            placeholder=''
                            onBlur={handleFromtime}
                            value={editFromTime}
                            maxLength={5}
                            onChange={(e) => { setEditFromTime(e.target.value) }}
                        />
                        {!errorFromTime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                {editFromTime}
                            </div>
                        )}
                        {errorFromTime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                Format-HH:MM
                            </div>
                        )}
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-5 lg:mt-5'>
                        <label className='text-black text-sm'>To Time<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <input
                            className="border border-gray-300 rounded-md px-3 py-2 w-full"
                            type="text"
                            placeholder=''
                            onBlur={handletotime}
                            value={editToTime}
                            maxLength={5}
                            onChange={(e) => { setEditToTime(e.target.value) }}
                        />
                        {!errorToTime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                {editToTime}
                            </div>
                        )}
                        {errorToTime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                Format- HH:MM
                            </div>
                        )}
                    </div>

                    <div className='w-10/12 h-2/3 items-center ml-5 lg:mt-5'>
                        <label className='text-black text-sm'>Alert Time<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <input
                            className="border border-gray-300 rounded-md px-3 py-2 w-full"
                            type="text"
                            placeholder=''
                            onBlur={handleAlerttime}
                            value={editAlertTime}
                            maxLength={5}
                            onChange={(e) => { seteditAlertTime(e.target.value) }}
                        />
                        {!errorAlerttime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                {editAlertTime}
                            </div>
                        )}
                        {errorAlerttime && (
                            <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                    <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                </svg>
                                Format :HH:MM
                            </div>
                        )}
                    </div>

                    <div></div> <div></div>
                    <div className='w-5/6 flex float-right h-10  ml-5 mt-3 '>
                        <button onClick={SaveDataHandler}
                            className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6 p-2 px-1   text-white font-semibold rounded-lg
                            ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={!allFieldsTouched}
                        >
                            Update
                        </button>
                    </div>
                </div>
                {error != undefined && error != "" &&
                    <div className='w-11/12 grid grid-cols-1 items-center bg-red-200 h-10 mt-1 rounded-sm text-white text-center'>
                        {error}
                    </div>
                }
            </div>
        </Modal>
    )
}

export default EditManufactureModal;
