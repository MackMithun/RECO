import React from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import { DataColumnInterface } from '../../../../interface/Global interface/DataColumnInterface';
import { HeaderColumnInterface } from '../../../../interface/Global interface/HeaderColumnInterface';
import { dataRow, headerRow } from '../../../../interface/Global interface/TableInterface';
import SimpleTable from '../../../Table/SimpleTable';
import { constants } from '../../../constants/Queue Management/ProductionQueueConstants';
import { QUEUE_ModalStyles } from '../../../constants/Modal_Styles/customModalStyles';

const QueueModal = (props:any) => {

    const QueueHeaderArray = constants.QueueHeaderArray;
    const headerQueuestyleindex = constants.headerQueuestyleindex;
    const Queuedatastyle = constants.queuedataStyle;
    const queuestyles = QUEUE_ModalStyles

    const parseQueueHeaderData = (QueueHeaderArray: string[]) => {
        return {
            headerColumns: QueueHeaderArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerQueuestyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const parseQueuerowData = (data: any[]) => {
        return data.map((item: any) => {
            console.log(item)
                return {
                    CatererCode: item.catererCode,
                    queueid: item.queueId,
                    sector: item.sector,
                    status: item.status.split("-")[0],
                    fltNo: item.fltNo,
                    message: item.status.split("-")[1]
                } as any;
        })
    };

    const parsequeuecolumns = (row: any, index: number): DataColumnInterface[] => {
        let columns = [] as DataColumnInterface[];
        columns.push({ text: (index + 1).toString(), action: undefined });
        columns.push({ text: row.fltNo, action: undefined })
        columns.push({ text: row.CatererCode, action: undefined })
        columns.push({ text: row.sector, action: undefined })
        columns.push({
            text: null, action: [{
                name: row.status, icon: undefined, type: "queue-link", event: null, parameter: null
            }]
        });
        columns.push({ text: row.message, action: undefined })
        // columns.push({
        //     text: null, action: [{
        //         name: "Retrigger", icon: <AiOutlineSync />, type: "icon", event: pendingQueueRerigger, parameter: { index: index, queueid: row.queueid }
        //     }]
        // });
        return columns;
    }

    const parseQueuedata = () => {
        let unmodifiedrows = parseQueuerowData(props.fetchdata);
        let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
            return {
                dataColumns: parsequeuecolumns(row, index)
            } as dataRow;
        });
        return modifiedrows;
    };

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Alert Modal"
                ariaHideApp={false}
                style={queuestyles}
                shouldCloseOnOverlayClick={false}
            >
                <div className='fixed-top h-12 p-4  bg-indigo-600 flex justify-between items-center w-full mb-5'>
                    <h3 className="text-center font-light flex-grow text-xl text-white ">Passenger Manifest Details</h3>
                    <button
                        className="text-white text-xl my-4 focus:outline-none "
                        onClick={props.isClose}
                    >
                        <AiOutlineClose />
                    </button>
                </div>
                <div className={`mx-8 justify-center items-center h-100 `}>
                    <SimpleTable tableheader={parseQueueHeaderData(QueueHeaderArray)}
                        tableData={parseQueuedata()}
                        tdstyle={Queuedatastyle}
                        background={'bg-customcolor'}
                    />
                </div>
            </Modal>
        </>
    );
}


export default QueueModal;