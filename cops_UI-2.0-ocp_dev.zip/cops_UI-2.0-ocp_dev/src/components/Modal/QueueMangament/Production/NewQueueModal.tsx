import { Input, Typography } from '@material-tailwind/react';
import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { alwaysTrue, TimeValidity } from '../../../../helpers/mapper';
import { ByCatererData, CatererStation } from '../../../../services/api-service';
import { SHEET_TYPES } from '../../../constants/Dropdown/dropdownConstants';
import { ADD_MODALSTYLES_PRODUCTION } from '../../../constants/Modal_Styles/customModalStyles';

let currentDate = new Date();
currentDate.setDate(currentDate.getDate() + 1);
let currentDatePlusOne = currentDate.toISOString().split('T')[0];

const minDate = new Date();
minDate.setDate(minDate.getDate())

const NewQueueModal = (props: any) => {

    const sheetType = SHEET_TYPES;
    const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: currentDatePlusOne, endDate: currentDatePlusOne });
    const [catererSelected, setCatererSelected] = useState('Select');
    const [stationSelected, setStationSelected] = useState('Select');
    const [sheetSelected, setSheetSelected] = useState('Select');
    const [exectime, setexectime] = useState("");
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [datepickerCustomCss, setDatepickerCustomCss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500" }) });
    const [errormessage, seterrormessage] = useState(false);
    const [stationList, setStationList] = useState([{ station_Code: 'Select', id: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [error, seterror] = useState(props?.toastError);

    useEffect(() => {
        seterror(props?.toastError)
    }, [props?.toastError])

    const stationData = CatererStation();

    const fetchStationData = () => {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    const CatererByStation = async () => {
        if (stationSelected !== 'Select') {
            const QueryString = `?stationCode=${stationSelected}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    const handleexecdatetime = (e: any) => {
        const value = e.target.value;
        if (
            value.length === 16 &&
            value.includes('-') &&
            value.includes(':') &&
            value.split('-').length === 3 &&
            value.split(':').length === 2 &&
            value.split(' ').length === 2
        ) {
            const date = value.split(' ')[0];
            const time = value.split(' ')[1];
            const parsedDate = Date.parse(date);

            if (!isNaN(parsedDate) && TimeValidity(time)) {
                setexectime(value);
                seterrormessage(false);
            } else {
                seterrormessage(true);
            }
        } else {
            seterrormessage(true);
        }
    };


    const saveNewProductionData = () => {
        const date: any = flightDate?.startDate;
        const executionDateTime = new Date(exectime);
        const currentDateTime = new Date();
        const flightStartDate = new Date(date);

        if (
            stationSelected === 'Select' ||
            catererSelected === 'Select' ||
            flightDate?.startDate === null ||
            exectime === "" ||
            sheetSelected === 'Select'
        ) {
            setAllFieldsTouched(false);
            return;
        }

        if (executionDateTime <= currentDateTime) {
            seterror("Execution date and time should not be in the past.");
            return;
        }

        if (executionDateTime >= flightStartDate) {
            seterror("Execution date and time must be less than flight date.");
        } else {
            if (allFieldsTouched) {
                const data = {
                    station: stationSelected,
                    caterer: catererSelected,
                    flightDate: flightDate?.startDate,
                    sheetType: sheetSelected,
                    executionTime: exectime
                }
                props.addNewData(data)
            }
        }
    }

    const clearAddDataHandler = () => {
        setFlightDate({ startDate: null, endDate: null });
        setCatererSelected('Select');
        setStationSelected('Select');
        setSheetSelected('Select');
        setexectime("");
        seterrormessage(false);
        seterror("");
    }

    useEffect(() => {
        clearAddDataHandler()
        seterrormessage(false);
    }, [props?.isOpen])

    useEffect(() => {
        setCatererSelected('Select');
    }, [stationSelected]);

    useEffect(() => {
        if (stationSelected === 'Select') {
            CatererByStation()
        }
        fetchStationData();
        CatererByStation();
    }, [stationData.state, stationSelected, catererSelected]);

    useEffect(() => {
        if (flightDate !== null) {
            const flightDateMinusOne = new Date(currentDatePlusOne);
            flightDateMinusOne.setDate(flightDateMinusOne.getDate() - 1);
            const formattedDate = flightDateMinusOne.toISOString().split('T')[0] + " 18:00";
            setexectime(formattedDate);
        }
    }, [flightDate]);

    useEffect(() => {
        if (
            flightDate?.startDate !== null && stationSelected !== 'Select' &&
            catererSelected !== 'Select' && sheetSelected !== 'Select' && exectime !== "" && errormessage === false
        ) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [stationSelected, catererSelected, flightDate?.startDate, sheetSelected, exectime, errormessage]);

    const isCatererDisabled = stationSelected === 'Select';
    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="add Modal"
                ariaHideApp={false}
                style={ADD_MODALSTYLES_PRODUCTION}
                shouldCloseOnOverlayClick={false}
                onRequestClose={props.isClose}
            >
                <div className='w-full flex justify-center items-center '>
                    <div className='w-full sm:w-12/12  grid grid-cols-3 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 bg-white-300 rounded-lg'>
                        <div className='col-span-3 flex justify-between items-center text-center'>
                            <div className='fixed-top h-10 flex justify-between items-center w-full'>

                                <h3 className="text-center font-medium flex-grow text-xl text-customcolor  ml-4">New Production Queue </h3>
                                <button
                                    className="text-gray-500 text-xl mr-5 focus:outline-none "
                                    onClick={props.isClose}
                                >
                                    <AiOutlineClose />
                                </button>
                            </div>
                        </div>

                        <div className='w-10/12 h-2/3 ml-6 items-center  '>
                            <label className='text-black text-sm w-11/12'>Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <Datepicker
                                classNames={datepickerCustomCss}
                                value={flightDate}
                                onChange={(newValue: any) => setFlightDate(newValue)}
                                useRange={false}
                                asSingle={true}
                                popoverDirection="down"
                                minDate={minDate}
                                displayFormat={"YYYY-MM-DD"}
                                readOnly
                            />
                        </div>

                        <div className=" md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 ">
                            <label className='text-black hover:text-gray-700 text-sm'>Station<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown ${stationSelected === 'Select' ? 'text-gray-400' : ''} `}
                                value={stationSelected} onChange={(e) => setStationSelected(e.target.value)}
                            >
                                {stationList.map((item) => (
                                    <option key={item.id} value={item.station_Code}>
                                        {item.station_Code}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className="md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5">
                            <label className='text-black hover:text-gray-700 text-sm'>Caterer<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown  ${catererSelected === 'Select' ? 'text-gray-400' : ''}  ${isCatererDisabled ? 'text-gray-100' : ''} `}
                                value={catererSelected} onChange={(e) => setCatererSelected(e.target.value)}
                                disabled={isCatererDisabled}
                            >
                                {catererList.map((item: any, index: number) => (
                                    <option value={item.cater_Code} disabled={item.disabled} id={item.id} key={index}>
                                        {item.cater_Code}
                                    </option>
                                ))}
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center ml-6 mt-5'>
                            <label className='text-black text-sm w-11/12 '>Sheet Type<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${sheetSelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={sheetSelected}
                                onChange={(e) => setSheetSelected(e.target.value)}
                            >
                                {sheetType.map((item: any, index: number) => {
                                    return (
                                        <option value={item.value} id={item.id} key={index}>
                                            {item.value}
                                        </option>
                                    );
                                })}
                            </select>
                        </div>

                        <div className='w-10/12 h-2/3 items-center ml-5 mt-5 md:mt-10 lg:mt-11 xl:mt-11'>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=""
                                onBlur={handleexecdatetime}
                                defaultValue={exectime}
                                maxLength={16}
                            />
                            {!errormessage && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {exectime}
                                </div>
                            )}
                            {errormessage && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    Format- YYYY-MM-DD HH:MM
                                </div>
                            )}
                        </div>

                        <div className='w-5/6 flex float-right h-10  ml-5 mt-5 md:mt-10 lg:mt-10 xl:mt-10'>
                            <button onClick={saveNewProductionData} className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6   text-white font-semibold rounded-lg
                            ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={!allFieldsTouched} >
                                Save
                            </button>
                            <button onClick={() => { clearAddDataHandler(); seterror(""); }}
                                className='bg-red-500 hover:bg-white hover:text-red-500 border-2 w-5/6  ml-5   text-white font-semibold rounded-lg'>
                                Clear
                            </button>
                        </div>
                        <div className='col-span-3 mx-16'>
                            {error != undefined && error != "" &&
                                <div className='w-11/12 grid grid-cols-1 items-center bg-red-200 h-10 mt-1 rounded-sm text-white text-center'>
                                    {error}
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </Modal>
        </>
    );

}

export default NewQueueModal;