import { Input, Typography } from '@material-tailwind/react';
import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import {  TimeValidity } from '../../../../helpers/mapper';
import { ByCatererData, CatererStation } from '../../../../services/api-service';
import { ADD_MODALSTYLES_MANUFACTURE } from '../../../constants/Modal_Styles/customModalStyles';

const minDate = new Date();
minDate.setDate(minDate.getDate() + 1)

let currentDate = new Date();
currentDate.setDate(currentDate.getDate() + 1);
let currentDatePlusOne = currentDate.toISOString().split('T')[0];

const NewQueueModal = (props: any) => {

    const [fromTime, setFromTime] = useState("");
    const [toTime, setToTime] = useState("");
    const [catererSelected, setCatererSelected] = useState('Select');
    const [stationSelected, setStationSelected] = useState('Select');
    const [exectime, setexectime] = useState("");
    const [errormessage, seterrormessage] = useState(false);
    const [errorFromtime, setErrorfromtime] = useState(false);
    const [errorTotime, seterrorTotime] = useState(false);
    const [stationList, setStationList] = useState([{ station_Code: 'Select', id: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [datepickerCustomCss, setDatepickerCustomCss] = useState<ClassNamesTypeProp>({ input: (() => { return "w-full p-2  border border-gray-300  rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none hover:border-blue-500" }) });
    const [allFieldsTouched, setAllFieldsTouched] = useState(false);
    const [flightDate, setFlightDate] = useState<DateValueType>({ startDate: currentDatePlusOne, endDate: currentDatePlusOne });
    const [error, seterror] = useState(props.toastError);

    useEffect(() => {
        seterror(props.toastError)
    }, [props.toastError])

    const isCatererDisabled = stationSelected === 'Select';

    const handleexecdatetime = (e: any) => {
        const value = e.target.value;
        if (
            value.length === 16 &&
            value.includes('-') &&
            value.includes(':') &&
            value.split('-').length === 3 &&
            value.split(':').length === 2 &&
            value.split(' ').length === 2
        ) {
            const date = value.split(' ')[0];
            const time = value.split(' ')[1];
            const parsedDate = Date.parse(date);

            if (!isNaN(parsedDate) && TimeValidity(time)) {
                setexectime(value);
                seterrormessage(false);
            } else {
                seterrormessage(true);
            }
        } else {
            seterrormessage(true);
        }
    };

    const handleFromtime = (e: any) => {
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("From Time is not in Valid Format");
            setErrorfromtime(true);
        }
        else {
            seterror("");
            setErrorfromtime(false);
        }
    };

    const handletotime = (e: any) => {
        const value = e.target.value;
        if (!TimeValidity(value)) {
            seterror("To Time is not in Valid Format");
            seterrorTotime(true);
        } else {
            seterrorTotime(false);
            seterror('');
            if (value > fromTime) {
                const fromTimeInMinutes = parseInt(fromTime.slice(0, 2)) * 60 + parseInt(fromTime.slice(3));
                const toTimeInMinutes = parseInt(value.slice(0, 2)) * 60 + parseInt(value.slice(3));
                if (toTimeInMinutes - fromTimeInMinutes >= 239) {
                    if (value.length === 5 && value.includes(':') && value.split(':').length === 2) {
                        setToTime(value);
                        seterrorTotime(false);
                    }
                } else {
                    seterrorTotime(true);
                    seterror("To time should be 4 hours greater than from time");
                }
            } else {
                seterrorTotime(true);
                seterror("To time should be greater than from time");
            }
        }
    };

    const stationData = CatererStation();

    const fetchStationData = () => {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    const CatererByStation = async () => {
        if (stationSelected !== 'Select') {
            const QueryString = `?stationCode=${stationSelected}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    const clearAddDataHandler = () => {
        setStationSelected('Select');
        setCatererSelected('Select');
        setFlightDate({ startDate: null, endDate: null });
        setFromTime("20:00");
        setToTime("23:59");
        setexectime("");
        seterrormessage(false);
        setErrorfromtime(false);
        seterrorTotime(false);
        seterror("")
    }

    const saveNewDataHandler = () => {
        const date: any = flightDate?.startDate;
        const executionDateTime = new Date(exectime);
        const currentDateTime = new Date();
        const flightStartDate = new Date(date);

        if (
            stationSelected === 'Select' || catererSelected === 'Select' ||
            flightDate?.startDate === null || fromTime === "" ||
            toTime === "" || exectime === ""
        ) {
            setAllFieldsTouched(false);
            return;
        }

        if (executionDateTime <= currentDateTime) {
            seterror("Execution date and time should not be in the past.");
            return;
        }

        if (executionDateTime >= flightStartDate) {
            seterror("Execution date and time must be less than flight date.");
        } else {
            if (allFieldsTouched) {
                const data = {
                    flightDate: flightDate?.startDate,
                    station: stationSelected,
                    caterer: catererSelected,
                    fromTime: fromTime,
                    toTime: toTime,
                    execTime: exectime
                }
                props.addNewData(data)
                console.log(data);
            }
        }
    }

    useEffect(() => {
        clearAddDataHandler()
    }, [props.isOpen])

    useEffect(() => {
        setCatererSelected('Select');
    }, [stationSelected]);

    useEffect(() => {
        if (stationSelected === 'Select') {
            CatererByStation()
        }
        fetchStationData();
        CatererByStation();
    }, [stationData.state, stationSelected, catererSelected]);

    useEffect(() => {
        fetchStationData();
        CatererByStation();
    }, [stationSelected]);

    useEffect(() => {
        if (flightDate !== null) {
            const flightDateMinusOne = new Date(currentDatePlusOne);
            flightDateMinusOne.setDate(flightDateMinusOne.getDate() - 1);
            const formattedDate = flightDateMinusOne.toISOString().split('T')[0] + " 22:00";
            setexectime(formattedDate);
        }
    }, [flightDate]);

    useEffect(() => {
        if (
            flightDate?.startDate !== null && stationSelected !== 'Select' && catererSelected !== 'Select' &&
            fromTime !== "" && toTime !== "" && exectime !== "" && errorFromtime === false && errorTotime === false && errormessage === false
        ) {
            setAllFieldsTouched(true);
        } else {
            setAllFieldsTouched(false);
        }
    }, [stationSelected, catererSelected, flightDate?.startDate, fromTime, toTime, exectime, errorFromtime, errorTotime, errormessage]);

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="add Modal"
                ariaHideApp={false}
                style={ADD_MODALSTYLES_MANUFACTURE}
                shouldCloseOnOverlayClick={false}
                onRequestClose={props.isClose}
            >
                <div className='w-full flex justify-center items-center '>
                    <div className='w-full sm:w-12/12  grid grid-cols-3 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 bg-white-300 rounded-lg'>
                        <div className='col-span-3 flex justify-between items-center text-center'>
                            <div className='fixed-top h-10 flex justify-between items-center w-full'>

                                <h3 className="text-center font-medium flex-grow text-xl text-customcolor  ml-4">New Manufacturing Queue </h3>
                                <button
                                    className="text-gray-500 text-xl mr-5 focus:outline-none "
                                    onClick={props.isClose}
                                >
                                    <AiOutlineClose />
                                </button>
                            </div>
                        </div>
                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 '>
                            <label className='text-gray-800 text-sm w-11/12'>Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <Datepicker
                                classNames={datepickerCustomCss}
                                value={flightDate}
                                onChange={(newValue: any) => setFlightDate(newValue)}
                                useRange={false}
                                asSingle={true}
                                popoverDirection="down"
                                minDate={minDate}
                                displayFormat={"YYYY-MM-DD"}
                                readOnly
                            />
                        </div>

                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 '>
                            <label className='text-gray-800 text-sm w-11/12 '>Departure<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''}`}
                                value={stationSelected}
                                onChange={(e) => setStationSelected(e.target.value)}
                                required
                            >
                                {stationList !== undefined
                                    ? stationList.map((item: any, index: number) => {
                                        return (
                                            <option
                                                value={item.dep}
                                                disabled={item.disabled}
                                                id={item.stationID}
                                                key={index}
                                                className="font-2xl bg-wallpaper"
                                            >
                                                {item.station_Code}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 '>
                            <label className='text-gray-800 text-sm w-11/12 '>Caterer<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                            <select
                                className={`form-select  w-full  p-2 font-light bg-white
                                    border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${stationSelected === 'Select' ? 'text-gray-400' : ''} ${isCatererDisabled ? 'text-gray-100' : ''}`}
                                value={catererSelected}
                                onChange={(e) => setCatererSelected(e.target.value)}
                                required disabled={isCatererDisabled}
                            >
                                {catererList !== undefined
                                    ? catererList.map((item: any, index: number) => {
                                        return (
                                            <option
                                                value={item.cater_Code}
                                                disabled={item.disabled}
                                                id={item.id}
                                                key={index}
                                            >
                                                {item.cater_Code}
                                            </option>
                                        );
                                    })
                                    : <></>
                                }
                            </select>
                        </div>

                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 mt-5 '>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=''
                                onBlur={handleFromtime}
                                value={fromTime}
                                maxLength={5}
                                onChange={(e) => { setFromTime(e.target.value) }}
                            />
                            {!errorFromtime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {fromTime}
                                </div>
                            )}
                            {errorFromtime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    HH:MM - Not exceed 19:59
                                </div>
                            )}
                        </div>
                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 mt-5'>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=''
                                onBlur={handletotime}
                                value={toTime}
                                maxLength={5}
                                onChange={(e) => { setToTime(e.target.value) }}
                            />
                            {!errorTotime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {toTime}
                                </div>
                            )}
                            {errorTotime && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    Format- HH:MM
                                </div>
                            )}
                        </div>
                        <div className=' md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 mt-5'>
                            <input
                                className="border border-gray-300 rounded-md px-3 py-2 w-full"
                                type="text"
                                placeholder=''
                                onBlur={handleexecdatetime}
                                value={exectime}
                                maxLength={16}
                                onChange={(e) => { setexectime(e.target.value) }}
                            />
                            {!errormessage && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-green-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    {exectime}
                                </div>
                            )}
                            {errormessage && (
                                <div className="mt-2 flex items-center gap-1 font-normal text-red-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="-mt-px h-4 w-4">
                                        <path d="M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 01.67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 11-.671-1.34l.041-.022zM12 9a.75.75 0 100-1.5.75.75 0 000 1.5z" fillRule="evenodd" clipRule="evenodd" />
                                    </svg>
                                    Format- YYYY-MM-DD HH:MM
                                </div>
                            )}
                        </div>
                        <div></div>
                        <div></div>

                        <div className='w-5/6 flex float-right h-10  ml-5 mt-5'>
                            <button onClick={saveNewDataHandler}
                                className={`bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-5/6 p-2 mx-0 my-0  text-white font-semibold rounded-lg
                                ${!allFieldsTouched ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={!allFieldsTouched}
                            >
                                Save
                            </button>
                            <button onClick={() => { clearAddDataHandler(); seterror(""); }}
                                className='bg-red-500 hover:bg-white hover:text-red-500 border-2 w-5/6 p-2 ml-5  mx-0 my-0  text-white font-semibold rounded-lg'
                            >
                                Clear
                            </button>

                        </div>
                        <div className='col-span-3 mx-16'>
                            {error != undefined && error != "" &&
                                <div className='w-11/12 grid grid-cols-1 items-center bg-red-200 h-10 mt-1 rounded-sm text-white text-center'>
                                    {error}

                                </div>
                            }
                        </div>
                    </div>
                </div>
            </Modal>
        </>
    )
}

export default NewQueueModal;


