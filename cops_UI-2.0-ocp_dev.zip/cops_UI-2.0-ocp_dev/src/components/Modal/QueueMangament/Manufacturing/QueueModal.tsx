import React from 'react';
import Modal from 'react-modal';
import { AiOutlineClose } from 'react-icons/ai';
import { DataColumnInterface } from '../../../../interface/Global interface/DataColumnInterface';
import { dataRow, headerRow } from '../../../../interface/Global interface/TableInterface';
import SimpleTable from '../../../Table/SimpleTable';
import { constants } from '../../../constants/Queue Management/ProductionQueueConstants';
import { HeaderColumnInterface } from '../../../../interface/Global interface/HeaderColumnInterface';
import { QUEUE_ModalStyles } from '../../../constants/Modal_Styles/customModalStyles';

const QueueModal = (props: any) => {
    
    const QueueHeaderArray = constants.QueueHeaderArray;
    const headerQueuestyleindex = constants.headerQueuestyleindex;
    const Queuedatastyle = constants.queuedataStyle;
    const queuestyles = QUEUE_ModalStyles

    const parseQueueHeaderData = (QueueHeaderArray: string[]) => {
        return {
            headerColumns: QueueHeaderArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerQueuestyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    const parseQueuerowData = (data: any[]) => {
        return data.map((item: any) => {      
                return {
                    CatererCode: item.catererCode,
                    queueid: item.queueId,
                    sector: item.sector,
                    status: item.status.split("-")[0],
                    message: item.status.split("-")[1],
                    flightNumber : item.fltNo,
                } as any;
        })
    };

    const parsequeuecolumns = (row: any, index: number): DataColumnInterface[] => {
        let columns = [] as DataColumnInterface[];
        columns.push({ text: (index + 1).toString(), action: undefined });
        columns.push({ text: row.flightNumber, action: undefined })
        columns.push({ text: row.CatererCode, action: undefined })
        columns.push({ text: row.sector, action: undefined })
        columns.push({
            text: null, action: [{
                name: row.status, icon: undefined, type: "queue-link", event: null, parameter: null
            }]
        });
        columns.push({ text: row.message, action: undefined })
        return columns;
    }

    const parseQueuedata = () => {
        let unmodifiedrows = parseQueuerowData(props.fetchdata);
        let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
            return {
                dataColumns: parsequeuecolumns(row, index)
            } as dataRow;
        });
        return modifiedrows;
    };
    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Queue Modal"
                ariaHideApp={false}
                style={queuestyles}
            >
                <div className='flex justify-between items-center mb-3'>
                    <h1 className="text-center flex-grow text-2xl  text-blue-500">Passenger Manifest Details</h1>
                    <button
                        className="text-gray-500 hover:text-gray-700 focus:outline-none mr-3 text-xl"
                        onClick={props.isClose}
                    >
                        <AiOutlineClose />
                    </button>
                </div>
                <div className=' mx-8  my-auto justify-center items-center'>
                    <SimpleTable tableheader={parseQueueHeaderData(QueueHeaderArray)}
                        tableData={parseQueuedata()}
                        tdstyle={Queuedatastyle}
                        background={'bg-customcolor'}
                    />
                </div>
            </Modal>
        </>
    )
}


export default QueueModal;