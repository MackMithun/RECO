import React, { useState } from 'react';
import Modal from 'react-modal';
import { CART_CATEGORY } from '../../constants/Dropdown/dropdownConstants';
import { AiFillPlusCircle, AiOutlineClose } from 'react-icons/ai';
import { ADHOC_MODALSTYLES } from '../../constants/Modal_Styles/customModalStyles'
import Adhoc_reason from '../../../assets/adhocReason.json';
import Adhoc_item from '../../../assets/adhocItems.json';

const AdhocModal = (props: any) => {

    const caterer = [
        {
            "Cater_Code": "AFK",
        },
        {
            "Cater_Code": "OFS"
        },
        {
            "Cater_Code": "TAJ"
        }
    ]
    const [cartCategorySelected, setCartCategorySelected] = useState("Select");
    const [adhocReasonSelected,setAdhocReasonSelected] = useState('Select');
    const [adhocItemSelected,setAdhocItemSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const CartCategory = CART_CATEGORY;
    const adhocreason = Adhoc_reason;
    const adhocitem = Adhoc_item;

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Alert Modal"
                ariaHideApp={false}
                style={customModalStyles}
            >
                <h1 className='w-full flex justify-center items-center text-xl font-semibold mb-2'>Adhoc Flight</h1>
                <button
                    className="text-slate-700 hover:text-slate-900 text-xl focus:outline-none absolute top-2 right-2"
                    onClick={props.closeModal}
                >
                    <AiOutlineClose />
                </button>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-gray-700 text-sm">Cart Category</label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartCategorySelected === "Select" ? "text-gray-400" : ""}`}
                            value={cartCategorySelected}
                            onChange={(e) => setCartCategorySelected(e.target.value)}
                        >
                            {CartCategory.map((item: any, index: number) => (
                                <option value={item.cater_Code} key={index}>{item.value}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="text-gray-700 text-sm">Item</label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartCategorySelected === "Select" ? "text-gray-400" : ""}`}
                            value={adhocItemSelected}
                            onChange={(e) => setAdhocItemSelected(e.target.value)}
                        >
                            {adhocitem.map((item: any, index: number) => (
                                <option value={item.cater_Code} key={index}>{item.ItemName}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="text-gray-700 text-sm">Adhoc reason</label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartCategorySelected === "Select" ? "text-gray-400" : ""}`}
                            value={adhocReasonSelected}
                            onChange={(e) => setAdhocReasonSelected(e.target.value)}
                        >
                            {adhocreason.map((item: any, index: number) => (
                                <option value={item.cater_Code} key={index}>{item.AdhocReason}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="text-gray-700 text-sm">Caterer</label>
                        <select
                            className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown ${catererSelected === 'Select' ? 'text-gray-400' : ''}`}
                            value={catererSelected}
                            onChange={(e) => setCatererSelected(e.target.value)}
                        >
                            {caterer.map((item: any, index: number) => (
                                <option value={item.cater_Code} disabled={item.disabled} key={index}>{item.Cater_Code}</option>
                            ))}
                        </select>
                    </div>
                </div>
                <div className=' lg:w-2/6 xl:w-2/6 md:w-10/12 md:ml-3  flex float-right h-10 mt-6 '>

                    <button type="button" className={`text-green-500 font-bold  text-4xl hover:bg-blue-gray-100 mr-4 justify-items-center rounded-full`} >
                        <AiFillPlusCircle />
                    </button>
                    <button className='bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 w-full  mx-0 my-0   text-white font-semibold rounded-lg'>
                        QR Code
                    </button>
                    <button className='bg-red-500 hover:bg-white hover:text-red-500  border-2 w-full   text-white font-semibold rounded-lg'>
                        Save
                    </button>
                </div>
            </Modal>
        </>
    );
}

export default AdhocModal;

const customModalStyles = ADHOC_MODALSTYLES;