import React from 'react';
import Modal from 'react-modal';
import { AiOutlineLike } from "react-icons/ai";


const InventoryCreationModal = ({isOpen, onClose}:any)=> {
    if (!isOpen) return null;
    const customModalStyles = {
        overlay: {
            backgroundColor: 'rgba(0, 0, 0, 0.5)',zIndex: 1000,transition: 'opacity 0.5s ease-in-out',opacity:  1 ,
        },
        content: {
            top: '50%',
            left: '50%',
            minWidth: '300px',
            maxWidth: '400px',
            maxHeight: '205px',
            transform: `translate(-50%, -50%')`,
            border: 'none',
            borderRadius: '10px',
            padding: '20px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
            background: '#FFFFFF',
            overflow: 'auto',
            transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',
            opacity: 1 ,
        },
    };
  return(
    <>
     <Modal
                isOpen={isOpen}
                contentLabel="Alert Modal"
                ariaHideApp={false}
                style={customModalStyles}
            >
                <div className='text-center'>
                  <div className="flex flex-col items-center justify-center mb-3">
                      <div className="text-green-500 hover:green-red-800 text-4xl mb-1">
                      <AiOutlineLike />
                      </div>
                      <h1 className='text-xl text-green-600 mb-2'>Success</h1>
                      <h1 className="text-blue-700 mb-3 font-bold">
                          Inventory Created Successfully!!
                      </h1>
                      <button
                          className="bg-blue-500 hover:bg-blue-800 text-white font-light py-1 px-1 rounded-lg shadow-md transition duration-300 ease-in-out"
                          onClick={onClose}
                      >
                          OK
                      </button>
                  </div>
              </div>
            </Modal>
    </>
  )
}


export default InventoryCreationModal;