import React, { useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';
import Modal from 'react-modal';
import { CART_CATEGORY } from '../../constants/Dropdown/dropdownConstants';
import { CUSTOMMODAL_STYLES } from '../../constants/Modal_Styles/customModalStyles';
import Toast from '../../Toast/Toast';
import { InfoModal } from '../CustomModal';

const SpillCartAddModal = (props: any) => {
    const [cartCategorySelected, setCartCategorySelected] = useState("Select");
    const [cartSelected, setCartSelected] = useState("Select");
    const [cartList, setCartList] = useState([{ cart: 'Select', id: 0 },]);
    const CartCategory = CART_CATEGORY;
    const isCartDisabled = cartCategorySelected === 'Select';
    const [infoModal, setInfoModal] = useState({ isOpen: false, message: "" });

    const addNewCartHandler = () => {
        if (cartSelected !== "Select" && cartCategorySelected !== "Select") {
            const data = {
                cartCategory: cartCategorySelected,
                cart: cartSelected,
            };
            props.data(data);
            setCartCategorySelected("Select");
            setCartSelected("Select");
        } else {
            setInfoModal({ isOpen: true, message: "please provide all Mandatory inputs" })
        }
    };

    const closemodal = () => {
        setInfoModal({ isOpen: false, message: "" })
    };

    return (
        <>
            <Modal
                isOpen={props.isOpen}
                contentLabel="Spill cart Modal"
                ariaHideApp={false}
                style={CUSTOMMODAL_STYLES}
            >
                <Toast />
                <div className="flex justify-between items-center text-center">
                    <h1></h1>
                    <h2 className="text-lg text-center text-customcolor font-semibold justify-center mt-2 mb-2 ml-6">
                        Add New art
                    </h2>

                    <button
                        className="text-customcolor hover:text-slate-900 text-xl mr-6 mt-2 focus:outline-none"
                        onClick={props.isClose}
                    >
                        <AiOutlineClose />
                    </button>
                </div>

                <div className="flex justify-center items-center">
                    <div className=" w-5/6 h-auto  grid grid-cols-1 md:grid-cols-3 xl:grid-cols-3 gap-3 ">
                        <div className="md:w-6/6 lg:w-6/6">
                            <label className="text-black hover:text-gray-700 text-sm">Cart Category<span className="text-red-400 text-xs inline-block align-top"> &#9733; </span> </label>

                            <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartCategorySelected === "Select" ? "text-gray-400" : ""}`}
                                value={cartCategorySelected} onChange={(e) => setCartCategorySelected(e.target.value)}
                            >
                                {CartCategory !== undefined ? (
                                    CartCategory.map((item: any, index: number) => {
                                        return (
                                            <option value={item.value} id={item.id} key={index}>
                                                {item.value}
                                            </option>
                                        );
                                    })) : (
                                    <></>)}
                            </select>
                        </div>

                        <div className="md:w-6/6 lg:w-6/6 ml-2">
                            <label className="text-black hover:text-gray-700 text-sm">Cart<span className="text-red-400 text-xs inline-block align-top"> &#9733; </span> </label>

                            <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartSelected === "Select" ? "text-gray-400" : ""}`}
                                value={cartSelected}
                                onChange={(e) => setCartSelected(e.target.value)}
                                disabled={isCartDisabled}
                            >
                                {cartList !== undefined ? (
                                    cartList.map((item: any, index: number) => {
                                        return (
                                            <option value={item.cater_Code} id={item.id} key={index}>
                                                {item.value}
                                            </option>
                                        );
                                    })) : (
                                    <></>)}
                            </select>
                        </div>
                        <div className="md:w-6/6 lg:w-6/6 ml-4 mt-1 ">
                            <button
                                onClick={addNewCartHandler}
                                className="bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 mt-5 lg:w-6/6 xl:w-6/6 md:w-6/6 xs:w-6/6 px-14 py-1 h-10 text-white font-semibold rounded-lg "
                            >
                                Add
                            </button>
                        </div>
                    </div>
                </div>

            </Modal>
            <InfoModal isOpen={infoModal.isOpen} message={infoModal.message} isClose={closemodal} />
        </>
    );
}

export default SpillCartAddModal;


