import React from 'react';
import { AiOutlineRedo, AiOutlineMail, AiFillWarning } from 'react-icons/ai';
import Modal from 'react-modal';
import { DELETE_MODALSTYLES, InfocustomModalStyles } from '../constants/Modal_Styles/customModalStyles'



export const DeleteModal = (props: any) => {
    return (
        <Modal
            isOpen={props.isOpen}
            contentLabel="Alert Modal"
            ariaHideApp={false}
            style={DELETE_MODALSTYLES}
        >
            <div className="h-full flex flex-col items-stretch justify-around">
                <p className="text-gray-700 text-center">
                    Are you sure you want to delete ?
                </p>
                <div className='w-full grid grid-cols-2 mt-4'>
                    <button className="bg-blue-500 hover:bg-blue-600 text-white mr-2 px-2 py-1 rounded-md" onClick={props.handleDelete} >
                        Yes
                    </button>
                    <button className="bg-red-500 hover:bg-red-800 text-white font-light py-2 px-3 rounded-lg shadow-md transition duration-300 ease-in-out"
                        onClick={props.isClose}>
                        No
                    </button>
                </div>
            </div>
        </Modal>
    )
}

export const InfoModal = (props: any) => {
    return (
        <Modal
            isOpen={props.isOpen}
            contentLabel="Alert Modal"
            ariaHideApp={false}
            style={InfocustomModalStyles}
        >
            <div className='text-center'>
                <div className="w-full flex flex-col items-center justify-around">
                    <h2 className="text-gray-700 font-medium mb-2">
                        {props.message}
                    </h2>
                   
                    <button className="w-2/4 bg-blue-500 hover:bg-blue-800 text-white font-light mt-4 py-2 px-3 rounded-lg shadow-md transition duration-300 ease-in-out"
                        onClick={props.isClose}>
                        Ok
                    </button>
             
                </div>
            </div>
        </Modal>
    )
}

export const ConfirmModal = (props: any) => {
    return (
        <Modal
            isOpen={props.isOpen}
            contentLabel="Confirm Modal"
            ariaHideApp={false}
            style={DELETE_MODALSTYLES}
        >
            <div className='text-center'>
                <div className="flex flex-col items-center justify-center mb-3">
                    <div className="text-red-500 hover:text-red-800 text-5xl mb-2">
                        {props.icon}
                    </div>
                    <p className="text-gray-700 mb-2">
                        {props.message}
                    </p>
                    <div className='flex mt-4'>
                        <button
                            className="bg-blue-500 hover:bg-blue-600 text-white mr-2 px-2 py-1 rounded-md"
                            onClick={props.action}
                        >
                            Yes
                        </button>
                        <button
                            className="bg-red-500 hover:bg-red-800 text-white font-light py-2 px-3 rounded-lg shadow-md transition duration-300 ease-in-out"
                            onClick={props.isClose}
                        >
                            No
                        </button>
                    </div>
                </div>
            </div>
        </Modal>
    );
}

