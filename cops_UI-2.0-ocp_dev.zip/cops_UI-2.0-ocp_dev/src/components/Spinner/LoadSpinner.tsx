import React from 'react';

const LoadSpinner = () => {
    return (
        <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-75 z-50">
            <div className="flex justify-center items-center text-white">
                <div className="mr-2 font-bold">Loading</div>
                <div className="rounded-full border-t-4 border-b-4 border-customcolor w-6 h-6 animate-spin"></div>
            </div>
        </div>
    );
};

export default LoadSpinner;