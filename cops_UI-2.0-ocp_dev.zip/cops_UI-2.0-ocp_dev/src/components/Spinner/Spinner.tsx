import React from 'react';

const Spinner = () => {
    return (
        <div className="relative flex justify-center items-center h-full">
            <div className="animate-pulse text-gray-800 font-bold">Loading</div>
            <div className="ml-2 rounded-full border-t-4 border-b-4 border-customcolor w-6 h-6 animate-spin"></div>
        </div>
    );
};

export default Spinner;