import React, { useEffect, useState } from 'react'

const FnbTable = (props:any) => {

  const data = props.data;

  console.log(props)
  
  let header=data[0].itmMasterList[0].CartType.map((item: any) => {
    console.log(item.cartName,'item');
    return (item.CartName);
  })
  const FnbHeaderArray = ["DrawerId", "Item", ...header];
  const createHeader = () => {
    return FnbHeaderArray.map((item) => {
      return (
        <><td className='h-10 text-white text-center font-semibold w-28 justify-center items-center border border-r-1 border-solid'>{item}</td></>

      )
    })
  }


  return (
    <>
      <div className='flex-grow mt-5 mx-40  my-auto justify-center items-center max-h-96 overflow-auto scrollbar-hide'>
        <table className='rounded-lg shadow-lg shadow-grey-400/10 w-full max-h-96 overflow-auto scrollbar-hide'>
          <thead className='bg-indigo-500'>
            <tr className='bg-indigo-500 text-xl border border-solid'>
              {createHeader()}
            </tr>
          </thead>

          <tbody>
            {data.map((items:any, index:any) => (
              items.itmMasterList.map((item:any, itemIndex:any) => (
                <tr className={`p-4 ${index % 2 === 0 ? 'bg-gray-500' : 'bg-white'}`} style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} key={`${index}-${itemIndex}`}>
                  {itemIndex === 0 && (
                    <td style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} className='h-8 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid' rowSpan={items.itmMasterList.length}>
                      {items.DrawerId}
                    </td>
                  )}
                  <td className="text-xs">{item.ItemName.toString().toLowerCase()}</td>
                  {items.itmMasterList[0].CartType.map((cart:any) => (
                    <td style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} className='h-8 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid' key={index}>
                      <input className="w-10 text-center border border-blue-100 hover:border-red-500" type="text" value={item.CartType.find(
                        (c:any) => c.CartName === cart.CartName
                      )?.CartItemQty || 0} />
                    </td>
                  ))}
                </tr>
              ))
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}


export default FnbTable;