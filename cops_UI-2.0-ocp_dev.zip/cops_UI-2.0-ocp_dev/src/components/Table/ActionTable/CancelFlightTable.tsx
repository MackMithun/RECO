import React, { useState } from 'react';
import { DataColumnInterface } from '../../../interface/Global interface/DataColumnInterface';
import { HeaderColumnInterface } from '../../../interface/Global interface/HeaderColumnInterface';
import { dataRow, headerRow } from '../../../interface/Global interface/TableInterface';
import SimpleTable from '../SimpleTable';
import { constants } from '../../constants/Action/ActionConstants';


const CancelFlightTable = (props: any) => {
  const headerstyleindex = constants.CancelFlightheaderStyleindex;
  const headerarray = constants.CancelFlightheaderArray;
  const datastyle = constants.dataStyle;

  const [flightsSelected, setFlightsSelected] = useState("Select");
  const [catererSelected, setCatererSelected] = useState("Select");
  const [flightList, setFlightList] = useState([
    { station_Code: "Select", stationID: 0 },
  ]);
  const [catererList, setCatererList] = useState([
    { cater_Code: "Select", id: 0 },
  ]);

  const data = props.data.map((item: any) => {
    return ({
      flightnumber: item.flt_No,
      dep: item.dep,
      arr: item.arr,
      seq: item.seqNo,
      caterer: item.cater_Code,
      aircraftType: item.aircraftType,
    });
  });

  const parseHeaderData = (headerarray: string[]) => {
    return {
      headerColumns: headerarray.map((item: string, index: number) => {
        return {
          isLabel: false,
          labelText: item,
          class: headerstyleindex,
          type: undefined,
        } as HeaderColumnInterface;
      }),
    } as headerRow;
  };

  const parserowData = (data: any[]) => {
    return data.map((item: any) => {
      return {
        flightnumber: item.flightnumber,
        aircraftType: item.aircraftType,
        departure: item.dep,
        Arrival: item.arr,
        Sequence: item.seq,
        caterer: item.caterer,
      } as any;
    });
  };

  const parseColumns = (row: any, index: number): DataColumnInterface[] => {
    let columns = [] as DataColumnInterface[];
    columns.push({
      text: null,
      action: [
        {
          name: "checkbox",
          icon: null,
          type: "checkbox",
          event: checkboxClick,
          parameter: undefined,
        },
      ],
    });
    columns.push({ text: row.flightnumber, action: undefined });
    columns.push({ text: row.aircraftType, action: undefined });
    columns.push({ text: row.departure, action: undefined });
    columns.push({ text: row.Arrival, action: undefined });
    columns.push({ text: row.Sequence, action: undefined });
    columns.push({ text: row.caterer, action: undefined });

    return columns;
  };
  const parsedata = () => {
    console.log(data, "data");
    let unmodifiedrows = parserowData(data);
    let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
      return {
        dataColumns: parseColumns(row, index),
      } as dataRow;
    });
    return modifiedrows;
  };

  const checkboxClick = () => {
    console.log("checkbox clicked");
  };

  return (
    <>
      <div className="flex justify-center items-center">
        <div className="max-w-screen-xl w-full">
          <div className=" mx-14  sm:mt-2 w-full sm:w-11/12 md:w-12/12 lg:w-12/12 xl:w-11/12">
            <SimpleTable
              tableheader={parseHeaderData(headerarray)}
              tableData={parsedata()}
              tdstyle={datastyle}
              background={'bg-customcolor'}
            />
          </div>

          <div className="flex  justify-center sm:justify-end text-center sm:mr-3 md:mr-20 lg:mr-16 xl:mr-16 mt-5">
            <div className="lg:w-1/4 xl:w-1/4 md:w-1/4 md:ml-3 flex h-10">
              <button className="bg-indigo-900 hover:bg-white hover:text-indigo-900 border-2 w-5/6 mx-0 my-0 text-white font-medium rounded-lg hover:font-semibold">
                Confirm
              </button>
              <button type="button"
                className="  hover:text-red-900 border-2 w-5/6 bg-red-900 hover:bg-white  shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none  ml-3 text-white font-medium rounded-lg hover:font-semibold"
                data-ripple-light="true">
                Clear
              </button>
            </div>
          </div>

        </div>
      </div>
    </>
  );
}

export default CancelFlightTable;