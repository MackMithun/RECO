import React, { useEffect, useState } from 'react'
import { AircraftType, } from '../../../services/api-service';

const ChangeAircraftType = (props: any) => {

    const [aircraftList, setAircraftList] = useState([{ aircraftType: 'Select', id: 0 },])
    const [aircraftTypeSelected, setAircraftTypeSelected] = useState('Select');

    async function aircraftType() {
        try {
            const aircraftTypeData = await AircraftType();
            setAircraftList((actype) => [actype[0], ...aircraftTypeData]);
        } catch (error) {
            console.error(error);
        }
    }

    useEffect(() => {
        aircraftType();
    }, [])

    return (
        <>
            <div className='mx-48 my-0 justify-center items-center'>
                <div className='w-3/12 h-2/3 items-center'>
                    <label className='text-gray-500 text-sm w-11/12 '>Aircraft Type</label>
                    <select
                        className={`form-select  w-full  p-2 font-light bg-white
                        border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  ${aircraftTypeSelected === 'Select' ? 'text-gray-400' : ''}`}
                        value={aircraftTypeSelected}
                        onChange={(e) => setAircraftTypeSelected(e.target.value)}
                    >
                        {aircraftList !== undefined ? (
                            aircraftList.map((item: any, index: number) => {
                                return (
                                    <option
                                        value={item.value}
                                        disabled={item.disabled}
                                        id={item.id}
                                        key={index}
                                    >
                                        {item.aircraftType}
                                    </option>
                                );
                            })
                        ) : (
                            <></>
                        )}
                    </select>
                </div>
            </div>

            <div className="flex  justify-center sm:justify-end text-center sm:mr-3 md:mr-20 lg:mr-16 xl:mr-40 mt-5">
                <div className="lg:w-1/4 xl:w-1/4 md:w-1/4 md:ml-3 flex h-10">
                    <button className="bg-indigo-900 hover:bg-white hover:text-indigo-900 border-2 w-5/6 mx-0 my-0 text-white font-semibold rounded-lg">
                        Confirm
                    </button>
                    <button type="button"
                        className="  hover:text-red-900 border-2 w-5/6 bg-red-900 hover:bg-white  shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none  ml-3 text-white font-semibold rounded-lg"
                        data-ripple-light="true">
                        Clear
                    </button>
                </div>
            </div>
        </>
    )
}

export default ChangeAircraftType;
