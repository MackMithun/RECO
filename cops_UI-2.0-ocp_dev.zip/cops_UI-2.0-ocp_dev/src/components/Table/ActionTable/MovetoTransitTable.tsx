import React, { useState } from "react";
import { HeaderColumnInterface } from "../../../interface/Global interface/HeaderColumnInterface";
import { dataRow, headerRow } from "../../../interface/Global interface/TableInterface";
import SimpleTable from "../SimpleTable";
import { constants } from "../../constants/Action/ActionConstants";
import { DataColumnInterface } from "../../../interface/Global interface/DataColumnInterface";

const MovetoTransitTable = (props: any) => {
  const headerstyleindex = constants.MovetoTransitheaderStyleindex;
  const headerarray = constants.MovetoTransitheaderArray;
  const datastyle = constants.dataStyle;

  const [flightsSelected, setFlightsSelected] = useState("Select");
  const [catererSelected, setCatererSelected] = useState("Select");
  const [flightList, setFlightList] = useState([{ station_Code: "Select", stationID: 0 }]);
  const [catererList, setCatererList] = useState([{ cater_Code: "Select", id: 0 }]);
  const [checkboxClicked, setCheckBoxClicked] = useState(false)

  const data = props.data.map((item: any) => {
    return ({
      flightnumber: item.flt_No,
      dep: item.dep,
      arr: item.arr,
      seq: item.seqNo,
      caterer: item.cater_Code,
      aircraftType: item.aircraftType,
    });
  });;

  const parseHeaderData = (headerarray: string[]) => {
    return {
      headerColumns: headerarray.map((item: string, index: number) => {
        return {
          isLabel: false,
          labelText: item,
          class: headerstyleindex,
          type: undefined,
        } as HeaderColumnInterface;
      }),
    } as headerRow;
  };

  const parserowData = (data: any[]) => {
    return data.map((item: any) => {
      return {
        flightnumber: item.flightnumber,
        aircraftType: item.aircraftType,
        departure: item.dep,
        Arrival: item.arr,
        Sequence: item.seq,
        caterer: item.caterer,
      } as any;
    });
  };

  const parseColumns = (row: any, index: number): DataColumnInterface[] => {
    let columns = [] as DataColumnInterface[];
    columns.push({text: null,
      action: [{name: "checkbox",icon: null,type: "checkbox",event: checkboxClickHandler,parameter: undefined,},
      ],});
    columns.push({ text: row.flightnumber, action: undefined });
    columns.push({ text: row.aircraftType, action: undefined });
    columns.push({ text: row.departure, action: undefined });
    columns.push({ text: row.Arrival, action: undefined });
    columns.push({ text: row.Sequence, action: undefined });
    columns.push({ text: row.caterer, action: undefined });

    return columns;
  };

  const parsedata = () => {
    let unmodifiedrows = parserowData(data);
    let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
      return {
        dataColumns: parseColumns(row, index),
      } as dataRow;
    });
    return modifiedrows;
  };

  const checkboxClickHandler = () => {
    setCheckBoxClicked(true); 
  };

  return (
    <div className="flex justify-center items-center">
    <div className="max-w-screen-xl w-full">
      <div className=" mx-14  sm:mt-2 w-full sm:w-11/12 md:w-12/12 lg:w-12/12 xl:w-11/12">
          <SimpleTable
            tableheader={parseHeaderData(headerarray)}
            tableData={parsedata()}
            tdstyle={datastyle}
            background={'bg-customcolor'}
          />
        </div>

        {checkboxClicked &&
          <>
            <div className="flex mt-3 mx-20">
              <div className="w-full sm:w-1/2 md:w-2/3 lg:w-3/4 xl:w-2/4 flex flex-col md:flex-row md:items-start">
                <div className="w-full md:w-1/2 lg:w-1/2 xl:w-1/2 md:mr-2">
                  <label className="text-black text-sm"> Flights<span className="text-red-400 text-xs inline-block align-top"> &#9733;</span></label>
                  <select
                    className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${catererSelected === "Select" ? "text-gray-400" : ""}`}
                    value={flightsSelected}
                    onChange={(e) => setFlightsSelected(e.target.value)}
                  >
                    {flightList.map((item: any, index: number) => (
                      <option
                        value={item.cater_Code}
                        disabled={item.disabled}
                        id={item.id}
                        key={index}
                      >
                        {item.station_Code}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="w-full md:w-1/2 lg:w-1/2 xl:w-1/2 md:ml-2 mt-3 md:mt-0">
                  <label className="text-black text-sm">Caterer<span className="text-red-400 text-xs inline-block align-top"> &#9733;</span></label>
                  <select
                    className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none ${catererSelected === "Select" ? "text-gray-400" : ""}`}
                    value={catererSelected}
                    onChange={(e) => setCatererSelected(e.target.value)}
                  >
                    {catererList.map((item: any, index: number) => (
                      <option
                        value={item.cater_Code}
                        disabled={item.disabled}
                        id={item.id}
                        key={index}
                      >
                        {item.cater_Code}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </>}

        <div className="flex justify-center sm:justify-end text-center sm:mr-3 md:mr-20 lg:mr-16 xl:mr-16 mt-3">
          <div className="lg:w-1/4 xl:w-1/4 md:w-1/4 md:ml-3 flex h-10">
            <button className="bg-indigo-900 hover:bg-white hover:text-indigo-900 border-2 w-5/6 mx-0 my-0 text-white font-medium hover:font-semibold rounded-lg">
              Confirm
            </button>
            <button type="button"
              className="  hover:text-red-900 border-2 w-5/6 bg-red-900 hover:bg-white  shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none  ml-3 text-white font-medium hover:font-semibold rounded-lg"
              data-ripple-light="true">
              Clear
            </button>

          </div>
        </div>
      </div>
    </div>
  );
};

export default MovetoTransitTable;
