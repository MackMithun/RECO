
import React from 'react'
import { DataColumnInterface } from '../../../interface/Global interface/DataColumnInterface';
import { HeaderColumnInterface } from '../../../interface/Global interface/HeaderColumnInterface';
import { dataRow, headerRow } from '../../../interface/Global interface/TableInterface';
import SimpleTable from '../SimpleTable';
import { constants } from '../../constants/Action/ActionConstants';

const ChangeMatricesandPercentageTable = (props: any) => {

    const data = props.data.map((item: any) => {
        return ({
          TxnId: item.txnId,
          GroupId: item.groupId,
          RouteNo: item.routeNo,
          Flt_No: item.flt_No,
          Flt_Dt: item.flt_Dt,
          Dep: item.dep,
          Arr: item.arr,
          SeqNo: item.seqNo,
          STA: item.sta,
          STD: item.std,
          Cater_Code: item.cater_Code,
          R_flag: item.r_flag,
          AircraftType:item.aircraftType,
          terminal: [
            "t1", "t2", "t3"
        ],
        percentage:item.percentage
        });
      });
   

    const headerstyleindex = constants.changeMetricesandPercentageheaderStyleindex;
    const headerArray = constants.changeMetricesandPercentageheaderArray;
    const datastyle = constants.dataStyle;

    const parseHeaderData = (headerArray: string[]) => {
        return {
            headerColumns: headerArray.map((item: string, index: number) => {
                return {
                    isLabel: false,
                    labelText: item,
                    class: headerstyleindex,
                    type: undefined
                } as HeaderColumnInterface;
            })
        } as headerRow
    };

    //Main Table rowData array map
    const parserowData = (data: any[]) => {
        return data.map((item: any) => {
            return {
                STD: item.STD,
                FlightNumber: item.Flt_No,
                STA: item.STA,
                DayDifference: item.R_flag,
                Departure: item.Dep,
                Arrival: item.Arr,
                SeqNo: item.SeqNo,
                Caterer: item.Cater_Code,
                AircraftType:item.AircraftType,
                percentage:item.percentage
            } as any;
        })
    };
    

    //Main Table Column Push for Each Row
    const parsecolumns = (row: any, index: number): DataColumnInterface[] => {
        let columns = [] as DataColumnInterface[];
        columns.push({ text: row.FlightNumber, action: undefined });
        columns.push({ text: row.AircraftType, action: undefined });
        columns.push({ text: row.Departure, action: undefined });
        columns.push({ text: row.Arrival, action: undefined });
        columns.push({ text: row.SeqNo, action: undefined });
        columns.push({ text: row.Caterer, action: undefined });
        columns.push({
            text: null,
            action: [{
                name: row.Arrival, icon: "time", type: "dropdown", event: null, parameter: { row: row }
            }]
        });
        columns.push({
            text: null,
            action: [{
                name: row.Arrival, icon: "time", type: "dropdown", event: null, parameter: { row: row }
            }]
        });
        columns.push({
            text: null,
            action: [{
                name: row.Arrival, icon: "time", type: "dropdown", event: null, parameter: { row: row }
            }]
        });
        columns.push({
            text: null,
            action: [{
                name: row.Arrival, icon: "time", type: "dropdown", event: null, parameter: { row: row }
            }]
        });
      

        columns.push({
            text: null,
            action: [{
                name: row.percentage, icon: "time", type: "action-input", event: null, parameter: { row: row }
            }]
        });
        return columns;
    }

    //Data row Insert
    const parsedata = () => {
        let unmodifiedrows = parserowData(data);
        let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
            return {
                dataColumns: parsecolumns(row, index)
            } as dataRow;
        });
        return modifiedrows;
    };

    return (
        <>
            <div className="flex">
                <div className="max-w-screen-xl w-full">
                    {/* <div className="mx-28 mt-2 w-full"> */}
                    <div className="mx-10 mt-2 w-full">
                        <SimpleTable tableheader={parseHeaderData(headerArray)}
                            tableData={parsedata()}
                            tdstyle={datastyle}
                            background={"bg-customcolor"}
                        />
                    </div>

                    <div className="flex  justify-center sm:justify-end text-center sm:mr-3 md:mr-20 lg:mr-16 xl:mr- mt-5">
                        <div className="lg:w-1/4 xl:w-1/4 md:w-1/4 md:ml-3 flex h-10">
                            <button className="bg-indigo-900 hover:bg-white hover:text-indigo-900 border-2 w-5/6 mx-0 my-0 text-white font-medium rounded-lg">
                            Confirm
                            </button>
                            <button type="button"
                                className="  hover:text-red-900 border-2 w-5/6 bg-red-900 hover:bg-white  shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none  ml-3 text-white font-medium rounded-lg"
                                data-ripple-light="true">
                                Clear
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )

}

export default ChangeMatricesandPercentageTable;