import React from 'react';

const ManufactureSheetTable = (props: any) => {
    const { Tableheader, tableRowData } = props;

    const GetTableHeader = () => {
        return Tableheader.map((row: any, index: any) => {
            if (index > 0) {
                return (
                    <tr key={index} className="bg-indigo-200 text-white">
                        {row.lstcolumnData.map((item: any, idx: any) => {
                            return (<td key={idx} className="p-2 border border-1 text-center" colSpan={item.mergeright}>
                                {(item.dataValue.trim() !== "" && item.dataValue.trim() !== "-") && item.dataValue}
                            </td>);
                        })}
                    </tr>);
            }
            else
            {
                return (
                    <tr key={index} className="bg-indigo-200 text-white">
                        <td key={index} className="p-2 border boorder-1 text-center" colSpan={row.lstcolumnData[0].mergeright + 1}>
                            {row.lstcolumnData[0].dataValue.trim() !== "" && row.lstcolumnData[0].dataValue}
                        </td>
                    </tr>); 
            }
        });
    };

    const GetTableDataRow = () => {
        return tableRowData.map((row:any, index:any) => (
            <tr key={index}>
                {row.lstcolumnData.map((item:any, idx:any) => (
                    <td key={idx} className="p-2 border boorder-1 text-center" colSpan={item.mergeright}>
                        {item.dataValue.trim() !== "" && item.dataValue}
                    </td>
                ))}
            </tr>
        ));
    };
    return (
        <div className='w-full grid grid-cols-1 ml-14'>
            <table className='w-fit'>   
                <thead>
                    {GetTableHeader()}
                </thead>
                <tbody>
                    {GetTableDataRow()}
                </tbody>
            </table>
            <div className='h-10'></div>
        </div>
    );
};

export default ManufactureSheetTable;

