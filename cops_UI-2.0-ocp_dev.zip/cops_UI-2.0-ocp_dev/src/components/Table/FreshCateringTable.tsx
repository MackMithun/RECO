import React, { useEffect, useState } from "react";
import {  useNavigate } from "react-router-dom";
import { Flight } from "../../interface/Models/Flight";
import { Deleteinventory, getFreshcateringData, InventoryCreation } from "../../services/FreshCateringService";
import { InfoModal } from "../Modal/CustomModal";
import ActionModal from '../Action/ActionModal';
import LoadSpinner from "../Spinner/LoadSpinner";

export default function FreshCateringTable(props: any) {
  const navigate = useNavigate();
  const [data, setData] = useState<Flight[]>([]);
  const [defaultData, setDefaultData] = useState<Flight[]>([]);
  const typeSelected = props.searchData.type === "Fresh Catering";

  const [conditions, setConditions] = useState({ isLoading: false, dataFound: false });
  const [modalisOpen, setModalisOpen] = useState<any>({ searchClick: false });
  const [infoModal, setInfoModal] = useState({ isOpen: false, message: "" });
  const [actionModal , setActionModal] = useState({isOpen:false , state:{}})

  const fetchData = () => {
    const { flightDate, station, aircraftType } = props.searchData;
    setConditions({ isLoading: true, dataFound: false });
    getFreshcateringData({ flightDate, station, aircraftType, typeSelected })
      .then((data: any) => {
        setData(data);
        setDefaultData(data);
        setConditions({ isLoading: false, dataFound: true });
        setModalisOpen({ searchClick: true });
      })
      .catch(() => {
        setData([]);
        setModalisOpen({ searchClick: true });
        setConditions({ isLoading: false, dataFound: false });
      });
  };

  useEffect(() => {
    fetchData();
  }, [props.searchData]);

  useEffect(() => {
    SearchApply();
  }, [props.filterData]);

  const SearchApply = () => {
    const { inputdata, type }: any = props.filterData;
    let filteredData = defaultData.map((flight: any) => {
      let filteredFlightInfo = flight.flightInfo.filter((item: any) => {
        switch (type) {
          case 'Departure':
            return item.dep.toLowerCase().startsWith(inputdata.toLowerCase())
          case 'Flight Number':
            return item.flt_No.toString().toLowerCase().startsWith(inputdata.toLowerCase());
          case 'Caterer':
            return item.cater_Code.toLowerCase().startsWith(inputdata.toLowerCase());
          case 'Route ID':
            return item.routeNo.toString().toLowerCase().startsWith(inputdata.toLowerCase());
          case 'Flight Type':
            return item.flightType.toLowerCase().startsWith(inputdata.toLowerCase() === 'domestic' ? 'd' : inputdata.toLowerCase() === 'international' ? 'i' : '');
          default:
            return true;
        }
      });

      if (filteredFlightInfo.length > 0) {
        return { ...flight, flightInfo: filteredFlightInfo };
      } else {
        return null;
      }
    }).filter((flight: any) => flight !== null);

    if (filteredData.length > 0) {
      setData(filteredData);
    } else {
      setData([]);
    }
  }

  const createInventory = (groupId: any) => {
    setConditions({ isLoading: true, dataFound: true })
    const { flightDate, station, aircraftType } = props.searchData;
    InventoryCreation({ flightDate, groupId })
      .then(() => {
        setInfoModal({ isOpen: true, message: "Inventory creation success" });
        fetchData()
        setConditions({ isLoading: false, dataFound: true })
      })
      .catch(() => {
        setInfoModal({ isOpen: true, message: "Failed to create inventory" });
      });
  };

  const deleteinventory = (deleteRowId: any) => {
    Deleteinventory(deleteRowId)
      .then(() => {
        const newData = data.filter((_, index) => index !== deleteRowId);
        setData(newData);
        setInfoModal({ isOpen: true, message: "Inventory Deleted successfully" });
      })
      .catch(() => {
        setInfoModal({ isOpen: true, message: "Failed to Delete inventory" });
      });
  };

  const EditInventory = (flight: any) => {
    navigate('/fltinfo/edit', { replace: false, state: { flight } });

  };

  const EditAction = (obj: any) => {
    // navigate('/fltinfo/action', { replace: false, state: { obj } });    
    setActionModal({isOpen:true , state:obj})
  };

  const headerArray = ['Flight Date & Time', 'Flight No', 'Departure', 'Arrival', 'Sequence', 'Flight Type', 'Is Topup', 'Caterer Code', 'Matrix', 'Category'];
  const widths = ['w-44', 'w-28', 'w-28', 'w-28', 'w-28', 'w-28', 'w-24', 'w-32', 'w-24', 'w-24'];
  const style = "h-10 ml-2 sticky top-0 z-1 text-center font-sm justify-center items-center border border-r-1 border-solid";
  const printTypes: string[] = ["CHS", "MHS", "QR", "MPos QR", "Blank HOS"];
  const createHeader = headerArray.map((item, index) => (
    <td
      key={index}
      className={`h-10 shadow-md sticky top-0 z-4 text-white bg-customcolor text-center font-medium justify-center items-center border border-r-1 border-solid ${widths[index]}`}
    >
      {item}
    </td>
  ));

  const getStyle = (index: number) => style + ' ' + widths[index];
  const dateFormat = (date: Date) => {
    const hh = date.getHours().toString().padStart(2, '0');
    const mm = date.getMinutes().toString().padStart(2, '0');
    return `${date.toLocaleDateString()} ${hh}:${mm}`;
  };

  const closemodal = () => {
    setInfoModal({ isOpen: false, message: "" })
    setActionModal({ isOpen:false, state:{}})
  }

  return (
    <>  
    <div className="max-h-102 overflow-auto scrollbar-hide">
      <div className="ml-16 w-11/12 mt-8 max-h-96 overflow-auto scrollbar-hide">
      {conditions.isLoading && <LoadSpinner />}
        {data && data.length > 0 ? ( 
          <table className="w-full">
            <thead>
              <tr>{createHeader}</tr> 
            </thead>

            <tbody>
              <tr className="w-full">
                <td className="w-full border" colSpan={createHeader.length}>
                  {data.map((flight, index) => (
                    <React.Fragment key={index}>
                      <div className="h-16 bg-indigo-100 flex flex-row bg-neutral-300 border border-1 border-gray-500 p-3 mt-1 place-content-between items-center -z-9999" id="header">
                        <div className="text-md">{flight.aircraftType} -  Route {flight.routeNo}</div>
                        {flight.ciid === 0 ? (
                          <>
                            <div className="w-2/6 p-1 grid grid-cols-3 items-center place-content-around">
                              {printTypes.map((val) => (
                                <div key={val} className="w-full p-1 grid grid-cols-3 place-content-around">
                                  <input className="w-4 h-4" type="checkbox" />
                                  <button className="float-left text-left underline col-span-2 h-4 text-xs">{val}</button>
                                </div>
                              ))}
                            </div>
                            <button className="p-2 float-right border border-1 rounded  text-sm font-medium text-customcolor bg-white" onClick={() => {
                              if (flight.flightInfo.length > 0) {
                                createInventory(flight.flightInfo[0].groupId);
                              }
                            }}>Create Inventory</button>
                          </>
                        ) : (
                          <div className="w-9/12 flex flex-row place-content-between items-center">
                            <div className="w-2/6 p-1 grid grid-cols-3 items-center place-content-around">
                              {printTypes.map((val) => (
                                <div key={val} className="w-full p-1 grid grid-cols-3 place-content-around">
                                  <input className="w-4 h-4" type="checkbox" />
                                  <button className="float-left text-left underline col-span-2 h-4 text-xs">{val}</button>
                                </div>
                              ))}
                            </div>
                            <button className="p-2 w-28 rounded text-xs bg-white  font-bold text-customcolor">Cart Allocation</button>
                            <button className="p-2 border border-1 w-32 rounded text-xs bg-white font-bold	 text-indigo-400 " onClick={() => EditAction(flight.flightInfo)}>Action</button>
                            <button className="p-2 border border-1 w-32 rounded text-xs bg-white font-bold text-customcolor" onClick={() => EditInventory(flight.flightInfo[0])}>Edit Inventory</button>
                            <button className="p-2 border border-1 w-32 rounded text-xs bg-white font-bold text-red-600" onClick={() => {
                              if (flight.flightInfo.length > 0) {
                                deleteinventory(flight.flightInfo[0].ciid);
                              }
                            }}>Delete Inventory</button>
                          </div>
                        )}
                      </div>
                      <div className="border border-1 border-gray-600 w-full">
                        <table className="w-full">
                          <tbody>
                            {flight.flightInfo.map((flightInfo: any, i: number) => (
                              <tr key={i}>
                                <td className={getStyle(0)}>{dateFormat(new Date(flightInfo.flt_Dt))}</td>
                                <td className={getStyle(1)}>{flightInfo.flt_No}</td>
                                <td className={getStyle(2)}>{flightInfo.dep}</td>
                                <td className={getStyle(3)}>{flightInfo.arr}</td>
                                <td className={getStyle(4)}>{flightInfo.seqNo}</td>
                                <td className={getStyle(5)}>{flightInfo.flightType}</td>
                                <td className={getStyle(6)}>{flightInfo.isTopup ? 'Yes' : 'No'}</td>
                                <td className={getStyle(7)}>{flightInfo.cater_Code}</td>
                                <td className={getStyle(8)}>{flightInfo.varMatrixCode}</td>
                                <td className={getStyle(9)}>{flightInfo.category}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </React.Fragment>
                  ))}
                </td>
              </tr>
            </tbody>
          </table>
        ) : (
          <div className='w-full grid justify-center items-center mt-12 mb-5'>
            <div className='transition duration-150 ease-in-out hover:text-red-600'>
              {!conditions.isLoading && <h1 className='font-medium text-red-500'>No Data found</h1>}
            </div>
          </div>
        )}
        <InfoModal isOpen={infoModal.isOpen} message={infoModal.message} isClose={closemodal} />
      {actionModal.isOpen && <ActionModal isOpen={actionModal.isOpen} isClose={closemodal} state ={actionModal.state}/> }
      </div>
    </div>
    </>
  );
}
