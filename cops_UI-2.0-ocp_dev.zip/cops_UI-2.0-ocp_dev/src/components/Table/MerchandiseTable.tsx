import React, { useEffect, useState } from 'react'

const MerchandiseTable = (props:any) => {

   const data1 = [
    {
      "DrawarId": 1,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [
        {
          "ItemId": 100005,
          "DrawerID": 1,
          "ItemName": "XL 1st WINDOW/AISLE - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 1,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100006,
          "DrawerID": 1,
          "ItemName": "XL OTHERS - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 2,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100007,
          "DrawerID": 1,
          "ItemName": "XL 1st WINDOW/AISLE - CPTR - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 3,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100008,
          "DrawerID": 1,
          "ItemName": "XL OTHERS - CPTR - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 4,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        }
      ],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    },
    {
      "DrawarId": 2,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [
        {
          "ItemId": 100005,
          "DrawerID": 1,
          "ItemName": "XL 1st WINDOW/AISLE - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 1,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100006,
          "DrawerID": 1,
          "ItemName": "XL OTHERS - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 2,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100007,
          "DrawerID": 1,
          "ItemName": "XL 1st WINDOW/AISLE - CPTR - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 3,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        },
        {
          "ItemId": 100008,
          "DrawerID": 1,
          "ItemName": "XL OTHERS - CPTR - D",
          "CIID": 5915926,
          "EntryLimit": null,
          "CartType": [
            {
              "InventoryId": 5915926,
              "CartName": "MHS",
              "CartItemQty": 20,
              "SpillCart": false,
              "T_CI_ItemQtyId": null,
              "SeqNo": 4,
              "M_CartId": 0,
              "CartId": 0,
              "EditFlag": true,
              "EntryLimit": 999,
              "InitQty": null,
              "TotalQty": 0,
              "HandoverStatus": null,
              "AdhocQty": 0,
              "TopUpQty": 0,
              "IsDisabled": false
            }
          ],
          "singleCart": null,
          "AircraftTypeId": 0
        }
      ],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    },
    {
      "DrawarId": 3,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    },
    {
      "DrawarId": 4,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    },
    {
      "DrawarId": 5,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    },
    {
      "DrawarId": 6,
      "FromDate": "2024-01-08T00:00:00",
      "GroupId": 48,
      "itmMasterList": [],
      "CreatedBy": "sanjeev.kumar6",
      "SpillCart": false,
      "UserRole": true
    }
  ]
  
      const FnbHeaderArray = ["DrawerId", "Item" , "MHS"];


      const createHeader = () => {
        return FnbHeaderArray.map((item) => {
            return (
                <><td className='h-10 text-white text-center font-semibold w-48 justify-center items-center border border-r-1 border-solid'>{item}</td></>
                
            )
        })
      }


    return (
        <>
        <div className='flex-grow mt-5 mx-72  my-auto justify-center items-center'>
        <table  className='rounded-lg shadow-lg shadow-grey-400/10'>
            <thead className='bg-indigo-500'>
                <tr className='bg-indigo-500 text-xl border border-solid'>
                    {createHeader()}
                </tr>
            </thead>

            <tbody>
                {data1.map((items, index) => (
                    items.itmMasterList.map((item, itemIndex) => (
                        <tr className={`p-4 ${index % 2 === 0 ? 'bg-gray-500' : 'bg-white'}`}  style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} key={`${index}-${itemIndex}`}>
                            {itemIndex === 0 && (
                                <td style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} className='h-8 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid' rowSpan={items.itmMasterList.length}>
                                    {items.DrawarId}
                                </td>
                            )}
                            <td className='w-72 text-center text-sm'>{item.ItemName}</td>
                            {items.itmMasterList[0].CartType.map((cart) => (
                                <td  style={{ background: index % 2 === 0 ? '#f3f4f6' : '#ffffff' }} className='h-8 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid' key={index}>
                                  <input className="w-10 text-center border border-blue-100 hover:border-red-500" type="text" value={item.CartType.find(
                                (c) => c.CartName === cart.CartName
                              )?.CartItemQty || 0} />
                                </td>
                            ))}
                        </tr>
                    ))
                ))}
            </tbody>
        </table>
        </div>
    </>
    )
}


export default MerchandiseTable;