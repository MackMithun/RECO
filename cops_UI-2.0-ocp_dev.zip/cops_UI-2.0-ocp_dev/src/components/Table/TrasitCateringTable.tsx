import React, { useState, useEffect } from "react";
import { AiOutlineClose } from "react-icons/ai";
import { DataColumnInterface } from "../../interface/Global interface/DataColumnInterface";
import { HeaderColumnInterface } from "../../interface/Global interface/HeaderColumnInterface";
import { dataRow, headerRow } from "../../interface/Global interface/TableInterface";
import { constants } from "../constants/FlightInfo/Flightinfo"
import SimpleTable from "./SimpleTable";
import Modal from 'react-modal'
import { toast } from "react-toastify";
import Toast from "../Toast/Toast";
import { Flight } from "../../interface/Models/Flight";
import { environment } from "../../environments/environment.dev";
import Spinner from "../Spinner/Spinner";
import { GiCommercialAirplane } from "react-icons/gi";
import { BsFillCartFill } from "react-icons/bs";
import { Transit_CUSTOMMODALSTYLES } from '../constants/Modal_Styles/customModalStyles'
import { getTransitcateringData } from "../../services/TransitCateringService";

const TransitCateringTable = (props: any) => {
  const headerstyleindex = constants.headerstyleindex;
  const datastyle = constants.dataStyle;
  const headerArray = constants.headerArray;
  const [data, setData] = useState<Flight[]>([]);

  const [conditions, setConditions] = useState({ isLoading: false, dataFound: false });
  const [modalisOpen, setModalisOpen] = useState<any>({searchClick: false,})
  const [infoModal , setInfoModal] = useState({isOpen:false, message:""});
  const typeSelected = props.searchData.type === "Fresh Catering" ? true : false;


  const fetchData = () => {
    const { flightDate, station, aircraftType } = props.searchData
    setConditions({ isLoading: true, dataFound: false });
    getTransitcateringData({flightDate, station, aircraftType}).then((data:any) => {
        // SearchApply(data, searchData);
        setData(data);
        setConditions({ isLoading: false, dataFound: true });
        setModalisOpen({ searchClick: true})
    }).catch(() => {
        setData([]);
        setModalisOpen({ searchClick: true})
        setConditions({ isLoading: false, dataFound: false });
    });
}

  useEffect(() => {
    fetchData();
  }, [props.searchData])


  const dateFormat = (date: Date) => {
    let hh = (date.getHours().toString().length < 2 ? ("0" + date.getHours().toString()) : date.getHours().toString());
    let mm = (date.getMinutes().toString().length < 2 ? ("0" + date.getMinutes().toString()) : date.getMinutes().toString());
    return date.toLocaleDateString() + " " + hh + ":" + mm;
  }

  const parseHeaderData = (headerArray: string[]) => {
    return {
      headerColumns: headerArray.map((item: string, index: number) => {
        return {
          isLabel: false,
          labelText: item,
          class: headerstyleindex,
          type: undefined
        } as HeaderColumnInterface;
      })
    } as headerRow
  };

  const parserowData = (data: Flight[]) => {
    const rows = data.flatMap((flight: Flight) => {
      return flight.flightInfo.map((flightInfo: any) => {
        return {
          flightdate: dateFormat(new Date(flightInfo.flt_Dt)),
          flightNumber: flightInfo.flt_No,
          Departure: flightInfo.dep,
          Arrival: flightInfo.arr,
          Sequence: flightInfo.seqNo,
          FlightType: flightInfo.flightType,
          Caterercode: flightInfo.cater_Code,
          matrix: flightInfo.fixedItemTemplate,
          category: flightInfo.category,
          istopUp: flightInfo.istopUp
        };
      });
    });

    return rows;
  };

  const parsecolumns = (row: any, index: number): DataColumnInterface[] => {
    let columns = [] as DataColumnInterface[];
    columns.push({ text: row.flightdate, action: undefined });
    columns.push({text: null, action: [{name: row.flightNumber, icon: <GiCommercialAirplane />, type: "icon-text", event: btnAircraftChange, parameter: { index: index }}]});
    columns.push({text: null, action: [{ name: row.Departure, icon: <BsFillCartFill />, type: "icon-text", event: btnCatererChange, parameter: { index: index }},]});
    columns.push({ text: row.Arrival, action: undefined });
    columns.push({ text: row.Sequence, action: undefined });
    columns.push({ text: row.FlightType, action: undefined });
    if (row.istopUp == true) {
      columns.push({ text: null, action: [{name: 'checkbox', icon: null, type: "checkbox-true", event: undefined, parameter: undefined}]})}
    else {
      columns.push({ text: null, action: [{name: 'checkbox', icon: null, type: "checkbox", event: undefined, parameter: undefined }]})
    }
    columns.push({ text: row.Caterercode, action: undefined });
    columns.push({ text: row.matrix, action: undefined });
    columns.push({ text: row.category, action: undefined });
    return columns;
  }

  const parsedata = () => {
    let unmodifiedrows = parserowData(data);
    let modifiedrows = unmodifiedrows.map((row: any, index: number) => {
      return {
        dataColumns: parsecolumns(row, index)
      } as dataRow;
    });
    return modifiedrows;
  };

  const btnAircraftChange = () => {
    // setshowtoast(false);
    // setAircraftTypeModalIsOpen(true);
    return true
  }

  const btnCatererChange = () => {
    // setshowtoast(false);
    // setCatererModalIsOpen(true)
    return true
  }

  // const closeModal = () => {
  //   // setshowtoast(true);
  //   // setCatererModalIsOpen(false);
  //   // setAircraftTypeModalIsOpen(false);
  // }
  // const ConfirmHandler = () => {

  // }

  return (
    <div className=" w-full ">
      {!conditions.isLoading && conditions.dataFound ? <div className='mx-28 w-full mt-5 my-0 justify-center items-center '>
        <SimpleTable
          tableheader={parseHeaderData(headerArray)} tableData={parsedata()}
          tdstyle={datastyle} background={"z-5 sticky w-full top-0 bg-customcolor"}
        />
      </div> : !conditions.isLoading && !conditions.dataFound && (<div className='w-full grid justify-center items-center mt-12 mb-5'>
        <div className='transition duration-150 ease-in-out hover:text-red-600'>
          {/* <h1 className='text-5xl  w-full grid justify-center items-center'><AiOutlineSearch/></h1>  */}
          <h1 className='font-medium text-red-500'>No Data found</h1>
        </div>
      </div>)
      }
      {conditions.isLoading && <div className="mt-10"><Spinner /></div>}
    </div>
  );
};

export default TransitCateringTable;