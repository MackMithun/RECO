import React, { useState } from 'react';
import { HeaderColumnInterface } from '../../interface/Global interface/HeaderColumnInterface';
import { DataColumnInterface } from '../../interface/Global interface/DataColumnInterface';
import { dataRow } from '../../interface/Global interface/TableInterface';

import { TimeValidity } from '../../helpers/mapper';


const SimpleTable = (props: any) => {

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = (props.itemsPerPage != null && props.itemsPerPage != undefined) ? props.itemsPerPage : 10;
  const totalItems = props.tableData.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const paginateData = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return props.tableData.slice(startIndex, endIndex);
  };

  const handlePageChange = (newPageIndex: any) => {
    setCurrentPage(newPageIndex);
  };

  const range = (start: number, stop: number, step: number) => {
   return Array.from({ length: (stop - start) / step + 1 }, (_, i) => start + i * step);
  }

  const pageNumber = () => {
    return (<>
      {
       
        <>
          {currentPage >= 5 && <button onClick={() => { handlePageChange(1) }}> ...</button>}
          {
            range(currentPage - 1, (currentPage <= totalPages - 4) ? currentPage + 3 : totalPages - 1, 1).map((index) => {
              return (
                <button
                  key={index}
                  className={`px-1 py-1 mx-1 rounded-lg hover:font-bold  ${currentPage === index + 1
                    ? 'text-customcolor font-bold'
                    : 'text-gray-400'
                    }`}
                  onClick={() => handlePageChange(index + 1)}
                >
                  {index + 1}
                </button>
              );
            })
          }
          {currentPage >= 1 && <button onClick={() => { handlePageChange(totalPages - 1) }}> ...</button>}
        </>      
      }
    </>);
    
  }
  const renderPaginationControls = () => {
    if (totalPages > 1) {
      return (
        <div className="flex justify-center items-center mt-3">
          {/* Previous button */}
          <button
            className="bg-white hover:bg-gray-200 text-customcolor border 2px px-2 py-2 font-medium rounded-lg mr-1"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            Previous
          </button>
          {/* Page buttons */}
          {pageNumber()}
          {/* Next button */}
          <button
            className="bg-white hover:bg-gray-200 text-customcolor border 2px px-4 py-2 font-medium rounded-lg mr-2"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      );
    } else {
      return null;
    }
  };
  
  

  //checkbox
  const [allChecked, setAllChecked] = useState(false);
  const [individualCheckboxes, setIndividualCheckboxes] = useState(
    props.tableData.map(() => false)
  );

  const toggleIndividualCheckbox = (rowIndex: number) => {
    const newIndividualCheckboxes = [...individualCheckboxes];
    newIndividualCheckboxes[rowIndex] = !newIndividualCheckboxes[rowIndex];
    setIndividualCheckboxes(newIndividualCheckboxes);

  };

  const toggleAllCheckboxes = () => {
    setAllChecked(!allChecked);
    setIndividualCheckboxes(props.tableData.map(() => !allChecked));
  };

  //Header
  const createHeader = (table: HeaderColumnInterface[]) => {
    return table.map((item: HeaderColumnInterface, index: number) => {
      if (item.type === "checkbox") {
        return (
          <th key={index} className='bg-indigo-500 text-xl border border-solid '>
            <input
              id="checkbox"
              type="checkbox"
              name="checkbox"
              className={item.class[index]}
              onClick={toggleAllCheckboxes}
              checked={allChecked}
            />
          </th>
        );
      }
      return (

        <th key={index} className={item.class[index]}>
          {item.labelText}
        </th>
      );
    });
  };


  //Table row
  const Createdatarow = (data: dataRow[]) => {

    return data.map((item: dataRow, index: number) => {
      return (
        <tr key={index}>
          {createcolumn(item.dataColumns, index)}
        </tr>
      );
    });

  };

  const onTextChange = (eventValue: any) => {
    if (!TimeValidity(eventValue.target.value)) {
       return false;
    }
  }
  
  const createcolumn = (row: DataColumnInterface[], rowIndex: number) => {

    return row.map((item: DataColumnInterface, index: number) => {
      if (item.action === undefined) {
        return (
          <td key={index} className={`${props.tdstyle} `}>
            {item.text}
          </td>
        );
      }
      if (item.action !== undefined && item.action.length > 0) {
        const controls = item.action?.map((evt: any, index: number) => {
          if (evt.type === "checkbox1") {
            return (
              <input
                key={index}
                id={`checkbox-${rowIndex}-${index}`}
                type="checkbox"
                name="checkbox"
                className='text-blue-900 font-bold grid justify-items-center w-full rounded-full'
                onChange={() => toggleIndividualCheckbox(rowIndex)}
                checked={individualCheckboxes[rowIndex]}
              />
            );
          } else if (evt.type === "checkbox") {
            return (
              <input
              
                id="checkbox"
                type="checkbox"
                name="checkbox"
                className='text-blue-900 font-bold grid justify-items-center w-24 rounded-full'
                onChange={evt.event}
              />
            )
          }
          // else if (evt.type === "checkbox-true") {
          //   return (
          //     <input
          //       id="checkbox"
          //       type="checkbox"
          //       name="checkbox"
          //       checked={true}
          //       className='text-blue-900 font-bold grid justify-items-center w-24 rounded-full'
          //       onChange={evt.event}
          //     />
          //   )
          // }
          else if (evt.type === 'icon') {
            return (
              <>
                  <button key={index} type="button" className={`text-iconColor font-bold  text-xl hover:bg-blue-gray-100 p-2 justify-items-center rounded-full`} onClick={(e) => { evt.event(evt.parameter) }} onMouseEnter={(evt) => {
                  }}>
                    {evt.icon}
                  </button>
              </>)
          }
          else if (evt.type === 'icon-text') {
            return (
              <>
                <div className='flex'>
                  <button key={index} type="button" className={`text-iconColor font-bold  text-xl hover:bg-blue-gray-100 p-2 ml-2 justify-items-center rounded-full`} onClick={(e) => { evt.event(evt.parameter) }} onMouseEnter={(evt) => {
                  }}>
                    {evt.icon}
                  </button>
                  <h1 className='h-9 p-2 ml-2 bg-white text-center justify-center items-center' >
                    {evt.name}
                  </h1>
                </div>
              </>)
          }
          else if (evt.type === 'icon-Disabled') {
            return (
              <>
                <button type="button" className=" text-blue-100 font-bold  text-xl  p-2 justify-items-center rounded-full" disabled> {evt.icon}</button>
              </>)
          }
          else if (evt.type === 'link') {
            let linkClass = "";
            switch (evt.name.toLowerCase()) {
                case "started":
                linkClass = "text-blue-gray-700 hover:text-white bg-blue-gray-400 hover:bg-blue-gray-700 ";
                break;  
              case "yet to start":
                linkClass = "text-gray-700 hover:text-white bg-gray-300 hover:bg-gray-500  ";
                break;
              case "processing":
                linkClass = "text-blue-500 hover:text-white  hover:bg-blue-700 bg-blue-200";
                break;
              case "success":
                linkClass = "text-green-500 hover:text-white hover:bg-green-700 bg-green-200";
                break;
                case "failed":
                linkClass = "text-red-500 hover:text-white bg-red-200 hover:bg-red-500 ";
                break;
              default:
                linkClass = "";
            }
            return (
              <button key={index} type="button" className={`${linkClass} w-28 background-transparent font-bold uppercase px-3 py-1 text-xs outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150 rounded-lg `} onClick={(e) => { evt.event(evt.parameter) }} onMouseEnter={(evt) => {
              }}>
                {evt.name}
              </button>
            )
          }
          else if (evt.type === 'queue-link') {
            let linkClass = "";
            switch (evt.name.toLowerCase()) {
              case "yet to start":
                linkClass = "text-gray-700 hover:text-white bg-gray-300 hover:bg-gray-500  ";
                break;
              case "processing":
                linkClass = "text-blue-500 hover:text-white  hover:bg-blue-700 bg-blue-200";
                break;
              case "success":
                linkClass = "text-green-500 hover:text-white hover:bg-green-700 bg-green-200";
                break;
                case "failed":
                linkClass = "text-red-500 hover:text-white bg-red-200 hover:bg-red-500 ";
                break;
              default:
                linkClass = "";
            }
            return (
              <button key={index} type="button" className={`${linkClass} w-20 background-transparent font-bold uppercase px-3 py-1 text-xs outline-none focus:outline-none mr-1 mb-1 ease-linear transition-all duration-150 rounded-lg `} >
                {evt.name}
              </button>
            )
          }
          else if (evt.type === 'text') {
            return (
              <td >
                {evt.name}
              </td>
            )
          }
          else if (evt.type === 'input') {
            return (
              <>
                {evt.name.trim().split(" ")[0]}
                <input key={evt} type="text"
                  className='p-1 text-white-900 border border-gray-300 grid grid-cols-2 text-center rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full'
                  onBlur={(e: any) => { e.target.value = evt.event(e.target.value); }}
                  defaultValue={evt.name.split(" ")[1]}
                />
              </>
            )
          }
          else if (evt.type === 'timeinput') {
            return (
              <>
                {evt.name.trim().split(" ")[0]}
                <input key={evt} type="text" maxLength={5}
                  className='p-1 text-white-900 border border-gray-300 grid grid-cols-2 text-center rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full'
                  onBlur={(e: any) => { e.target.value = evt.event(e.target.value); }}
                  onChange={(e: any) => onTextChange(evt.event(e))}
                  defaultValue={evt.name.split(" ")[1]}
                />
              </>
            )
          }
        
          else if (evt.type === 'action-input') {
            return (
              <>
                <input key={evt} type="text"
                  className='p-1 text-white-900  h-7 uppercase border border-gray-300 grid grid-cols-2 text-center rounded-lg bg-white focus:text-gray-700  ml-4 focus:bg-white focus:border-blue-600 focus:outline-none w-2/3'
                  defaultValue={evt.name}
                />
              </>
            )
          }
          else if (evt.type === 'Alert-input') {
            return (
              <>
                <input key={evt} type="text"
                  className='p-1 text-white-900 border border-gray-300 grid grid-cols-2 text-center rounded-lg bg-white focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none w-full'
                  placeholder={evt.name}
                  defaultValue={evt.name}
                />
              </>
            )
          }
          else if (evt.type === 'dropdown') {
            return (
              <>
                <div className='w-full h-2/3 items-center '>
                  <select className={`form-select  w-4/5 h-8  p-1.5 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none  `}
                    onChange={(e) => (e.target.value)}
                  >
                    {"hello" !== undefined ? (
                      ['h1'].map((item: any, index: number) => {
                        return (
                          <option
                            value={item.value}
                            disabled={item.disabled}
                            id={item.id}
                            key={index}
                          >
                            {item.aircraftType}  {'Select'}
                          </option>
                        );
                      })
                    ) : (
                      <></>
                    )}
                  </select>
                </div>
              </>
            )
          }
        }
        );
        return (
          <td
            key={index}
            className='bg-white text-center justify-center items-center border border-solid'
          >
               {controls} 
          </td>
        );
      }
    });
  };

  const renderTableBody = () => {
    if (props.tableData.length > 0) {
      return <tbody>{Createdatarow(paginateData())}</tbody>;
    } else {
      return (
        <tbody>
          <tr>
            <td colSpan={10} className="text-center" style={{ height: '40px' }}>
              <div className='w-full grid justify-center items-center mt-12 mb-5'>
                <div className='transition duration-150 ease-in-out hover:text-red-600'>
                  {/* <h1 className='text-5xl  w-full grid justify-center items-center'><AiOutlineSearch/></h1>  */}
                  <h1 className='font-medium text-red-500'>No Data found</h1>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      );
    }
  }



  return (
    <>
      <table className='rounded-lg shadow-lg shadow-grey-400/10 justify-center items-center max-h-96 overflow-auto scrollbar-hide w-fit' >
        <thead className={props.background || 'bg-blue-500'}>
          <tr>{createHeader(props.tableheader.headerColumns)}</tr>
        </thead>

        {renderTableBody()}
      </table>

      <div className='mb-1 bottom-16 left-0 w-full'>
        {renderPaginationControls()}

      </div> <></>
    </>
  );
};

export default SimpleTable;
