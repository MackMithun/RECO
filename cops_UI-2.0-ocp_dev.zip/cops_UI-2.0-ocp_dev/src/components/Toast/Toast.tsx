import React from 'react';
import { ToastContainer } from 'react-toastify';

const Toast = () => {
    return (<>
        <ToastContainer
            position="top-right"
            autoClose={1000}
            hideProgressBar   
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            theme="light"
            newestOnTop={true}
             style={{  height:"15px", fontWeight:"normal" }}
        />
    </>);
}

export default Toast;