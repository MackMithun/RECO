import React, { useEffect, useState } from 'react'
import Datepicker, { ClassNamesTypeProp, DateValueType } from 'react-tailwindcss-datepicker';
import { environment } from '../../environments/environment.dev';
import { ByCatererData, CatererStation } from '../../services/api-service';
import { TopUp_Production } from '../constants/Dropdown/dropdownConstants'
import Spinner from '../Spinner/Spinner';
import { InfoModal } from '../Modal/CustomModal';

const Productionsheet = () => {

    const BASE_URL = environment.baseUrl;
    const topup = TopUp_Production;

    const [date, setDate] = useState<DateValueType>({ startDate: null, endDate: null });
    const [customcss, setCustomCss] = useState<ClassNamesTypeProp>({ input: (() => "w-full p-2  border border-solid border-gray-400 rounded-lg focus:border-blue-600 focus:outline-none md:border-width-6/6  md:w-5/6 sm:w-6/6 xl:w-6/6 xl:w-full sm:w-full md:w-full hover:border-blue-600") });
    const [stationSelected, setStationSelected] = useState('Select');
    const [catererSelected, setCatererSelected] = useState('Select');
    const [topupSelected, settopupSelected] = useState('No')
    const [stationList, setStationList] = useState([{ station_Code: 'Select', stationID: 0 },]);
    const [catererList, setCatererList] = useState([{ cater_Code: 'Select', id: 0 },]);
    const [isLoading, setIsLoading] = useState(false);
    const [infoModal ,setInfoModal] = useState({ isOpen:false , message: "" })

    const stationData = CatererStation();

    const fetchStationData = () => {
        try {
            setStationList([
                { station_Code: 'Select', stationID: 0 },
                ...stationData.state.post,
            ]);
        } catch (error) {
            console.error(error);
        }
    }

    const CatererByStation = async () => {
        if (stationSelected !== 'Select') {
            const QueryString = `?stationCode=${stationSelected}`
            try {
                const catererData = await ByCatererData(QueryString);
                setCatererList([catererList[0], ...catererData.caterer]);
            } catch (error) {
                console.error(error);
            }
        }
    }

    const closeModal = () => {
       setInfoModal({isOpen:false , message:""})
    };

    useEffect(() => {
        setCatererSelected('Select');
    }, [stationSelected]);

    useEffect(() => {
        if (stationSelected === 'Select') {
            CatererByStation()
        }
        fetchStationData();
        CatererByStation();
    }, [stationData.state, stationSelected, catererSelected]);

    const DownloadFile = async () => {
        if (date?.startDate !== null && stationSelected != 'Select' && catererSelected != 'Select') {
            const QueryString = `?flightDate=${date?.startDate}&station=${stationSelected}&catererCode=${catererSelected}`;
            setIsLoading(true);
            setTimeout(async () => {
                await fetch(`${BASE_URL}/api/QueueManagement/productionsheet-details${QueryString}`)
                    .then((response: any) => {
                        response.blob().then((data: any) => {
                            // Check if the size of the blob is less than 1024 bytes
                            if (data.size < 1024) {
                                setIsLoading(false);
                                setInfoModal({isOpen:true , message:"Production sheet not found."});
                            } else {
                                const url = window.URL.createObjectURL(
                                    new Blob([data]),
                                );
                                const link = document.createElement('a');
                                link.href = url;
                                link.setAttribute(
                                    'download',
                                    `${stationSelected}-ProductionSheet.pdf`,
                                );
                                // Append to html link element page
                                document.body.appendChild(link);
                                // Start download
                                link.click();
                                // Clean up and remove the link
                                link.parentNode?.removeChild(link);
                                setIsLoading(false);
                                setInfoModal({isOpen:true , message:"File downloaded Successfully."});
                            
                            }
                        });
                    });
                setDate({ startDate: "", endDate: "" });
                setStationSelected('Select');
                setCatererSelected('Select');
                settopupSelected('No')
               
            }, 2000);
        } else {
            setInfoModal({isOpen:true , message:"Please select all mandatory fields."});
        }
    };

    useEffect(() => {
        if (stationSelected === 'Select') {
            setCatererSelected('Select');
        }
        fetchStationData();
        CatererByStation();
    }, [stationData.state, stationSelected, catererSelected]);

    const isCatererDisabled = stationSelected === 'Select';

    const currentdateMinusOne = new Date();
    currentdateMinusOne.setDate(currentdateMinusOne.getDate() + 1);

    return (
        <>
            <div className='flex justify-center items-center'>
                <div className='m-4 w-full md:w-5/6 lg:w-5/6 xl:w-5/6 xl:h-32 h-auto p-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-4 border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50'>

                    <div className="md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5" >
                        <label className='text-black hover:text-gray-700 text-sm '>Flight Date<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <div >
                            <Datepicker classNames={customcss} value={date}
                                onChange={(newValue: any) => setDate(newValue)}
                                useRange={false} asSingle={true}
                                maxDate={currentdateMinusOne} placeholder={"Flight Date"} displayFormat={"YYYY-MM-DD"} readOnly
                            />
                        </div>
                    </div>

                    <div className=" md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5 ">
                        <label className='text-black hover:text-gray-700 text-sm'>Station<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown ${stationSelected === 'Select' ? 'text-gray-400' : ''} `}
                            value={stationSelected} onChange={(e) => setStationSelected(e.target.value)}
                        >
                            {stationList.map((item) => (
                                <option key={item.stationID} value={item.station_Code}>
                                    {item.station_Code}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5">
                        <label className='text-black hover:text-gray-700 text-sm'>Caterer<span className="text-red-400 text-xs inline-block align-top">&#9733;</span></label>
                        <select className={`form-select  w-full  p-2 font-light bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown  ${catererSelected === 'Select' ? 'text-gray-400' : ''}  ${isCatererDisabled ? 'text-gray-100' : ''} `}
                            value={catererSelected} onChange={(e) => setCatererSelected(e.target.value)}
                            disabled={isCatererDisabled}
                        >
                            {catererList.map((item: any, index: number) => (
                                <option value={item.cater_Code} disabled={item.disabled} id={item.id} key={index}>
                                    {item.cater_Code}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="md:w-5/6 xl:w-6/6 sm:ml-5 md:ml-5 xl:ml-5">
                        <label className='text-black hover:text-gray-700 text-sm'>Is TopUp</label>
                        <select className="form-select  w-full  p-2 font-light  bg-white border border-solid border-gray-400 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white hover:border-blue-600 focus:border-blue-600 focus:outline-none custom-select-dropdown"
                            value={topupSelected} onChange={(e) => settopupSelected(e.target.value)}
                        >
                            {topup.map((item: any, index: number) => {
                                return (
                                    <option value={item.value} disabled={item.disabled} id={item.id} key={index}>
                                        {item.value}
                                    </option>
                                );
                            })}
                        </select>
                    </div>

                    <div>
                        <button onClick={DownloadFile}
                            className="bg-indigo-500 hover:bg-white hover:text-indigo-500 border-2 text-white font-bold py-1 px-2 ml-8 mt-5 h-10 md:col-span-1 sm:w-3/6 xl:w-4/6 rounded-lg disabled:$ ">
                            Download
                        </button>
                    </div>

                </div>
            </div>

            {isLoading && <Spinner />}

            <InfoModal isOpen={infoModal.isOpen} message={infoModal.message} isClose={closeModal} />

        </>
    )
}

export default Productionsheet;