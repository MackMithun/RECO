
import React from 'react';

const Footer = () => {
  return (
    <>
      <footer className="w-full bg-gray-600 py-2 mt-2 flex items-center place-content-center h-12 ">
         <span  className='justify-center text-center text-white'> For InterGlobe Aviation Ltd. (IndiGo)</span> 
         </footer>
    </>
  );
};

export default Footer;
