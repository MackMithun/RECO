export const constants: any ={

    headerArrayManufacturing: [
        'Flight Date','From Time','To Time','Departure', 'Caterer','Execution Date Time', 'Queue Status', 'Email', 'ReTrigger', 'Action'
    ],

    dataStyle: 'h-8 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid ',

    headerstyleindexManufacturing: [
            'h-10 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid',
            'h-10 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid',
            'h-10 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid ',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border border-r-1 border-solid ',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border border-r-1 border-solid ',
            'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
            'h-10 text-white text-center font-medium w-44 justify-center items-center border border-r-1 border-solid',
            'h-10 text-white text-center font-medium w-24 justify-center items-center border border-r-1 border-solid',
            'h-10 text-white text-center font-medium w-24 justify-center items-center border border-r-1 border-solid ',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border border-r-1 border-solid ',
    ],

    QueueHeaderArray: ['S.No', 'Flight No', 'Caterer', 'Sector', 'Status','Message'],
    
        headerQueuestyleindex: [
            'h-8 text-white text-center font-medium w-16  justify-center  border border-r-1 border-solid',
            'h-8 text-white text-center font-medium w-32 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-32 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-24 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-24 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid '
        ],


};

