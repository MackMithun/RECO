export const constants: any = {
        
    
        dataStyle: 'h-8 bg-white  text-center font-normal justify-center items-center border border-r-1 border-solid ',
    
        QueueDataStyle: 'h-10 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid ',
    
        headerArray: ['Flight Date', 'Departure', 'Caterer', 'Sheet Type', 'Execution DateTime', 'Queue Status', 'Email', 'Re-Trigger', 'Action'],
    
        headerstyleindex: [
            'h-10 text-white text-center font-medium w-40 justify-center items-center border  border-solid',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border  border-solid',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border  border-solid ',
            'h-10 text-white text-center font-medium w-36 justify-center items-center border  border-solid ',
            'h-10 text-white text-center font-medium w-52 justify-center items-center border  border-solid ',
            'h-10 text-white text-center font-medium w-44 justify-center items-center border  border-solid ',
            'h-10 text-white text-center font-medium w-28 justify-center items-center border  border-solid',
            'h-10 text-white text-center font-medium w-28 justify-center items-center border  border-solid',
            'h-10 text-white text-center font-medium w-32 justify-center items-center border  border-solid ',
        ],

        //Queue
    
        QueueHeaderArray: ['S.No', 'Flight No', 'Caterer', 'Sector', 'Status','Message'],
    
        headerQueuestyleindex: [
            'h-8 text-white text-center font-medium w-16 justify-center items-center border border-r-1 border-solid',
            'h-8 text-white text-center font-medium w-28 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-28 justify-center items-center border border-r-1 border-solid ',
            'h-8 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid '
        ],
        queuedataStyle: 'h-8 p-2 bg-white text-center text-sm font-normal justify-center items-center border border-r-1 border-solid ',
}