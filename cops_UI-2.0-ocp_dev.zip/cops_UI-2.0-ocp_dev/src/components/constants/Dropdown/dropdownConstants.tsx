export const SHIFT_TYPES = [
  { value: 'All', id: 0 },
  { value: 'Morning', id: 1 },
  { value: 'Evening', id: 2 },
];

export const FLIGHT_TYPES = [
  { value: 'Select', id: 0 },
  { value: 'Domestic', id: 1 },
  { value: 'International', id: 2 },
];


export const SHEET_TYPES = [
  { value: 'Select', id: 0 },
  { value: 'Delta', id: 1 },
  { value: 'Regular', id: 2 },
];

export const SHEET_NAMES = [
  { value : 'Select' , id: 0},
  { value : 'Manufacturing' , id: 1 },
  { value : 'Production' , id: 2 }
]

export const SHEET_NAMES_ALERT = [
  { value : 'Manufacturing' , id: 0 },
  { value : 'Production' , id: 1 }
]

export const TOPUP = [
  { value: 'Select', id: 0 },
  { value: 'No', id: 1 },
  { value: 'Yes', id: 2 },
];

export const ACTUALEDITED_QUANTITIES = [
  { value: 'Select', id: 0 },
  { value: 'Actual Quantity', id: 1 },
  { value: 'Edited Quantity', id: 2 },
]

export const ALERT_FREQUENCY = [
  { value: "Select", id: 0 },
  { value: "Day Advance", id: 1 },
  { value: "Same Day", id: 2 },
];


export const CART_CATEGORY = [
  { value: "Select", id: 0 },
  { value: "F&B", id: 1 },
  { value:"Merchandise", id: 2 },
]

export const TopUp_Production = [
  { value: 'No', id: 0 },
  { value: 'Yes', id: 1 },
];

export const FLT_TYPES = [
  { value: 'Flight type', id: 0 },
  { value: 'Domestic', id: 1 },
  { value: 'International', id: 2 },
];