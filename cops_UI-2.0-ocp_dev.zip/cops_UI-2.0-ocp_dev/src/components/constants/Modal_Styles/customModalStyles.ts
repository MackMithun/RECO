export const DELETE_MODALSTYLES = {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 1000,
        transition: 'opacity 0.5s ease-in-out',
    },
    content: {
        top: '50%',
        left: '50%',
        minWidth: '200px',
        maxWidth: '400px',
        maxHeight: '200px',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '10px',
        padding: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',
        '@screen sm': {
            width: '100%',
            height: '70%' // Adjust width for small screens (sm)
        },
        '@screen md': {
            width: '70%',
            height: '70%' // Adjust width for medium screens (md)
        },
        '@screen lg': {
            width: '60%',
            height: '70%'// Adjust width for large screens (lg)
        },
        '@screen xl': {
            width: '50%',
            height: '70%' // Adjust width for extra-large screens (xl)
        },
    },
}



export const ADD_MODALSTYLES = {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.2)',
        zIndex: 9999,
        transition: 'opacity 0.5s ease-in-out',
    },
    content: {
        top: '50%',
        left: '50%',
        width: '45%', // Default width for smaller screens
        maxWidth: '50rem',
        height: '270px',// Maximum width for larger screens
        maxHeight: '70vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '20px',
        padding: '0px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        zIndex: '9999',
        animation: 'flipInOut 0.5s', // Using flipInOut animation
        '@screen sm': {
            width: '100%',
            height: '70%' // Adjust width for small screens (sm)
        },
        '@screen md': {
            width: '70%',
            height: '70%' // Adjust width for medium screens (md)
        },
        '@screen lg': {
            width: '60%',
            height: '70%'// Adjust width for large screens (lg)
        },
        '@screen xl': {
            width: '50%',
            height: '70%' // Adjust width for extra-large screens (xl)
        },
        '@keyframes flipInOut': {
            '0%': {
                transform: 'perspective(400px) rotateY(90deg)',
                opacity: 0
            },
            '100%': {
                transform: 'perspective(400px) rotateY(0deg)',
                opacity: 1
            }
        }
    },
};

export const ADD_MODALSTYLES_PRODUCTION = {
    overlay: {
        // Overlay styles (adjust based on your requirements)
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        zIndex: 1,
        transition: 'opacity 0.5s ease-in-out',

    },
    content: {
        // Content styles
        top: '45%',
        left: '50%',
        width: '98%', // Default width for smaller screens
        maxWidth: '50rem',
        height: '350px',// Maximum width for larger screens
        maxHeight: '70vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '20px',
        padding: '0px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        zIndex: '9999',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',

      

        // Responsive design using Tailwind classes
        '@screen sm': {
            width: '100%',
            height: '70%' // Adjust width for small screens (sm)
        },
        '@screen md': {
            width: '70%',
            height: '70%' // Adjust width for medium screens (md)
        },
        '@screen lg': {
            width: '60%',
            height: '70%'// Adjust width for large screens (lg)
        },
        '@screen xl': {
            width: '50%',
            height: '70%' // Adjust width for extra-large screens (xl)
        },
    },
};

export const ADHOC_MODALSTYLES= {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.2)',
        zIndex: 9999,
    },
    content: {
        top: '50%',
        left: '50%',
        width: '70%',
        maxWidth: '50rem',
        height: '280px',
        maxHeight: '70vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '20px',
        padding: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        zIndex: '9999',
    },
};


export const Transit_CUSTOMMODALSTYLES = {
    overlay: {
      // Overlay styles (adjust based on your requirements)
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      zIndex: 9999,
      transition: 'opacity 0.5s ease-in-out',
  
    },
    content: {
      // Content styles
      top: '50%',
      left: '50%',
      width: '50%', // Default width for smaller screens
      maxWidth: '30rem',
      height: '250px',// Maximum width for larger screens
      maxHeight: '80vh',
      transform: 'translate(-50%, -50%)',
      border: 'none',
      borderRadius: '10px',
      padding: '0px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      background: '#FFFFFF',
      overflow: 'show',
      transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',
  
      // Responsive design using Tailwind classes
      '@screen sm': {
        width: '100%',
        height: '70%' // Adjust width for small screens (sm)
      },
      '@screen md': {
        width: '70%',
        height: '70%' // Adjust width for medium screens (md)
      },
      '@screen lg': {
        width: '60%',
        height: '70%'// Adjust width for large screens (lg)
      },
      '@screen xl': {
        width: '50%',
        height: '70%' // Adjust width for extra-large screens (xl)
      },
    },
  };

  export const addcustomModalStyles = {
    overlay: {
        // Overlay styles (adjust based on your requirements)
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        zIndex: 9999,
        transition: 'opacity 0.5s ease-in-out',

    },
    content: {
        // Content styles
        top: '45%',
        left: '50%',
        width: '98%', // Default width for smaller screens
        maxWidth: '50rem',
        height: '280px',// Maximum width for larger screens
        maxHeight: '80vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '10px',
        padding: '0px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        zIndex: '9999',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',

        // Responsive design using Tailwind classes
        '@screen sm': {
            width: '100%',
            height: '70%' // Adjust width for small screens (sm)
        },
        '@screen md': {
            width: '70%',
            height: '70%' // Adjust width for medium screens (md)
        },
        '@screen lg': {
            width: '60%',
            height: '70%'// Adjust width for large screens (lg)
        },
        '@screen xl': {
            width: '50%',
            height: '70%' // Adjust width for extra-large screens (xl)
        },
    },
};

export const QUEUE_ModalStyles = {
    overlay: {
        backgroundColor: 'rgba(0.5, 0.5, 0.5, 0.5)',
        zIndex: 1000,
        transition: 'opacity 0.5s ease-in-out',
    },
    content: {
        top: '50%',
        left: '50%',
        width: '60%', 
        height: '550px',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '20px',
        padding: '0px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFF',
        overflow: 'auto',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',
    },
};

export const ADD_MODALSTYLES_MANUFACTURE = {
    overlay: {
        // Overlay styles (adjust based on your requirements)
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 1,
        transition: 'opacity 0.5s ease-in-out',

    },
    content: {
        // Content styles
        top: '50%',
        left: '50%',
        width: '98%', // Default width for smaller screens
        maxWidth: '50rem',
        height: '300px',// Maximum width for larger screens
        maxHeight: '80vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '10px',
        padding: '0px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',

        // Responsive design using Tailwind classes
        '@screen sm': {
            width: '100%',
            height: '70%' // Adjust width for small screens (sm)
        },
        '@screen md': {
            width: '70%',
            height: '70%' // Adjust width for medium screens (md)
        },
        '@screen lg': {
            width: '60%',
            height: '70%'// Adjust width for large screens (lg)
        },
        '@screen xl': {
            width: '50%',
            height: '70%' // Adjust width for extra-large screens (xl)
        },
    },
};

export const ReTrigger_MODALSTYLES= {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.2)',
        zIndex: 9999,
    },
    content: {
        top: '50%',
        left: '50%',
        width: '30%',
        maxWidth: '50rem',
        height: '220px',
        maxHeight: '70vh',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '20px',
        padding: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'show',
        zIndex: '9999',
    },
};
  

export const DeletecustomModalStyles = {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 1000,
        transition: 'opacity 0.5s ease-in-out',
    },
    content: {
        top: '50%',
        left: '50%',
        minWidth: '200px',
        maxWidth: '400px',
        maxHeight: '150px',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '10px',
        padding: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'auto',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',

    },
};

export const InfocustomModalStyles = {
    overlay: {
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        zIndex: 2,
        transition: 'opacity 0.5s ease-in-out',
    },
    content: {
        top: '50%',
        left: '50%',
        minWidth: '220px',
        maxWidth: '300px',
        maxHeight: '140px',
        transform: 'translate(-50%, -50%)',
        border: 'none',
        borderRadius: '10px',
        padding: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
        background: '#FFFFFF',
        overflow: 'auto',
        transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',

    },
};

export const CUSTOMMODAL_STYLES = {
    overlay: {
      // Overlay styles (adjust based on your requirements)
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      zIndex: 9999,
      transition: "opacity 0.5s ease-in-out",
    },
    content: {
      // Content styles
      top: "50%",
      left: "50%",
      width: "45%", // Default width for smaller screens
      maxWidth: "90rem",
      height: "180px", // Maximum width for larger screens
      maxHeight: "60vh",
      transform: "translate(-50%, -50%)",
      border: "none",
      borderRadius: "10px",
      padding: "0px",
      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.2)",
      background: "#FFFFFF",
      overflow: "show",
      transition:
        "transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out",
  
      // Responsive design using Tailwind classes
      "@screen sm": {
        width: "100%",
        height: "50%", // Adjust width for small screens (sm)
      },
      "@screen md": {
        width: "100%",
        height: "50%", // Adjust width for medium screens (md)
      },
      "@screen lg": {
        width: "60%",
        height: "40%", // Adjust width for large screens (lg)
      },
      "@screen xl": {
        width: "50%",
        height: "40%", // Adjust width for extra-large screens (xl)
      },
    },
  };

  export const ACTION_CUSTOMMODALSTYLES = {
    overlay: {
      // Overlay styles (adjust based on your requirements)
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      zIndex: 9999,
      transition: 'opacity 0.5s ease-in-out',
  
    },
    content: {
      // Content styles
      top: '50%',
      left: '50%',
      width: '90%', // Default width for smaller screens
      maxWidth: '100rem',
      height: '1000px',// Maximum width for larger screens
      maxHeight: '80vh',
      transform: 'translate(-50%, -50%)',
      border: 'none',
      borderRadius: '10px',
      padding: '0px',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',
      background: '#FFFFFF',
      overflow: 'show',
      transition: 'transform cubic-bezier(0.4, 0, 0.2, 1), opacity 0.5s ease-in-out',
  
      
    },
  };

