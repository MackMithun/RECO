export const constants: any = {

    dataStyle: 'h-9 p-2 bg-white text-center justify-center items-center border border-r-1 border-solid ',

    headerArray: ['Flight Date & Time','Flight Number', 'Departure', 'Arrival', 'Sequence', 'Flight Type', 'Is Top Up', 'Caterer Code', 'Matrix', 'Category'],

    headerstyleindex: [
        'h-9 text-white text-center font-semibold w-44 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-32 justify-center items-center border border-r-1 border-solid',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-32 justify-center items-center border border-r-1 border-solid',
        'h-9 text-white text-center font-semibold w-32 justify-center items-center border border-r-1 border-solid ',
        'h-9 text-white text-center font-semibold w-24 justify-center items-center border border-r-1 border-solid ',
    ],

   
}