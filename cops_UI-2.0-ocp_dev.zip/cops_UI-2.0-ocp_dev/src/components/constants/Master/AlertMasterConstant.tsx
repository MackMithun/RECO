export const constants:any ={
    headerArray :['S.No', 'Effective From', 'Effective To', 'Sheet Type', 'Alert Frequency', 'Alert Time', 'Created By', 'Action'],

     headerstyleindex : [
        'h-10 text-white text-center font-medium w-24 justify-center items-center border  border-solid',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-48 justify-center items-center border border-r-1 border-solid ',
        'h-10 text-white text-center font-medium w-36 justify-center items-center border border-r-1 border-solid '
    ],

     datastyle : 'h-9 bg-white  text-center  font-normal justify-center items-center border border-r-1 border-solid ',

     headerArrayManufacture: ['S.No', 'Effective From', 'Effective To', 'From Time','To Time', 'Alert Time','Alert Frequency', 'Created By', 'Action']
}