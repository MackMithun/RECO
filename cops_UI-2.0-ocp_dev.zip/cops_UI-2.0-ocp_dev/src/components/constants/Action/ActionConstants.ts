export const constants: any = {

    AddTailheaderArray: ['', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer'],

    dataStyle: 'h-6 p-1.5 bg-white text-center justify-center items-center border border-r-1 border-solid ',

    AddTailheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-36  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36  justify-center items-center border border-r-1 border-solid',
    ],

    CancelFlightheaderArray: ['Select', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer'],

    CancelFlightheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-36  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36  justify-center items-center border border-r-1 border-solid',
    ],

    ChangeCatererCodeheaderArray: ['', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer'],

    ChangeCatererCodeheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-36  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36  justify-center items-center border border-r-1 border-solid',
    ],

    ChangeFlightNumberheaderArray: ['', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer'],

    ChangeFlightNumberheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-28  xl:w-28  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36  justify-center items-center border border-r-1 border-solid',
    ],

    changeMetricesandPercentageheaderArray: ['Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer', ' Fixed Matrix' , 'Variable Matrix', 'FNB Matrix', 'MHS Matrix', 'Percentage'],

    changeMetricesandPercentageheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-36  xl:w-72 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-96 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-72 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-72 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-52 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-72 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-96 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-96 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-96 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-96 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-52 justify-center items-center border border-r-1 border-solid',
    ],

    changeTerminalheaderArray: ['', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Terminal', 'Sequence', 'Caterer'],

    changeTerminalheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-28  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32  justify-center items-center border border-r-1 border-solid',
    ],

    IROPSheaderArray : ['Flight No', 'STD' ,'STA' ,'Day Diff' ,'Departure' ,'Arrival', 'Seq' , 'Caterer'],

    IROPSheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-28  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-32  justify-center items-center border border-r-1 border-solid',
    ],

    MovetoTransitheaderArray: ['Select', 'Flight No', 'Aircraft Type', 'Departure', 'Arrival', 'Sequence', 'Caterer'],

    MovetoTransitheaderStyleindex: [
        'h-8 text-white text-center font-medium w-full sm:w-20 md:w-20 lg:w-28  xl:w-32  justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-40 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid ',
        'h-8 text-white text-center font-medium w-full sm:w-24 md:w-32 lg:w-32  xl:w-36 justify-center items-center border border-r-1 border-solid',
    ],


};