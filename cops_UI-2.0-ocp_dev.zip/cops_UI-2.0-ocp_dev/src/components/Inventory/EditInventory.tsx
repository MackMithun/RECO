import React, { useState, useEffect } from "react";
import { CART_CATEGORY } from "../constants/Dropdown/dropdownConstants";
import FnbTable from "../Table/FnbTable";
import MerchandiseTable from "../Table/MerchandiseTable";
import { useLocation } from "react-router";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import Breadcrumbs from "../Breadcrumbs/Breadcrumbs";
import { getEditInventory } from "../../services/FreshCateringService";
import { InfoModal } from "../Modal/CustomModal";
import SpillCartAddModal from "../Modal/Inventory/SpillCartAddModal";

const EditInventory = (props: any) => {
  let locationdata = useLocation();
  let { flt_Dt, groupId, aircraftType } = locationdata.state.flight;
   console.log(locationdata.state.flight)
  const [data, setData] = useState([]);
  const [conditions, setConditions] = useState({ isLoading: false, dataFound: false });
  const [modalisOpen, setModalisOpen] = useState<any>({ searchClick: false });
  const [infoModal, setInfoModal] = useState({ isOpen: false, message: "" });

  const fetchData = () => {
    let { flt_Dt, groupId, dep,flt_No } = locationdata.state.flight;
    console.log(flt_Dt , groupId)
    setConditions({ isLoading: true, dataFound: false });
    getEditInventory({ flt_Dt, groupId , dep ,cartCategorySelected , aircraftType , flt_No})
      .then((data: any) => {
        setData(data);
        setConditions({ isLoading: false, dataFound: true });
        setModalisOpen({ searchClick: true });
      })
      .catch(() => {
        setData([]);
        setModalisOpen({ searchClick: true });
        setConditions({ isLoading: false, dataFound: false });
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const [cartCategorySelected, setCartCategorySelected] = useState("Select");
  const [fnbContent, setFnbContent] = useState(false);
  const [merchandiseContent, setMerchandiseContent] = useState(false);
  const [spillCartModalIsOpen, setSpillCartModalIsopen] = useState(false);

  const CartCategory = CART_CATEGORY;

  useEffect(() => {
    cartCategorySelected === "F&B" ? setFnbContent(true) : setFnbContent(false);
    cartCategorySelected === "Merchandise" ? setMerchandiseContent(true) : setMerchandiseContent(false);
   }, [cartCategorySelected]);


  const spillCartBtnHandler = () => {
    setSpillCartModalIsopen(true);
  };

  const closemodal = () => {
    setInfoModal({ isOpen: false, message: "" })
    setSpillCartModalIsopen(false);
  };

  return (
    <>
      <div className='min-h-screen flex flex-col'>
        <Header />
        <div className='ml-3 mt-2'> <Breadcrumbs /></div>
        <div className='scrollbar-hide flex flex-col'>
          <div className="flex justify-center items-center">
            <div className="w-full md:w-5/6 lg:w-3/4 xl:w-4/4 xl:h-40 h-auto p-4  border bg-white-300 rounded-lg shadow-lg shadow-grey-300/50">
              <div className=" max-w-screen-xl w-11/12 mx-10 h-auto p-1 border bg-white-300 rounded-lg">
                <span className="ml-20">Groupid: </span><span className="font-bold text-red-500 mr-10"> {groupId}</span>
                {/* Flight Number: <span className=" mr-10 font-bold text-red-500"> {flt_No}</span> */}
                Flight Number: <span className=" mr-10 font-bold text-red-500"> {"hello"}</span>
                {/* Departure: <span className="font-bold text-red-500 mr-10"> {dep}</span> */}
                Departure: <span className="font-bold text-red-500 mr-10"> {"dep"}</span>
                Flight date: <span className="font-bold text-red-500 mr-10"> {flt_Dt.split("T")[0]} </span>
                Aircraft Type:  <span className="font-bold text-red-500"> {aircraftType}</span>
              </div>
              <div className="grid grid-cols-3 ">
                <div className="md:w-6/6 lg:w-4/6 mx-12 mt-2">
                  <label className="text-black hover:text-gray-700 text-sm">Cart Category <span className="text-red-400 text-xs inline-block align-top"> &#9733; </span></label>
                  <select className={`form-select w-full p-2 font-light bg-white border border-solid border-gray-300 rounded-lg transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none custom-select-dropdown hover:border-blue-500 ${cartCategorySelected === "Select" ? "text-gray-400" : ""}`}
                    value={cartCategorySelected} onChange={(e) => setCartCategorySelected(e.target.value)}
                  >
                    {CartCategory !== undefined ? (
                      CartCategory.map((item: any, index: number) => {
                        return (
                          <option value={item.cater_Code} disabled={item.disabled} id={item.id} key={index}>
                            {item.value}
                          </option>
                        );
                      })) : (
                      <></>)}
                  </select>
                </div>
                <div></div>
                <button onClick={spillCartBtnHandler} className="bg-indigo-900 hover:bg-white hover:text-indigo-900 border-2 w-3/6 h-10 mx-16 my-0 mt-8  text-white font-semibold rounded-lg">Add Spill Cart</button>
              </div>
            </div>
          </div>

          {fnbContent && <FnbTable data={data} />}

          {merchandiseContent && <MerchandiseTable data={data} />}
          <InfoModal isOpen={infoModal.isOpen} message={infoModal.message} isClose={closemodal} />

          <SpillCartAddModal isOpen={spillCartModalIsOpen} isClose={closemodal} />
        </div>
        <div className="mt-auto"> <Footer /></div>
    
      </div>
    </>
  );
};

export default EditInventory;

