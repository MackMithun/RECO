﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using System;

namespace RECO.ReaccommodationDALService.HealthChecking
{
    public class CustomCheck: IHealthCheck
    {
        private readonly Random _random = new Random();
        

        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            var responseTime = _random.Next(1, 300);
            if (responseTime > 0)
            {
                return Task.FromResult(HealthCheckResult.Healthy("Healthy result from ReaccommodationDBAccess MS"));
            }
            else
            {
                return Task.FromResult(HealthCheckResult.Unhealthy("Unhealthy result from ReaccommodationDBAccess MS"));
            }
        }
          
    }
}

