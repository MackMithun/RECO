using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using NLog;
using NLog.Web;
using RECO.ReaccommodationDALService.Middlewares;
using RECO.ReaccommodationDALService.ServicesDependency;

var builder = WebApplication.CreateBuilder(args);

builder.RegisterServices();
var app = builder.Build();

LogManager.LoadConfiguration(string.Concat(Directory.GetCurrentDirectory(), @"/nlog.config"));

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ErrorHandlerMiddleware>();
app.UseMiddleware<NLogRequestPostedBodyMiddleware>(
            new NLogRequestPostedBodyMiddlewareOptions());
app.MapHealthChecksUI();

app.UseHttpsRedirection();
app.UseAntiXssMiddleware();
app.UseRouting();

app.UseAuthorization();

app.MapControllers();
app.UseEndpoints(endpoints =>
{
    endpoints.MapHealthChecks("/health",
     new HealthCheckOptions()
     {

         ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
     }
    );
});
app.Run();
