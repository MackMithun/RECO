﻿namespace RECO.Kafka_ListnerService.Models
{
    public class RECO_KafkaEvents
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public List<RECO_EventApiMapping> RECO_EventApiMappings { get; set; }
    }
}
