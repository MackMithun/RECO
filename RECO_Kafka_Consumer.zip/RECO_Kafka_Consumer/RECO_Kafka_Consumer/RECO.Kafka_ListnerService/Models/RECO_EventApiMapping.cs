﻿namespace RECO.Kafka_ListnerService.Models
{
    public class RECO_EventApiMapping
    {
        public int Id { get; set; }

        public string KafkaEventId { get; set; }

        public string BaseUrl { get; set; }

        public string ApiUrl { get; set; }

        public string AuthValue { get; set; }

        public RECO_KafkaEvents KafkaEvent { get; set; }
    }
}
