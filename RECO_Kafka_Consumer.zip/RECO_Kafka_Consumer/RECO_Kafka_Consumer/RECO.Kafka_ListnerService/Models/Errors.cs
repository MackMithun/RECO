﻿namespace RECO.ReaccommodationDALService.Models
{
    public class Errors
    {
        public string? type { get; set; }
        public string? code { get; set; }
        public string? message { get; set; }
        public string? subType { get; set; }
        public string? correlationId { get; set; }
        
    }
}

