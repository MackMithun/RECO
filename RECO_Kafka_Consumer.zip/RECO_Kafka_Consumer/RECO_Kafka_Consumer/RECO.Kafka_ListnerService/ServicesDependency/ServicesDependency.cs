﻿using Microsoft.IdentityModel.Logging;
using NLog;
using NLog.Web;
using RECO.Kafka_ListnerService.Consumer;
using RECO.Kafka_ListnerService.Contracts;
using RECO.Kafka_ListnerService.Repository;
using RECO.Kafka_ListnerService.RestClient;
using RECO.Kafka_ListnerService.Utilities;
using RECO.ReaccommodationDALService.Common;

using RECO.ReaccommodationDALService.HealthChecking;
using RECO.ReaccommodationDALService.IUtilities;
using RECO.ReaccommodationDALService.Utilities;

namespace RECO.ReaccommodationDALService.ServicesDependency
{
    public static class ServicesDependency
    {
        public static void RegisterServices(this WebApplicationBuilder builder)
        {
            builder.Services.AddControllers();

            ///Nlog configuration
            NLog.LogManager.Setup().LoadConfigurationFromAppSettings().GetCurrentClassLogger();
            builder.Logging.ClearProviders();
            builder.Logging.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
            builder.Host.UseNLog();
            builder.Services.AddSession(options => {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
            });
            builder.Services.AddDistributedMemoryCache();
            //builder.Services.AddResponseCaching();
            builder.Services.AddHttpContextAccessor();

          
            // Add services to the container.
           



    //        var app = builder.Build();
            IConfiguration configuration = builder.Configuration;
    //        IWebHostEnvironment environment = app.Environment;


           string appSettingsFile = "appsettings.json";
            try
            {
                var enviroment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                if (enviroment != null)
                {
                    Console.WriteLine(enviroment.ToLower());
                    if (enviroment.ToLower() == "uat")
                        appSettingsFile = "appsettings.uat.json";
                    else if (enviroment.ToLower() == "development")
                        appSettingsFile = "appsettings.development.json";
                    else if (enviroment.ToLower() == "preprod")
                        appSettingsFile = "appsettings.preprod.json";
                    else if (enviroment.ToLower() == "prod")
                        appSettingsFile = "appsettings.prod.json";
                }
            }
            catch (Exception ex) { }
                   IConfiguration envconfiguration = new ConfigurationBuilder().AddJsonFile(appSettingsFile, false, true)
            .Build();

            builder.Services.AddHealthChecks()
            .AddCheck<CustomCheck>("Todo Health Check", tags: new[] { "custom" });


            builder.Services.AddOptions().Configure<DataApiConfiguration>(configuration.GetSection(nameof(DataApiConfiguration)));
            builder.Services.AddOptions().Configure<ApiTokenConfiguration>(configuration.GetSection(nameof(ApiTokenConfiguration)));
            builder.Services.AddOptions().Configure<KafkaTopicConfiguration>(configuration.GetSection(nameof(KafkaTopicConfiguration)));
            builder.Services.AddOptions().Configure<ConsumerConfiguration>(configuration.GetSection(nameof(ConsumerConfiguration)));

            builder.Services.AddHttpClient<IRestClient, RestClient>();
            builder.Services.AddSingleton<ILogHelper, LogHelpers>();
            builder.Services.AddTransient<IFlightRepository, FlightRepository>();
            builder.Services.AddHostedService<FlightCancellEventConsumer>();


            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
        }
    }
}
