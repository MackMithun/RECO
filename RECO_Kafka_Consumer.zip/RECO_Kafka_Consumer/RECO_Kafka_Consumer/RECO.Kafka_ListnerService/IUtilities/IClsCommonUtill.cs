﻿namespace RECO.ReaccommodationDALService.IUtilities
{
    public interface IClsCommonUtill
    {
        public bool IsValidSecretKey(string? SecretKey);
    }
}
