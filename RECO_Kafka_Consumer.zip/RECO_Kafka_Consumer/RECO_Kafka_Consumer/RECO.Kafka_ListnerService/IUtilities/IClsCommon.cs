﻿namespace RECO.ReaccommodationDALService.IUtilities
{
    public interface IClsCommon
    {
        public string GetConfigData(string keyName);
    }
}
