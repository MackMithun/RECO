﻿using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using RECO.ReaccommodationDALService.Models;
using RECO.ReaccommodationDALService.Utilities;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text.Json;

namespace RECO.ReaccommodationDALService.Middlewares
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ErrorHandlerMiddleware> _logger;
        public ErrorHandlerMiddleware(RequestDelegate next, ILogger<ErrorHandlerMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {            
            var watch = new Stopwatch();
            watch.Start();
            string StartTime = System.DateTime.Now.ToLocalTime().ToString();
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                var errors = new Errors();
                var response = context.Response;
                response.ContentType = "application/json";

                switch (error)
                {
                    case AppException e:
                        // custom application error
                        errors = e._errors;
                        response.StatusCode = (int)HttpStatusCode.BadRequest;
                        break;
                    case KeyNotFoundException e:
                        // not found error
                        response.StatusCode = (int)HttpStatusCode.NotFound;
                        break;
                    default:
                        errors.message = error.Message;
                        string[] code = error.Message.Split(',');
                        if (error.Message != null && code.Length > 0)
                        {
                            errors.code = code[0];
                        }
                        else
                        {
                            errors.code = "E005";
                        }
                        // unhandled error
                        response.StatusCode = (int)HttpStatusCode.OK;
                        break;
                }               

                watch.Stop();
                               
                context.Request.Headers.TryGetValue("Authorization", out var headerValue);
               
                Result result = new Result();
                result.data = null;
                result.errors = errors;
                var jsonContent = JsonSerializer.Serialize(result);
                if (!string.IsNullOrEmpty(headerValue))
                {
                    result.errors.correlationId = headerValue;
                }
                else
                {
                    result.errors.correlationId = string.Empty;
                }
                var logJsonContent = JsonSerializer.Serialize(result);
                _logger.LogError(logJsonContent);
                await context.Response.WriteAsync(Convert.ToString(jsonContent));
            }
        }
    }

    public class AppException : Exception
    {
        public readonly Errors _errors = new Errors();
        public AppException() : base() { }

        public AppException(Errors? errors) : base(errors.message) { _errors = errors; }

        public AppException(string message, params object[] args)
            : base(String.Format(CultureInfo.CurrentCulture, message, args))
        {
        }
    }
    public class Result
    {
        public Errors? errors { get; set; }
        public dynamic? data { get; set; }
    }
}