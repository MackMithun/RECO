﻿namespace RECO.Kafka_ListnerService.RestClient
{
    public interface IRestClient
    {
        public HttpResponseMessage? _response { get; set; }
        string? URL { get; set; }
        public string GatewayKey { get; set; }
        string? Auth { get; set; }
        dynamic? Content { get; set; }
        dynamic? GetAsync();
        dynamic? PostAsync();
        dynamic? PutAsync();
        dynamic? DeleteAsync();

        Task<dynamic?> GetAsynchcronous();

        Task<dynamic?> PostAsynchcronous();
    }
}
