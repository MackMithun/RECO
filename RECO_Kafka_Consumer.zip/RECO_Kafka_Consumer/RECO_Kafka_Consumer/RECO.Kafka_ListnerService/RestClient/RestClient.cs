﻿using Newtonsoft.Json;
using System.Text;

namespace RECO.Kafka_ListnerService.RestClient
{
    public class RestClient : IRestClient
    {

        private readonly HttpClient? _httpClient;
        private string? _auth;
        private string? _gatewayKey;
        private dynamic? _content;
        private dynamic? _responseObject;
        public string? URL { get; set; }
        public string? Auth
        {
            get
            {

                return _auth;
            }   // get method
            set
            {
                _auth = value;
                if (!string.IsNullOrEmpty(_auth) && _httpClient != null)
                {
                    _httpClient.DefaultRequestHeaders.Remove("Authorization");
                    _httpClient.DefaultRequestHeaders.Add("Authorization", _auth);
                }

            }  // set method
        }

        public string GatewayKey
        {
            get
            {
                return _gatewayKey;
            }
            set
            {
                _gatewayKey = value;
                if (!string.IsNullOrEmpty(_gatewayKey) && _httpClient != null)
                {
                    _httpClient.DefaultRequestHeaders.Remove("user_key");
                    _httpClient.DefaultRequestHeaders.Add("user_key", _gatewayKey);
                }
            }
        }

        public HttpResponseMessage? _response { get; set; }
        public dynamic? Content
        {
            get
            {

                return _content;
            }   // get method
            set
            {
                _content = new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");

            }  // set method
        }
        public RestClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public dynamic? GetAsync()
        {
            // HttpResponseMessage? _response;
            if (_httpClient != null)
            {
                this._response = _httpClient.GetAsync(URL).Result;
                this._response.Headers.Remove("Server");

                _responseObject = JsonConvert.DeserializeObject<dynamic>(this._response.Content.ReadAsStringAsync().Result);
            }

            return _responseObject;
        }

        public async Task<dynamic?> GetAsynchcronous()
        {
            // HttpResponseMessage? _response;
            if (_httpClient != null)
            {
                this._response = (await _httpClient.GetAsync(URL));
                this._response.Headers.Remove("Server");

                _responseObject = JsonConvert.DeserializeObject<dynamic>(this._response.Content.ReadAsStringAsync().Result);
            }

            return _responseObject;
        }

        public dynamic? PostAsync()
        {
            HttpResponseMessage? _response;
            if (_httpClient != null)
            {
                _response = _httpClient.PostAsync(URL, Content).Result;
                _response.Headers.Remove("Server");
                _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
            }
            return _responseObject;
        }

        public async Task<dynamic?> PostAsynchcronous()
        {
            HttpResponseMessage? _response;
            if (_httpClient != null)
            {
                _response = (await _httpClient.PostAsync(URL, Content));
                _response.Headers.Remove("Server");
                _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
            }
            return _responseObject;
        }

        public dynamic? PutAsync()
        {
            HttpResponseMessage? _response;
            if (_httpClient != null)
            {
                _response = _httpClient.PutAsync(URL, Content).Result;
                _response.Headers.Remove("Server");
                _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
            }
            return _responseObject;
        }

        public dynamic? DeleteAsync()
        {
            if (Content is null)
            {
                _response = _httpClient.DeleteAsync(URL).Result;
            }
            else
            {
                HttpRequestMessage request = new HttpRequestMessage();
                request.Method = HttpMethod.Delete;
                request.Content = Content;
                request.RequestUri = new Uri(URL);
                /* request.Headers.Add("Authorization", Auth);
                 request.Headers.Add("user_key", _gatewayKey);*/
                _response = _httpClient.SendAsync(request).Result;
            }
            _response.Headers.Remove("Server");
            return JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);

        }
    }
}