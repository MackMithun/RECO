﻿namespace RECO.Kafka_ListnerService.Contracts
{
    public class ConsumerConfiguration
    {
        public string bootstrapservers { get; set; }

        public string bootstrapserver { get; set; }
        public string groupid { get; set; }
        public string enableautocommit { get; set; }
        public string SslCaLocation { get; set; }
        public string SslKeyPassword { get; set; }
        public string statisticsintervalms { get; set; }
        public string sessiontimeoutms { get; set; }
        public string autooffsetreset { get; set; }
        public string enablepartitioneof { get; set; }

        public string username { get; set; }
        public string password { get; set; }
        public string protocol { get; set; }

    }
}
