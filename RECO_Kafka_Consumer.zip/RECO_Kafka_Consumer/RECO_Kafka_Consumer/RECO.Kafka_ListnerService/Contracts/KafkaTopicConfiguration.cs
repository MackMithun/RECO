﻿namespace RECO.Kafka_ListnerService.Contracts
{
    public class KafkaTopicConfiguration
    {
        public string FlightCancel { set; get; }
        public string EquipmentEvent { set; get; }
        public string TerminalEvent { set; get; }
        public string ETDEvent { set; get; }
        public string InBlockActualTimeEvent { set; get; }
        public string LandingEstimatedTimeEvent { set; get; }
        public string OffBlockEstimatedTimeEvent { set; get; }
        public string InBlockEstimatedTimeEvent { set; get; }
        public string TakeOffActualTimeEvent { set; get; }
        public string LandingActualTimeEvent { set; get; }
        public string OffBlockActualTimeEvent { set; get; }
        public string BrsSmartNotifyEvent { set; get; }
        public string PassengerCountManifestEvent { set; get; }
        public string FlightDelayTimeEvent { set; get; }
        public string DoorCloseEvent { set; get; }
        public string ChangeManifestEvent { set; get; }
    }
}
