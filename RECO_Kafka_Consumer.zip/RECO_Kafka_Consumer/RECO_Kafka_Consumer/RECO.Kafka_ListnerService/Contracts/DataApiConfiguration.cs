﻿namespace RECO.Kafka_ListnerService.Contracts
{
    public class DataApiConfiguration
    {
        public string BaseURL { get; set; }
        public string DataApiAuthKey { get; set; }
        public string DataApiAuthValue { get; set; }
        public string GetApis { get; set; }
    }
}
