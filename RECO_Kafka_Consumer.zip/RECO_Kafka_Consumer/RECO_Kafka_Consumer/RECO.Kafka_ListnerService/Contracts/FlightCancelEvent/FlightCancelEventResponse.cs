﻿namespace RECO.Kafka_ListnerService.Contracts.FlightCancelEvent
{
    public class FlightInfo
    {
        public string carrier { get; set; }
        public string dateOfOrigin { get; set; }
        public int flightNumber { get; set; }
        public string startStation { get; set; }
        public string endStation { get; set; }
        public DateTime? scheduledStartTime { get; set; }

    }
    public class Current
    {
        public string operationalStatus { get; set; }
        public string cancellationCode { get; set; }
        public string serviceType { get; set; }

    }
    public class Previous
    {
        public string operationalStatus { get; set; }
        public string cancellationCode { get; set; }
        public string serviceType { get; set; }

    }
    public class Application
    {
        public FlightInfo flightInfo { get; set; }
        public Current current { get; set; }
        public Previous previous { get; set; }

    }

    public class Root
    {
        public FlightInfo flightInfo { get; set; }
        public Current current { get; set; }
        public Previous previous { get; set; }
    }
}

