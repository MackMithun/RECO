﻿namespace RECO.Kafka_ListnerService.Contracts
{
    public class ApiTokenConfiguration
    {
        public string Url { get; set; }
        public string Granttype { get; set; }
        public string client_id { get; set; }
        public string client_secret { get; set; }
    }
}
