﻿using RECO.ReaccommodationDALService.IUtilities;

namespace RECO.ReaccommodationDALService.Common
{
    public class ClsCommon : IClsCommon
    {
        private readonly IConfiguration _configuration;
        public ClsCommon(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        #region GetConfigData
        public string GetConfigData(string keyName)
        {
            return ConfigMethods.GetDetailsFromConfig(keyName);
        }
        #endregion
    }
}
