﻿namespace RECO.ReaccommodationDALService.Common
{
    public class Configurations
    {
        public List<ApiConfiguration> ApiConfigurations { get; set; }
    }

    public class ApiConfiguration
    {
        //testing changes
        public string Key { get; set; }
        public string Value { get; set; }
    }

    public static class ConfigMethods
    {
        public static string GetDetailsFromConfig(string key)
        {
            var apiConfigs = Utilities.Utilities.GetApiConfigurations();
            return apiConfigs.ApiConfigurations.Where(m => m.Key == key).FirstOrDefault().Value;
        }
    }
}
