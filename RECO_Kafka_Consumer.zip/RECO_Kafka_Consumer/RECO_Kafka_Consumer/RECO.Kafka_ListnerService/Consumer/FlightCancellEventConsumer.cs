﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Confluent.Kafka;
using RECO.Kafka_ListnerService.Contracts;
using RECO.Kafka_ListnerService.Repository;
using RECO.Kafka_ListnerService.Contracts.FlightCancelEvent;

namespace RECO.Kafka_ListnerService.Consumer
{
    public class FlightCancellEventConsumer : BackgroundService
    {
        private string _topicName;
        private IConsumer<string, string> _consumer;

        private readonly IOptions<ConsumerConfiguration> _configuration;

        private readonly IOptions<KafkaTopicConfiguration> _kafkaTopicConfiguration;
        private readonly IFlightRepository _flightRepository;
        private readonly ILogHelper _logHelper;
        public FlightCancellEventConsumer(IOptions<ConsumerConfiguration> configuration, IFlightRepository flightRepository,
            IOptions<KafkaTopicConfiguration> kafkaTopicConfiguration, ILogHelper logHelper)
        {

            _configuration = configuration;
            _flightRepository = flightRepository;
            _kafkaTopicConfiguration = kafkaTopicConfiguration;
            _logHelper = logHelper;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Yield();

            stoppingToken.ThrowIfCancellationRequested();
            var consumerConfig = new ConsumerConfig()
            {
                BootstrapServers = _configuration.Value.bootstrapservers,
                SslCaLocation = _configuration.Value.SslCaLocation,
                SecurityProtocol = SecurityProtocol.Ssl,
                SslKeyPassword = _configuration.Value.SslKeyPassword,
                AutoOffsetReset = AutoOffsetReset.Latest,
                EnableAutoCommit = true,
                GroupId = _configuration.Value.groupid,
            };
            _topicName = _kafkaTopicConfiguration.Value.FlightCancel;

            using (var c = new ConsumerBuilder<string, string>(consumerConfig).Build())
            {
                c.Subscribe(_topicName);

                CancellationTokenSource cts = new CancellationTokenSource();

                try
                {
                    _logHelper.LogInfo("Flight cancel event started");
                    while (!stoppingToken.IsCancellationRequested)
                    {
                        try
                        {
                            var cr = c.Consume(stoppingToken);
                            var response = JsonConvert.DeserializeObject<Root>(cr.Message.Value);
                            _logHelper.LogInfo("Flight cancel event consumed " + cr.Message.Value);
                            if (!(JToken.DeepEquals(JsonConvert.SerializeObject(response.current), JsonConvert.SerializeObject(response.previous))))
                            {
                                _logHelper.LogInfo("Api triggered ");
                                await _flightRepository.CancelEventApis(_topicName, response);
                                _logHelper.LogInfo("Api ended ");
                            }


                        }
                        catch (ConsumeException e)
                        {
                            _logHelper.LogConsoleException(e);
                            //Console.WriteLine($"Error occured: {e.Error.Reason}");
                        }
                        await Task.Delay(TimeSpan.FromMinutes(1), cts.Token);
                    }
                }
                catch (OperationCanceledException)
                {
                    //  return "";
                    // Ensure the consumer leaves the group cleanly and final offsets are committed.
                    c.Close();
                }
            }

            await Task.CompletedTask;
        }
    }
}
