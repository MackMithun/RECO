﻿namespace RECO.ReaccommodationDALService
{
    public static class Constants
    {
        public static readonly string InvalidSecretKey = "Invalid Request, Please provide the valid secret key";
        public static readonly string Comm_FetchFlightOldDetails_PLANB = "Comm_FetchFlightOldDetails_PLANB";
        public static readonly string AppSecretKey = "AppSecretKey";
        public static readonly int ParamTypeCodeTen = 10;     
        public static readonly string SecretKeyError = "Shurveer Comment : Please provide the valid secret key: ";
        public static readonly string ExceptionLogFlag = "ExceptionLogFlag"; 
        public static readonly string EncryptDecryptKey = "b14ca5898a4e4133bbce2ea2315a1916";
        public static readonly string DotREZCommWCFService = "Indigo#977AAA2CEF261DB65A9B85ED42BAF";
    }
}
