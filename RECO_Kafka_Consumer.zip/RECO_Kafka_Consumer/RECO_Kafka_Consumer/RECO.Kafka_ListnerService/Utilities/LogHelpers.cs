﻿using RECO.Kafka_ListnerService.Repository;

namespace RECO.Kafka_ListnerService.Utilities
{
    public class LogHelpers : ILogHelper
    {
        private readonly IConfiguration _configuration;
        public LogHelpers(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void LogError(string message) => Console.WriteLine($"Error:-[{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}] " + message);

        public void LogInfo(string message) => Console.WriteLine($"Info:-[{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")}] " + message);

        public void LogConsoleException(Exception ex)
        {
            Console.WriteLine($"TimeStamp: {"[" + DateTime.Now.ToString() + "]"}");
            Console.WriteLine($"Message: {ex.Message}");
            Console.WriteLine($"StackTrace: {ex.StackTrace}");
            if (ex.InnerException != null)
                Console.WriteLine($"Inner Exception Message: {ex.InnerException.Message}");

            MailHelper.SendmailAlert(_configuration, $"MESSAGE - {ex.Message}{Environment.NewLine} STACK TRACE - {ex.StackTrace}");
        }
    }
}
