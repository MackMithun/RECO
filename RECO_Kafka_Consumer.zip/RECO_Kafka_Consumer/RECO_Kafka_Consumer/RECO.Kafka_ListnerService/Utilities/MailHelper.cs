﻿using System.Net.Mail;

namespace RECO.Kafka_ListnerService.Utilities
{
    public class MailHelper
    {

        public static bool SendmailAlert(IConfiguration _config, string message)
        {
            try
            {
                var mailConfig = _config.GetSection("Mailing");
                int PORT = Convert.ToInt32(mailConfig["PORT"]);
                string SMTPHOST = mailConfig["SMTP"];
                MailAddress From = new(mailConfig["MailFROM"]);
                MailAddress To = new(mailConfig["MailTO"]);
                MailMessage msg = new(From, To);
                foreach (var mailaddress in mailConfig["MailCC"].Split(','))
                {
                    msg.CC.Add(new(mailaddress));
                }
                msg.Subject = mailConfig["MailSUBJECT"];
                msg.Body = message;
                msg.IsBodyHtml = true;
                msg.Priority = MailPriority.High;
                SmtpClient objsmtp = new SmtpClient();

                objsmtp.EnableSsl = false;
                objsmtp.Host = SMTPHOST;
                objsmtp.Port = PORT;
                objsmtp.UseDefaultCredentials = false;
                objsmtp.Credentials = new System.Net.NetworkCredential(mailConfig["MailFROM"].Replace("@goindigo.in", string.Empty), mailConfig["MailCred"]);
                objsmtp.Send(msg);
                msg.Dispose();
                return true;
            }
            catch (Exception mailEx)
            {
                Console.WriteLine($"{DateTime.Now} - [MailStatus] {mailEx.Message}");
                Console.WriteLine($"{DateTime.Now} - [Exception] {mailEx.Message}");
                Console.WriteLine($"{DateTime.Now} - [Exception StackTrace] {mailEx.StackTrace}");
            }
            return false;
        }
    }
}
