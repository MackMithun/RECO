﻿using Newtonsoft.Json;
using RECO.ReaccommodationDALService.Common;

namespace RECO.ReaccommodationDALService.Utilities
{
    public class Utilities
    {
        public static Configurations GetApiConfigurations()
        {
            Configurations items = null;

            using (StreamReader r = new StreamReader("Configs/API Config.json"))
            {
                string json = r.ReadToEnd();
                items = JsonConvert.DeserializeObject<Configurations>(json);
            }
            return items;
        }
    }    
}
