﻿using RECO.ReaccommodationDALService.IUtilities;

namespace RECO.ReaccommodationDALService.Utilities
{
    public class clsCommonUtill : IClsCommonUtill
    {
        private readonly ILogger _logger;
        private readonly IClsCommon _clsCommon;

        public clsCommonUtill(ILogger<clsCommonUtill> logger, IClsCommon clsCommon)
        {
            _logger = logger;
            _clsCommon = clsCommon;
        }

        public bool IsValidSecretKey(string? SecretKey)
        {
            string AppSecretKey = _clsCommon.GetConfigData(Constants.AppSecretKey);

            if (AppSecretKey != SecretKey)
            {
                _logger.LogError("Error Message: - " + Constants.SecretKeyError + SecretKey);
                return true;
            }
            return false;
        }        
    }
}
