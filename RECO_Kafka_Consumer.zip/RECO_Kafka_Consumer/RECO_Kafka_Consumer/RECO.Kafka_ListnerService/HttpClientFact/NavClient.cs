﻿using Newtonsoft.Json;
using PlanBDBAccess_SkyPlus.HttpClientFact;

using RECO.ReaccommodationDALService.Models;
using System.Text;

namespace PlanBEligibPlanBDBAccess_SkyPlusilty_SkyPlus.HttpClientFact
{
    public class NavClient : INavClient
    {
        private readonly HttpClient? _httpClient;
        private readonly ILogger<NavClient> _logger;        
        private dynamic? _content;
        private dynamic? _responseObject;
        private string _auth;
        private string _gatewayKey;
        public string URL { get; set; }

        public string? Auth
        {
            get
            {

                return _auth;
            }   // get method
            set
            {
                _auth = value;
                if (!string.IsNullOrEmpty(_auth) && _httpClient != null)
                {
                    _httpClient.DefaultRequestHeaders.Remove("Authorization");
                    _httpClient.DefaultRequestHeaders.Add("Authorization", _auth);
                }

            }  // set method
        }

        public string GatewayKey
        {
            get
            {
                return _gatewayKey;
            }
            set
            {
                _gatewayKey = value;
                if (!string.IsNullOrEmpty(_gatewayKey) && _httpClient != null)
                {
                    if (_httpClient.DefaultRequestHeaders.Contains("user_key"))
                    {
                        _httpClient.DefaultRequestHeaders.Remove("user_key");
                    }
                    _httpClient.DefaultRequestHeaders.Add("user_key", _gatewayKey);
                }
            }
        }

        public dynamic? Content
        {
            get
            {

                return _content;
            }   // get method
            set
            {
                _content = new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");

            }  // set method
        }

        public NavClient(HttpClient httpClient, ILogger<NavClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        public dynamic? GetAsync()
        {
            HttpResponseMessage? _response = null;
            int statusCode;
            if (_httpClient != null)
            {
                try
                {
                    _response = _httpClient.GetAsync(URL).Result;
                    _response.Headers.Remove("Server");
                    statusCode = Convert.ToInt32(_response.StatusCode);
                    //_logger.LogInformation("NavClientInfo, Navitaire URL :- " + URL + " Navitaire Response :- " + (string)_response.Content.ReadAsStringAsync().Result + " | CorrelationId :- " + _httpClient.DefaultRequestHeaders.Authorization);
                    _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
                }
                catch (Exception ex)
                {
                    Exception exception = UnExpectedError(_response, ex);
                    throw exception;
                }
                ExceptionCheck(_response, statusCode);
            }

            return _responseObject;
        }

        private void ExceptionCheck(HttpResponseMessage? _response, int statusCode)
        {
            if (!(statusCode >= 200 && statusCode < 250) && _responseObject != null)
            {
                var error = _responseObject.errors[0];
                Errors errors = new Errors();
                if (statusCode == 440)
                {
                    errors.code = error.Code.ToString();
                    errors.message = error.Message.ToString();
                    errors.type = error.Type.ToString();
                }
                else
                {
                    errors.code = error.code.ToString();
                    errors.message = null;
                    errors.type = null;
                }                
                Exception exception = new Exception(errors.code + " , Navitaire Status Code : " + Convert.ToString(statusCode) + " , Navitaire Response : - {" + _response.Content.ReadAsStringAsync().Result + "}");
                throw exception;
            }
        }

        private static Exception UnExpectedError(HttpResponseMessage? _response, Exception ex)
        {
            return new Exception("UnExpectedError" + ", Navitaire Status Code : " + Convert.ToString(_response == null ? "Response object is Null" : (int)_response?.StatusCode) + " , Exception Message:-" + ex.Message);
        }

        public dynamic? PostAsync()
        {
            HttpResponseMessage? _response = null;
            int statusCode;

            if (_httpClient != null)
            {
                try
                {
                    _response = _httpClient.PostAsync(URL, Content).Result;
                    _response.Headers.Remove("Server");

                    statusCode = Convert.ToInt32(_response.StatusCode);
                    //_logger.LogInformation("NavClientInfo, Navitaire URL :- " + URL + " Navitaire Response :- " + (string)_response.Content.ReadAsStringAsync().Result + " | CorrelationId :- " + _httpClient.DefaultRequestHeaders.Authorization);
                    _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
                }
                catch (Exception ex)
                {
                    Exception exception = UnExpectedError(_response, ex);
                    throw exception;
                }
                ExceptionCheck(_response, statusCode);
            }
            return _responseObject;
        }

        public dynamic? PutAsync()
        {
            HttpResponseMessage? _response = null;
            int statusCode;
            if (_httpClient != null)
            {
                try
                {
                    _response = _httpClient.PutAsync(URL, Content).Result;
                    _response.Headers.Remove("Server");
                    statusCode = ((int)_response.StatusCode);
                    //_logger.LogInformation("NavClientInfo, Navitaire URL :- " + URL + " Navitaire Response :- " + (string)_response.Content.ReadAsStringAsync().Result + " | CorrelationId :- " + _httpClient.DefaultRequestHeaders.Authorization);
                    _responseObject = JsonConvert.DeserializeObject<dynamic>(_response.Content.ReadAsStringAsync().Result);
                }
                catch (Exception ex)
                {
                    Exception exception = UnExpectedError(_response, ex);
                    throw exception;
                }
                ExceptionCheck(_response, statusCode);
            }
            return _responseObject;
        }

        public dynamic? DeleteAsync()
        {
            if (Content is null)
            {
                _responseObject = _httpClient.DeleteAsync(URL).Result;
            }
            else
            {
                HttpRequestMessage request = new HttpRequestMessage();
                request.Method = HttpMethod.Delete;
                request.Content = Content;
                request.RequestUri = new Uri(URL);
                request.Headers.Add("Authorization", Auth);
                request.Headers.Add("user_key", _gatewayKey);
                _responseObject = _httpClient.SendAsync(request).Result;
            }
            //_logger.LogInformation("NavClientInfo, Navitaire URL :- " + URL + " Navitaire Response :- " + (string)_responseObject.Content.ReadAsStringAsync().Result + " | CorrelationId :- " + _httpClient.DefaultRequestHeaders.Authorization);
            _responseObject.Headers.Remove("Server");
            return JsonConvert.DeserializeObject<dynamic>(_responseObject.Content.ReadAsStringAsync().Result);
        }
    }
}
