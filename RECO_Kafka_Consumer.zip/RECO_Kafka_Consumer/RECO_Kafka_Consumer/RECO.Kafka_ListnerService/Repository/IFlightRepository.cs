﻿namespace RECO.Kafka_ListnerService.Repository
{
    public interface IFlightRepository
    {
        

        Task CancelEventApis(string topic, Contracts.FlightCancelEvent.Root response);

    }
}
