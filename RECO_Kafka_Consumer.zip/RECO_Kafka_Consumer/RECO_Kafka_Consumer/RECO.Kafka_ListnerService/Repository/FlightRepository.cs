﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RECO.Kafka_ListnerService.Contracts;
using RECO.Kafka_ListnerService.Models;
using RECO.Kafka_ListnerService.RestClient;
using System.Net.Http.Headers;

namespace RECO.Kafka_ListnerService.Repository
{
    public class FlightRepository : IFlightRepository
    {
        private readonly IRestClient _restClient;
        private readonly IOptions<DataApiConfiguration> _configuration;
        private readonly IOptions<ApiTokenConfiguration> _apiTokenConfiguration;
        private readonly ILogHelper _logHelper;

        public FlightRepository(IRestClient restClient, IOptions<DataApiConfiguration> configuration,
             IOptions<ApiTokenConfiguration> apiTokenConfiguration, ILogHelper logHelper)
        {
            _restClient = restClient;
            _configuration = configuration;
            _apiTokenConfiguration = apiTokenConfiguration;
            _logHelper = logHelper;
        }

        public async Task<RECO_KafkaEvents> GetApiFromTopic(string request)
        {
            string url = _configuration.Value.BaseURL + string.Format(_configuration.Value.GetApis, request);

            MapHttpClientproperty("", _configuration.Value.DataApiAuthValue, url);

            var result = _restClient.GetAsync();

            return result;
        }

        private void MapHttpClientproperty(string auth, string gateWayKey, string url)
        {

            _restClient.Auth = auth;

            _restClient.GatewayKey ??= gateWayKey;

            _restClient.URL = url;

        }

        public dynamic? GetAPIToken(string AppName)
        {
            HttpClient _client = new HttpClient();
            string url = _apiTokenConfiguration.Value.Url;
            //  _client.DefaultRequestHeaders.Remove("user_key");
            // _client.DefaultRequestHeaders.Add("user_key", _configuration.GetValue<string>("SuccesfactorApis:SuccesfactorAuthValue"));



            var loginData = new Dictionary<string, string>
                {
                    {"grant_type",  _apiTokenConfiguration.Value.Granttype },
                    {"client_id", _apiTokenConfiguration.Value.client_id },
                    {"client_secret", _apiTokenConfiguration.Value.client_secret},

                };
            var content = new FormUrlEncodedContent(loginData);
            HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, url);

            req.Content = content;
            req.Content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");

            try
            {
                var response = _client.Send(req);

                var jsonContent = response.Content.ReadAsStringAsync();

                TokenResponse token = JsonConvert.DeserializeObject<TokenResponse>(jsonContent.Result);
                //Token tok = JsonConvert.DeserializeObject<Token>(jsonContent);
                return token.access_token;
            }
            catch (Exception ex) { return null; }
        }

        public async Task CancelEventApis(string topic, Contracts.FlightCancelEvent.Root response)
        {
            string url = _configuration.Value.BaseURL + string.Format(_configuration.Value.GetApis, topic);

            MapHttpClientproperty("", _configuration.Value.DataApiAuthValue, url);

            var result = _restClient.GetAsync();
            RECO_KafkaEvents events = JsonConvert.DeserializeObject<RECO_KafkaEvents>(JsonConvert.SerializeObject(result));
            events.RECO_EventApiMappings.ForEach(x =>
            {
                url = x.BaseUrl + x.ApiUrl;
                _logHelper.LogInfo("url {0}" + url);
                MapHttpClientproperty("Bearer " + GetAPIToken(""), x.AuthValue, url);
                _restClient.Content = response;
                _restClient.PostAsync();
            });

        }

    }

}
