﻿namespace RECO.Kafka_ListnerService.Repository
{
    public interface ILogHelper
    {
        public void LogError(string message);
        public void LogInfo(string message);
        public void LogConsoleException(Exception ex);
    }
}
